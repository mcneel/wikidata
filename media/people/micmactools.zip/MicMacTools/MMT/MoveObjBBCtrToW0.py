"""Moves selected object from its bounding box center to the world origin
Script by Mitch Heynick 29.01.2015"""

import rhinoscriptsyntax as rs
def MoveObjBBCtrToW0():
    obj=rs.GetObject("Select object to center at world 0",preselect=True)
    if not obj: return
    origin=rs.coerce3dpoint([0,0,0])
    bb=rs.BoundingBox(obj)
    if bb:
        ctr=(bb[0]+bb[6])/2
        rs.MoveObject(obj,origin-ctr)
MoveObjBBCtrToW0()