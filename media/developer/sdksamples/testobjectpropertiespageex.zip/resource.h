//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TestObjectPropertiesPageEx.rc
//
#define IDD_OBJPROPPAGE_DIALOG          8002
#define IDC_S_HYPERLINK                 8002
#define IDC_E_HYPERLINK                 8003
#define IDI_ICON1                       8003
#define IDI_OBJPROPPAGE_DIALOG          8003
#define IDC_B_HYPERLINK                 8004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        8004
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         8005
#define _APS_NEXT_SYMED_VALUE           8002
#endif
#endif
