/////////////////////////////////////////////////////////////////////////////
// TestObjectPropertiesPageExPlugIn.cpp

#include "StdAfx.h"
#include "Resource.h"
#include "TestObjectPropertiesPageExPlugIn.h"
#include "TestObjectPropertiesPageExDlg.h"

#pragma warning( push )
#pragma warning( disable : 4073 )
#pragma init_seg( lib )
#pragma warning( pop )

// Rhino plug-in declaration
RHINO_PLUG_IN_DECLARE

// Rhino plug-in name
// Provide a short, friendly name for this plug-in.
RHINO_PLUG_IN_NAME( L"TestObjectPropertiesPageEx" );

// Rhino plug-in id
// Provide a unique uuid for this plug-in
RHINO_PLUG_IN_ID( L"230C6D30-431C-4763-875A-483CAA9FB215" );

// Rhino plug-in version
// Provide a version number string for this plug-in
RHINO_PLUG_IN_VERSION( __DATE__"  "__TIME__ )

// Rhino plug-in developer declarations
// TODO: fill in the following developer declarations with
// your company information. Note, all of these declarations
// must be present or your plug-in will not load.
RHINO_PLUG_IN_DEVELOPER_ORGANIZATION( L"My Company Name" );
RHINO_PLUG_IN_DEVELOPER_ADDRESS( L"123 Developer Street\r\nCity State 12345-6789" );
RHINO_PLUG_IN_DEVELOPER_COUNTRY( L"My Country" );
RHINO_PLUG_IN_DEVELOPER_PHONE( L"123.456.7890" );
RHINO_PLUG_IN_DEVELOPER_FAX( L"123.456.7891" );
RHINO_PLUG_IN_DEVELOPER_EMAIL( L"support@mycompany.com" );
RHINO_PLUG_IN_DEVELOPER_WEBSITE( L"http://www.mycompany.com" );
RHINO_PLUG_IN_UPDATE_URL( L"http://www.mycompany.com/support" );

// The one and only CTestObjectPropertiesPageExPlugIn object
static CTestObjectPropertiesPageExPlugIn thePlugIn;

/////////////////////////////////////////////////////////////////////////////
// CTestObjectPropertiesPageExPlugIn definition

CTestObjectPropertiesPageExPlugIn& TestObjectPropertiesPageExPlugIn()
{ 
  // Return a reference to the one and only CTestObjectPropertiesPageExPlugIn object
  return thePlugIn; 
}

CTestObjectPropertiesPageExPlugIn::CTestObjectPropertiesPageExPlugIn()
{
  // TODO: Add construction code here
  m_plugin_version = RhinoPlugInVersion();
}

CTestObjectPropertiesPageExPlugIn::~CTestObjectPropertiesPageExPlugIn()
{
  // TODO: Add destruction code here
}

/////////////////////////////////////////////////////////////////////////////
// Required overrides

const wchar_t* CTestObjectPropertiesPageExPlugIn::PlugInName() const
{
  // TODO: Return a short, friendly name for the plug-in.
  return RhinoPlugInName();
}

const wchar_t* CTestObjectPropertiesPageExPlugIn::PlugInVersion() const
{
  // TODO: Return the version number of the plug-in.
  return m_plugin_version;
}

GUID CTestObjectPropertiesPageExPlugIn::PlugInID() const
{
  // TODO: Return a unique identifier for the plug-in.
  // {230C6D30-431C-4763-875A-483CAA9FB215}
  return ON_UuidFromString( RhinoPlugInId() );
}

BOOL CTestObjectPropertiesPageExPlugIn::OnLoadPlugIn()
{
  // TODO: Add plug-in initialization code here.
  return CRhinoUtilityPlugIn::OnLoadPlugIn();
}

void CTestObjectPropertiesPageExPlugIn::OnUnloadPlugIn()
{
  // TODO: Add plug-in cleanup code here.
  CRhinoUtilityPlugIn::OnUnloadPlugIn();
}

void CTestObjectPropertiesPageExPlugIn::AddPagesToObjectPropertiesDialog( ON_SimpleArray<class CRhinoObjectPropertiesDialogPage*>& pages )
{
  AFX_MANAGE_STATE( AfxGetStaticModuleState() );
  HWND hWnd = RhinoApp().MainWnd();
  CTestObjectPropertiesPageExDlg* page = new CTestObjectPropertiesPageExDlg( IDD_OBJPROPPAGE_DIALOG, CWnd::FromHandle(hWnd) );
  if( page )
    pages.Append( page );
}
