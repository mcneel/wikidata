import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def GetObjectOrValue(prompt,filt=None):
    #prompt==command line prompt
    go = Rhino.Input.Custom.GetObject()
    go.SetCommandPrompt(prompt)
    go.AcceptNumber(True,True)
    if filt:
        go.GeometryFilter=filt
        #can add subfilter if desired
        #go.SetCustomGeometryFilter(None)
    value=None
    while True:
        get_rc = go.Get()
        if get_rc==Rhino.Input.GetResult.Cancel: return
        if get_rc==Rhino.Input.GetResult.Object:
            value=go.Object(0)
            break
        elif get_rc==Rhino.Input.GetResult.Number:
            value=go.Number()
            if value<=0:
                print "Number must be greater than 0" ; continue
            else: break
    return value
    
def GetObjPrintWidth(objID):
    if rs.ObjectPrintWidthSource(objID) == 1:
        obj_pw = rs.ObjectPrintWidth(objID)
    elif rs.ObjectPrintWidthSource(objID) == 0:
        obj_pw = rs.LayerPrintWidth(rs.ObjectLayer(objID))
    return obj_pw

def SelCrvsByPrintWidth():
    objs = rs.ObjectsByType(4,state=1)
    if not objs: return
    
    msg1="Pick curve with print width to match or key in value"
    gf=Rhino.DocObjects.ObjectType.Curve
    result=GetObjectOrValue(msg1,gf)
    if result is None: return
    if isinstance(result,Rhino.DocObjects.ObjRef):
        wid=GetObjPrintWidth(result.ObjectId)
    else:
        wid=result
    
    rs.EnableRedraw(False)
    n = 0
    tol=sc.doc.ModelAbsoluteTolerance
    for obj in objs:
        objPW=GetObjPrintWidth(obj)
        if Rhino.RhinoMath.EpsilonEquals(objPW,wid,tol*0.1):
        rs.SelectObject(obj)
        n+=1
        
    if n >0: 
        if n==1: s=""
        else: s="s"
        print "Selected {} curve{} with print width {}".format(n,s,objPW)
    else: print "No curves of print width {} found".format(objPW)

SelCrvsByPrintWidth()