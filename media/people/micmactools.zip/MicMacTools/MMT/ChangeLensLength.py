import rhinoscriptsyntax as rs

def ChangeLensLength():
    if rs.IsViewPerspective(rs.CurrentView()):
        curr_len=rs.ViewCameraLens(rs.CurrentView())
        msg="Current camera lens length is {} New lens length?".format(curr_len)
        new_len=rs.GetReal(msg,minimum=1.0)
        if new_len is not None:
            rs.ViewCameraLens(rs.CurrentView(),new_len)
    else:
        print "Cannot change lens length for parallel projection viewports"
ChangeLensLength()