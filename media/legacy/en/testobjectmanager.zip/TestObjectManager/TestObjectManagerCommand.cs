using RMA.Rhino;
using RMA.OpenNURBS;

namespace TestObjectManager
{
  public class TestObjectManagerCommand : RMA.Rhino.MRhinoCommand
  {
    public override System.Guid CommandUUID()
    {
      return new System.Guid("{0115f73b-42e2-468c-9c31-a4b367cdde7f}");
    }

    public override string EnglishCommandName()
    {
      return "TestObjectManager";
    }

    public override IRhinoCommand.result RunCommand(IRhinoCommandContext context)
    {
      System.Guid id = TestObjectManagerDockBar.ID();
      bool bVisible = RMA.UI.MRhinoDockBarManager.IsDockBarVisible(id);

      string prompt;
      if (bVisible)
        prompt = string.Format("{0} window is visible. New value", EnglishCommandName());
      else
        prompt = string.Format("{0} window is hidden. New value", EnglishCommandName());

      MRhinoGetOption go = new MRhinoGetOption();
      go.SetCommandPrompt(prompt);
      int h_option = go.AddCommandOption(new MRhinoCommandOptionName("Hide"));
      int s_option = go.AddCommandOption(new MRhinoCommandOptionName("Show"));
      int t_option = go.AddCommandOption(new MRhinoCommandOptionName("Toggle"));
      go.GetOption();
      if (go.CommandResult() != IRhinoCommand.result.success)
        return go.CommandResult();

      IRhinoCommandOption opt = go.Option();
      if (opt == null)
        return IRhinoCommand.result.failure;

      int option_index = opt.m_option_index;
      if (h_option == option_index)
      {
        if (bVisible)
          RMA.UI.MRhinoDockBarManager.ShowDockBar(id, false, false);
      }
      else if (s_option == option_index)
      {
        if (!bVisible)
          RMA.UI.MRhinoDockBarManager.ShowDockBar(id, true, false);
      }
      else if (t_option == option_index)
      {
        if (bVisible)
          RMA.UI.MRhinoDockBarManager.ShowDockBar(id, false, false);
        else
          RMA.UI.MRhinoDockBarManager.ShowDockBar(id, true, false);
      }

      return IRhinoCommand.result.success;
    }
  }
}

