import rhinoscriptsyntax as rs
import random

#objs=rs.NormalObjects()
objs=rs.GetObjects("Select objects to random color")
rs.EnableRedraw(False)
for obj in objs:
    r=random.randint(0,255)
    g=random.randint(0,255)
    b=random.randint(0,255)
    rs.ObjectColor(obj,[r,g,b])
