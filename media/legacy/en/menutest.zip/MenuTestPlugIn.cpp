/////////////////////////////////////////////////////////////////////////////
// MenuTestPlugIn.cpp
//

#include "StdAfx.h"
#include "Resource.h"

#pragma warning( push )
#pragma warning( disable : 4073 )
#pragma init_seg( lib )
#pragma warning( pop )

// The one and only CMenuTestPlugIn object
static CMenuTestPlugIn thePlugIn;

// Returns reference to the plug-in object
CMenuTestPlugIn& MenuTestPlugIn() { return thePlugIn; }

// Rhino plug-in declaration
RHINO_PLUG_IN_DECLARE
RHINO_PLUG_IN_DEVELOPER_ORGANIZATION( L"Robert McNeel & Associates" );
RHINO_PLUG_IN_DEVELOPER_ADDRESS( L"3670 Woodland Park Ave N\r\nSeattle, WA 98103" );
RHINO_PLUG_IN_DEVELOPER_COUNTRY( L"United States" );
RHINO_PLUG_IN_DEVELOPER_PHONE( L"206-545-7000" );
RHINO_PLUG_IN_DEVELOPER_FAX( L"206-545-7321" );
RHINO_PLUG_IN_DEVELOPER_EMAIL( L"tech@mcneel.com" );
RHINO_PLUG_IN_DEVELOPER_WEBSITE( L"http://www.rhino3d.com" );
RHINO_PLUG_IN_UPDATE_URL( L"ftp://ftp.rhino3d.com/updateme.cab" );


CMenuTestPlugIn::CMenuTestPlugIn()
{
  m_plugin_version = __DATE__"  "__TIME__;
  m_script_mode = false;
}

GUID CMenuTestPlugIn::PlugInID() const
{
  // {B8FED069-E63-4C62-8C83-BD34325ACE50}
  static const GUID MenuTestPlugIn_GUID =
  { 0xB8FED069, 0xE63, 0x4C62, { 0x8C, 0x83, 0xBD, 0x34, 0x32, 0x5A, 0xCE, 0x50 } };
  return MenuTestPlugIn_GUID;
}

BOOL CMenuTestPlugIn::OnLoadPlugIn()
{
  AFX_MANAGE_STATE( AfxGetStaticModuleState() );

  if( m_menu.LoadMenu(IDR_MENUTEST) )
    InsertPlugInMenuToRhinoMenu( m_menu.GetSafeHmenu(), 0);

  return TRUE;
}

void CMenuTestPlugIn::OnUnloadPlugIn()
{
  RemovePlugInMenuFromRhino( ::GetSubMenu(m_menu.GetSafeHmenu(), 0) );
}

BOOL CMenuTestPlugIn::OnDisplayPlugInHelp( HWND hWnd ) const
{
  ::RhinoMessageBox( L"TODO: Add online help here.", PlugInName(), MB_OK );
  return TRUE;
}

void CMenuTestPlugIn::OnInitPlugInMenuPopups( WPARAM wParam, LPARAM )
{
  HMENU hMenu = (HMENU)wParam;
  UINT uCheck = MF_BYCOMMAND;
  if( m_script_mode )
    uCheck |= MF_CHECKED;
  else
    uCheck |= MF_UNCHECKED;

  ::CheckMenuItem( hMenu, ID_TESTMENU_SCRIPTMODE, uCheck );
}

BOOL CMenuTestPlugIn::OnPlugInMenuCommand( WPARAM wParam )
{
  switch( wParam )
  {
  case ID_TESTMENU_TESTCOMMAND1:
    {
      if( m_script_mode )
        RhinoApp().RunScript( L"_-TestCommand1" );
      else
        RhinoApp().RunScript( L"_TestCommand1" );
    }
    break;

  case ID_TESTMENU_TESTCOMMAND2:
    {
      if( m_script_mode )
        RhinoApp().RunScript( L"_-TestCommand2" );
      else
        RhinoApp().RunScript( L"_TestCommand2" );
    }
    break;

  case ID_TESTMENU_SCRIPTMODE:
    m_script_mode = (m_script_mode) ? false : true;
    break;

  default:
    return FALSE;
  }

  return TRUE;
}
