"""Script by Mitch Heynick, 20 June 2013
Interpolates the display color on a group of objects
between a start color black or white
(order is the order of the objects in the file)"""
import rhinoscriptsyntax as rs
import scriptcontext

def ProgressiveColorRange():
    
    #check for previous settings
    if scriptcontext.sticky.has_key("RedChoice"):
        rChoice = scriptcontext.sticky["RedChoice"]
    else:
        rChoice=True
        
    if scriptcontext.sticky.has_key("GreenChoice"):
        gChoice = scriptcontext.sticky["GreenChoice"]
    else:
        gChoice=True
        
    if scriptcontext.sticky.has_key("BlueChoice"):
        bChoice = scriptcontext.sticky["BlueChoice"]
    else:
        bChoice=True
        
    if scriptcontext.sticky.has_key("FadeChoice"):
        fChoice = scriptcontext.sticky["FadeChoice"]
    else:
        fChoice=True
    
    #user input
    objs=rs.GetObjects("Select objects for color progression",preselect=True)
    if not objs: return
    
    rangeList=[("Red","No","Yes"),("Green","No","Yes"),("Blue","No","Yes"),("FadeTo","White","Black")]
    rangeChoice=rs.GetBoolean("ColorRanges",rangeList,[rChoice,gChoice,bChoice,fChoice])
    if rangeChoice==None: return
    
    ranges = reduce(lambda x, y: x+y, rangeChoice[0:3])
    #if all add to 0: all are False, exit
    if ranges==0: return
    
    num=len(objs)
    step=255/(len(objs)-1) #can be non-integer
    
    #progression
    satVal=[int(i*step) for i in range(num)]
    r,g,b=satVal,satVal,satVal

    if rangeChoice[3]:
        #to black
        if not rangeChoice[0]:
            r=[0]*num
        if not rangeChoice[1]:
            g=[0]*num
        if not rangeChoice[2]:
            b=[0]*num
    else:
        #to white
        satVal.reverse()
        if rangeChoice[0]:
            r=[255]*num
        if rangeChoice[1]:
            g=[255]*num
        if rangeChoice[2]:
            b=[255]*num

    rs.EnableRedraw(False)
    for i in range(num):
        rs.ObjectColor(objs[i],(r[i],g[i],b[i]))
        
    #set previous values
    scriptcontext.sticky["RedChoice"]=rangeChoice[0]
    scriptcontext.sticky["GreenChoice"]=rangeChoice[1]
    scriptcontext.sticky["BlueChoice"]=rangeChoice[2]
    scriptcontext.sticky["FadeChoice"]=rangeChoice[3]
    
ProgressiveColorRange()