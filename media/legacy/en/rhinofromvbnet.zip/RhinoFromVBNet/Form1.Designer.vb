<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
    Me.m_btnShowRhino = New System.Windows.Forms.Button
    Me.m_btnDrawLines = New System.Windows.Forms.Button
    Me.m_btnHideRhino = New System.Windows.Forms.Button
    Me.SuspendLayout()
    '
    'm_btnShowRhino
    '
    Me.m_btnShowRhino.Location = New System.Drawing.Point(43, 12)
    Me.m_btnShowRhino.Name = "m_btnShowRhino"
    Me.m_btnShowRhino.Size = New System.Drawing.Size(120, 30)
    Me.m_btnShowRhino.TabIndex = 0
    Me.m_btnShowRhino.Text = "Show Rhino"
    Me.m_btnShowRhino.UseVisualStyleBackColor = True
    '
    'm_btnDrawLines
    '
    Me.m_btnDrawLines.Location = New System.Drawing.Point(43, 48)
    Me.m_btnDrawLines.Name = "m_btnDrawLines"
    Me.m_btnDrawLines.Size = New System.Drawing.Size(120, 30)
    Me.m_btnDrawLines.TabIndex = 1
    Me.m_btnDrawLines.Text = "Draw Lines"
    Me.m_btnDrawLines.UseVisualStyleBackColor = True
    '
    'm_btnHideRhino
    '
    Me.m_btnHideRhino.Location = New System.Drawing.Point(43, 84)
    Me.m_btnHideRhino.Name = "m_btnHideRhino"
    Me.m_btnHideRhino.Size = New System.Drawing.Size(120, 30)
    Me.m_btnHideRhino.TabIndex = 2
    Me.m_btnHideRhino.Text = "Hide Rhino"
    Me.m_btnHideRhino.UseVisualStyleBackColor = True
    '
    'Form1
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(212, 125)
    Me.Controls.Add(Me.m_btnHideRhino)
    Me.Controls.Add(Me.m_btnDrawLines)
    Me.Controls.Add(Me.m_btnShowRhino)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "Form1"
    Me.Text = "Rhino - VB.NET App"
    Me.ResumeLayout(False)

  End Sub
  Friend WithEvents m_btnShowRhino As System.Windows.Forms.Button
  Friend WithEvents m_btnDrawLines As System.Windows.Forms.Button
  Friend WithEvents m_btnHideRhino As System.Windows.Forms.Button

End Class
