"""Scrolls through the entire layer set from top to bottom and successively 
selects objects on each layer. Enter, spacebar or right mouse click to continue;
Esc to exit. Ignores locked or off layers. Script by Mitch Heynick 11.09.15"""

import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def GetOptionEscCancel(prompt):
    go = Rhino.Input.Custom.GetOption()
    go.SetCommandPrompt(prompt)
    go.AcceptNothing(True)
    get_rc = go.Get()
    if get_rc==Rhino.Input.GetResult.Nothing: return True
    
def ScrollThroughLayersSelectObjs():
    layer_names=rs.LayerNames()
    layer_ids=rs.LayerIds()
    order_list=[rs.LayerOrder(id) for id in layer_ids]
    layer_disp_order=zip(order_list,layer_ids,layer_names)
    layer_disp_order.sort()
    
    for i,layer_id,layer_name in layer_disp_order:
        rs.UnselectAllObjects()
        if not rs.IsLayerLocked(layer_id) and rs.IsLayerVisible(layer_id):
            objs=rs.ObjectsByLayer(layer_id,True)
            if not objs: count="No"
            else: count=len(objs)
            print "{} objects selected on layer {}".format(count,layer_name)
            esc_clause=GetOptionEscCancel("Press Enter to continue, Esc to exit")
            if not esc_clause:
                rs.UnselectAllObjects() ; return
    rs.UnselectAllObjects()
    print "Reached end of layer list, exiting function"
ScrollThroughLayersSelectObjs()