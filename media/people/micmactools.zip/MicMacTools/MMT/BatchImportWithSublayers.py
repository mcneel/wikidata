"""Imports all files of a given filetype from a selected folder
Each file gets a principal parent layer with the filename as layer name
Layer structure in the original files is preserved as sublayers
Script by Mitch Heynick, version 08 september 2015 - Windows or Mac."""

"""This version uniquely randomizes the names of all existing top level layers
in the document in order to avoid having imported objects go to existing layers 
if the files that are being imported have the same named layers.  The names
are restored when the script finishes"""

import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino, os, uuid, System
    
def OnMac():
    return Rhino.Runtime.HostUtils.RunningOnOSX
    
def RandomizeTopLevelLayers():
    #randomize top level layer names by adding unique uuid to layer name
    tl_dic={}
    for layer in sc.doc.Layers:
        if layer.ParentLayerId == System.Guid.Empty:
            #layer is a top level layer
            random_name=str(uuid.uuid4())
            new_name=layer.Name+"-"+random_name
            tl_dic[new_name]=layer.Name
            layer.Name=new_name
            layer.CommitChanges()
    return tl_dic

def RestoreTopLevelLayers(tl_dic):
    #restore top level layer names using previously created dictionary
    for layer in sc.doc.Layers:
        if layer.Name in tl_dic:
                layer.Name=tl_dic[layer.Name]
                layer.CommitChanges()
                
def ProcessFolder(folder,ext):
    #check to see if at least one file of the given type is in folder
    blnFound = False
    for filename in os.listdir(folder):
        if filename.endswith(ext):
            blnFound = True ; break
    #if no files of given type, exit
    if not blnFound: return
    orig_curr_layer=rs.CurrentLayer()
    
    #randomize all existing top level layer names first
    restore_dic=RandomizeTopLevelLayers()
    
    #Import all files of chosen filetype in the selected folder
    for filename in os.listdir(folder):
        fullpath=os.path.join(folder,filename).lower()
        #create new layer with filename
        new_top_layer=rs.AddLayer(filename[:-len(ext)] )
        #commented out, this seems unnecessary and could cause problems later
        #rs.CurrentLayer(new_top_layer) 
        #all existing objects will have a layer index lower than the following
        new_top_index=sc.doc.Layers.FindByFullPath(new_top_layer,True)
        
        #import file
        print "Importing " + new_top_layer
        rs.Command("_-Import "+chr(34)+fullpath+chr(34)+" _Enter", False)
        layer_check=sc.doc.Layers
        for layer in sc.doc.Layers:
            if layer.LayerIndex > new_top_index:
                if layer.ParentLayerId == System.Guid.Empty:
                    #layer is an imported parent layer
                    layer.ParentLayerId = sc.doc.Layers[new_top_index].Id
                    layer.CommitChanges()
                    
    #restore original names of top level layers after batch is imported
    RestoreTopLevelLayers(restore_dic)
    #this is "just in case..."
    try:
        if not rs.IsLayerCurrent(orig_curr_layer):
            rs.CurrentLayer(orig_curr_layer)
    except:
        print "Error: unable to restore original current layer"
    return blnFound
    
def BatchImportWithSublayers():
    #UI
    fTypes=["Rhino", "STL", "DXF", "DWG", "IGES", "STEP", "SolidWorks"]
    if "BI_PrevFolder" in sc.sticky: prevFolder = sc.sticky["BI_PrevFolder"]
    else: prevFolder=rs.WorkingFolder()
    if "BI_PrevFileType" in sc.sticky: prevFileType = sc.sticky["BI_PrevFileType"]
    else: prevFileType=fTypes[0]
    
    msg="Select folder to process"
    title="Batch Import"
    #current Mac version bug 08-09-15 - message argument crashes Rhino!
    if OnMac():
        msg="" ; title=""
    folder = rs.BrowseForFolder(prevFolder, msg , title)
    if not folder : return
    
    msg="Select file type to import"
    fType = rs.ListBox(fTypes,msg,title,prevFileType)
    if not fType: return
    
    if fType=="Rhino":
        ext = ".3dm"
    elif fType=="STEP":
        ext = ".stp"
    elif fType=="SolidWorks":
        ext = ".sldprt"
    elif fType=="IGES":
        ext = ".igs"
    else:
        ext = "."+fType.lower()
    
    #Process the folder
    rs.EnableRedraw(False)
    result=ProcessFolder(folder,ext)
    if not result:
        msg="No files of chosen type found in folder!"
        rs.MessageBox(msg, 0, "File Import")
    rs.UnselectAllObjects()
    
    #store last used file type, folder
    sc.sticky["BI_PrevFolder"] = folder
    sc.sticky["BI_PrevFileType"] = fType
    
BatchImportWithSublayers()

