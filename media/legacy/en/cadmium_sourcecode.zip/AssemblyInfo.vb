Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes
<Assembly: RMA.Organization("Reconstructivism.net")> 
<Assembly: RMA.Address("Abtswoude 62" & Vbcrlf & "Schipluiden, Zuid Holland")> 
<Assembly: RMA.Country("The Netherlands")> 
<Assembly: RMA.Phone("call-me-baby")> 
<Assembly: RMA.Fax("-")> 
<Assembly: RMA.EMail("david@reconstructivism.net")> 
<Assembly: RMA.WebSite("http://www.reconstructivism.net")> 
<Assembly: RMA.UpdateURL("http://www.reconstructivism.net")> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
'This is also used as the Rhino Plug-In unique ID
<Assembly: Guid("9EB99E52-6957-47AF-95AA-31BE7329A439")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.*")> 
