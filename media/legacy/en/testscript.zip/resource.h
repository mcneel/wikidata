//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TestScript.rc
//
#define IDD_ABOUT                       28000
#define IDC_EDIT1                       28000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        28001
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         28001
#define _APS_NEXT_SYMED_VALUE           28000
#endif
#endif
