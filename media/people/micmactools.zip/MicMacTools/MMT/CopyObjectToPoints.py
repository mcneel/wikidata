import rhinoscriptsyntax as rs

def CopyObjectToPoints():
    obj=rs.GetObject("Select object to copy to points",preselect=True)
    if not obj: return    
    sPt=rs.GetPoint("Point to copy from")
    if not sPt: return    
    ptIDs=rs.GetObjects("Select points to copy object to",1)
    if not ptIDs: return
    rs.EnableRedraw(False)
    pts=rs.coerce3dpointlist(ptIDs)
    copies=[rs.CopyObject(obj,pt-sPt) for pt in pts]
    rs.SelectObjects(copies)
    rs.SelectObject(obj)
CopyObjectToPoints()