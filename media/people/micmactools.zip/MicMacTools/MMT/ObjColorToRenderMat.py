import rhinoscriptsyntax as rs
import scriptcontext as sc

def ObjColorToRenderMat():
    msg="Select objects to attribute render color"
    objs=rs.GetObjects(msg,8+16+32,preselect=True)
    if not objs: return
    mats=sc.doc.Materials
    rs.EnableRedraw(False)
    gloss=200 #value from 0 (matte) to 255 (full gloss)
    reflect=40 #value from 0% (no reflection) to 100% (fully reflective)
    for obj in objs:
        #new_mat_index=rs.ObjectMaterialIndex(obj)
        color=rs.ObjectColor(obj)
        new_mat_index=rs.AddMaterialToObject(obj)
        rs.MaterialColor(new_mat_index,color)
        rs.MaterialShine(new_mat_index,gloss)
        #newMat=mats[new_mat_index]
        #newMat.Reflectivity=40
        #sc.doc.Materials.Modify(newMat,new_mat_index,True)
ObjColorToRenderMat()