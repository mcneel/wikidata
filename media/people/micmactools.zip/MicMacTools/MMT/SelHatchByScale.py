import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def GetObjectOrValue(prompt,filt=None):
    #prompt==command line prompt
    go = Rhino.Input.Custom.GetObject()
    go.SetCommandPrompt(prompt)
    go.AcceptNumber(True,True)
    if filt: go.GeometryFilter=filt
    value=None
    while True:
        get_rc = go.Get()
        if get_rc==Rhino.Input.GetResult.Cancel: return
        if get_rc==Rhino.Input.GetResult.Object:
            value=go.Object(0)
            break
        elif get_rc==Rhino.Input.GetResult.Number:
            value=go.Number()
            if value<=0:
                print "Number must be greater than 0" ; continue
            else: break
    return value

def SelHatchByScale():
    objs = rs.ObjectsByType(65536)
    if not objs: return
    tol=sc.doc.ModelAbsoluteTolerance
    
    msg1="Select a hatch to match scale or enter a number to search for"
    gf=Rhino.DocObjects.ObjectType.Hatch
    result=GetObjectOrValue(msg1,gf)
    if result is None: return
    if isinstance(result,Rhino.DocObjects.ObjRef):
        sf=rs.HatchScale(result.ObjectId)
    else:
        sf=result
        
    rs.EnableRedraw(False)
    n = 0
    for obj in objs:
        if rs.IsObjectSelectable(obj):
            hp_scale=rs.HatchScale(obj)
            if abs(hp_scale-sf)<tol:
                rs.SelectObject(obj)
                n += 1
    if n>0:
        if n==1: s=""
        else: s="es"
        print "Selected {} hatch{} with scale factor of {}".format(n,s,sf)
    else: print "No hatches of requested scale factor found"

SelHatchByScale()