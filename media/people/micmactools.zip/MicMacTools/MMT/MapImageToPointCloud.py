"""Maps an image to a colored point cloud
Script by Mitch Heynick, 29 Sept 2013"""

import rhinoscriptsyntax as rs
import Rhino, System, scriptcontext

def RemapDomainToDomain(val,minO,maxO,minN,maxN):
    """Remaps a number in an arbitrary domain to another arbitrary domain"""
    if val>maxO or val<minO: return
    if maxO==minO or maxN==minN: return
    return ((val-minO)/(maxO-minO)*(maxN-minN))+minN
    
def Remap2DPointDomain(pt,domA,domAA,domB,domBB):
    """Remaps a 2D point from one 2D domain to another (Z unchanged)
    A-->AA; B-->BB. Needs RemapDomainToDomain function"""
    newPtX=RemapDomainToDomain(pt.X,domA[0],domA[1],domAA[0],domAA[1])
    newPtY=RemapDomainToDomain(pt.Y,domB[0],domB[1],domBB[0],domBB[1])
    if newPtX != None and newPtY != None:
        return Rhino.Geometry.Point3d(newPtX,newPtY,pt.Z)

def MapImageToPointCloud():
    msg="Select a point cloud to map image to"
    pcID=rs.GetObject(msg,2,preselect=True)
    if not pcID: return
    
    msg="Select an image file to map"
    filter = "PNG (*.png)|*.png|JPG (*.jpg)|*.jpg|BMP (*.bmp)|*.bmp|All (*.*)|*.*||"
    rs.Prompt(msg)
    filename = rs.OpenFileName(msg, filter)
    if not filename: return
    # use the System.Drawing.Bitmap class described at
    # [url]http://msdn.microsoft.com/en-us/library/system.drawing.bitmap.aspx[/url]
    img = System.Drawing.Bitmap(filename)
    
    #Get pointcloud bounding box
    bb=rs.BoundingBox(pcID)
    if not bb:
        print "Unable to get pointcloud dimensions"
        return
    
    #can't go to edge... hence the -1
    #image domain starts in upper left corner, point cloud in lower left
    imgDomX=(0,img.Width-1)
    imgDomY=(img.Height-1,0)
    pcDomX=(bb[0][0],bb[1][0])
    pcDomY=(bb[0][1],bb[3][1])
    
    #print info to command line
    prec=scriptcontext.doc.DistanceDisplayPrecision
    pcX=(round(pcDomX[0],prec),round(pcDomX[1],prec))
    pcY=(round(pcDomY[0],prec),round(pcDomY[1],prec))
    print "Point cloud domain: X {} to {} | Y {} to {}".format(pcX[0],pcX[1],pcY[0],pcY[1])
    print "Image pixel dimensions: {} x {}".format(img.Width,img.Height)
    rs.Prompt("Transfering image to point cloud...")
    
    #create a new color point cloud
    pcPts=rs.PointCloudPoints(pcID)
    pc = Rhino.Geometry.PointCloud()
    for pt in pcPts:
        ptIC=Remap2DPointDomain(pt,pcDomX,imgDomX,pcDomY,imgDomY)
        color=img.GetPixel(int(round(ptIC.X)),int(round(ptIC.Y)))
        pc.Add(pt,color)
    rc=scriptcontext.doc.Objects.AddPointCloud(pc)
    #delete original if success
    if rc:
        rs.DeleteObject(pcID)
    scriptcontext.doc.Views.Redraw()
MapImageToPointCloud()