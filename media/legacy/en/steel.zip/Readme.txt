'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' Steel -- September 2008
' If this code works, it was written by Dale Fugier.
' If not, I don't know who wrote it.
' Works with Rhino 4.0.

To use this script, copy the contents of the zip file into a folder found
in Rhino's library search path (the C:\Program Files\Rhinoceros 4.0 folder
is a good location). Then, launch Rhino and then drag 'n drop "Steel.rvb" 
on top of Rhino. Then, enter "Steel..." on the command line to run one of
the steel shape drawing functions. If you are ambitious, you can even
load the Steel.tb toolbar file to you have buttons to click.