""""Create a point cloud retaining the original point colors
Script by Mitch Heynick, version 29 September 2013"""

import rhinoscriptsyntax as rs
import Rhino, scriptcontext

def CreateColorPointCloud():
    msg="Select points to create color point cloud"
    ptIDs=rs.GetObjects(msg,1,preselect=True)
    if not ptIDs: return
    
    pc = Rhino.Geometry.PointCloud()
    pts=rs.coerce3dpointlist(ptIDs)
    for i,pt in enumerate(pts):
        col=rs.ObjectColor(ptIDs[i])
        pc.Add(pt,col)
    rs.DeleteObjects(ptIDs)
    scriptcontext.doc.Objects.AddPointCloud(pc)
    scriptcontext.doc.Views.Redraw()
    
if __name__ == "__main__":
    CreateColorPointCloud()