/////////////////////////////////////////////////////////////////////////////
// TestTabbedDockBarPlugIn.cpp : defines the initialization routines for the plug-in.
//

#include "StdAfx.h"
#include "TestTabbedDockBarPlugIn.h"
#include "TestTabbedDockBarDialog.h"

#pragma warning( push )
#pragma warning( disable : 4073 )
#pragma init_seg( lib )
#pragma warning( pop )

// Rhino plug-in declaration
RHINO_PLUG_IN_DECLARE

// Rhino plug-in name
RHINO_PLUG_IN_NAME( L"TestTabbedDockBar" );

// Rhino plug-in id
RHINO_PLUG_IN_ID( L"9AB292B3-3CBC-4FFB-ABAA-DF5EC90A4C9A" );

// Rhino plug-in version
RHINO_PLUG_IN_VERSION( __DATE__"  "__TIME__ )

// Rhino plug-in developer declarations
RHINO_PLUG_IN_DEVELOPER_ORGANIZATION( L"Robert McNeel & Associates" );
RHINO_PLUG_IN_DEVELOPER_ADDRESS( L"3670 Woodland Park Avenue North\015\012Seattle WA 98103" );
RHINO_PLUG_IN_DEVELOPER_COUNTRY( L"United States" );
RHINO_PLUG_IN_DEVELOPER_PHONE( L"206-545-6877" );
RHINO_PLUG_IN_DEVELOPER_FAX( L"206-545-7321" );
RHINO_PLUG_IN_DEVELOPER_EMAIL( L"tech@mcneel.com" );
RHINO_PLUG_IN_DEVELOPER_WEBSITE( L"http://www.rhino3d.com" );
RHINO_PLUG_IN_UPDATE_URL( L"http://www2.rhino3d.com/sr/plugin.asp?id=9AB292B3-3CBC-4FFB-ABAA-DF5EC90A4C9A" );

// The one and only CTestTabbedDockBarPlugIn object
static CTestTabbedDockBarPlugIn thePlugIn;

/////////////////////////////////////////////////////////////////////////////
// CTestTabbedDockBarPlugIn definition

CTestTabbedDockBarPlugIn& TestTabbedDockBarPlugIn()
{ 
  // Return a reference to the one and only CTestTabbedDockBarPlugIn object
  return thePlugIn; 
}

CTestTabbedDockBarPlugIn::CTestTabbedDockBarPlugIn()
{
  // TODO: Add construction code here
  m_plugin_version = RhinoPlugInVersion();
}

CTestTabbedDockBarPlugIn::~CTestTabbedDockBarPlugIn()
{
  // TODO: Add destruction code here
}

/////////////////////////////////////////////////////////////////////////////
// Required overrides

const wchar_t* CTestTabbedDockBarPlugIn::PlugInName() const
{
  // TODO: Return a short, friendly name for the plug-in.
  return RhinoPlugInName();
}

const wchar_t* CTestTabbedDockBarPlugIn::PlugInVersion() const
{
  // TODO: Return the version number of the plug-in.
  return m_plugin_version;
}

GUID CTestTabbedDockBarPlugIn::PlugInID() const
{
  // {9AB292B3-3CBC-4FFB-ABAA-DF5EC90A4C9A}
  return ON_UuidFromString( RhinoPlugInId() );
}

BOOL CTestTabbedDockBarPlugIn::OnLoadPlugIn()
{
  CRhinoTabbedDockBarDialog::Register( RUNTIME_CLASS(CTestTabbedDockBarDialog), CTestTabbedDockBarDialog::IDD, AfxGetStaticModuleState() );
  return TRUE;
}

void CTestTabbedDockBarPlugIn::OnUnloadPlugIn()
{
}

