using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

using RMA.Rhino;
using RMA.UI;

namespace ExtendObjectProperties
{
  public partial class MyObjectPropertiesPage : UserControl
  {
    public MyObjectPropertiesPage()
    {
      InitializeComponent();
    }

    private void button1_Click(object sender, EventArgs e)
    {
      MessageBox.Show("Button clicked");
    }

    // Called by CMyObjectPropertiesDialogPage
    public void InitControls(IRhinoObject new_obj)
    {
    }

    // Called by CMyObjectPropertiesDialogPage
    public bool AddPageToControlBar(IRhinoObject obj)
    {
      return true;
    }

    // Called by CMyObjectPropertiesDialogPage
    public IRhinoCommand.result RunScript(IRhinoObject[] objects)
    {
      return IRhinoCommand.result.success;
    }
  }
}
