#pragma once

#include "Resource.h"

class CTestModalDialog : public CDialog
{
public:
	CTestModalDialog(CWnd* pParent);

	//{{AFX_DATA(CTestModalDialog)
	enum { IDD = IDD_DIALOG1 };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CTestModalDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CTestModalDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnAddLine();
	afx_msg void OnAddCircle();
	afx_msg void OnAddPoints();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
