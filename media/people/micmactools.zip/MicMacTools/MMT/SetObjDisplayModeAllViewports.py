"""Sets a custom display mode for one or more objects in all viewports
User can choose display mode from a list box
Script by Mitch Heynick 17 February 2014"""

"""Note the list box method currently only runs on Windows, 
so a GetString method has been substituted when running on Mac"""

import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def SetObjDisplayModeAllViewports():
    msg="Select objects to set display mode"
    objIDs=rs.GetObjects(msg,8+16+32,preselect=True)
    if not objIDs: return
    
    dModes = Rhino.Display.DisplayModeDescription.GetDisplayModes()
    modeNames=[dMode.LocalName for dMode in dModes if not dMode.PipelineLocked]
    msg="Choose a display mode for objects"
    
    #For Mac, set up string box, otherwise use listbox for Windows
    if Rhino.Runtime.HostUtils.RunningOnOSX:
        modeName=rs.GetString(msg,strings=modeNames)
        if not modeName: return
        
        #check for valid string
        stringmatch=False
        for name in modeNames:
            if name==modeName:
                stringmatch=True ; break
        if not stringmatch: return
    else:
        modeName=rs.ListBox(modeNames,msg,"Display Mode List")
        if not modeName: return
    
    for i in range(len(modeNames)):
        if modeName==modeNames[i]: break
        
    vIDs=[view.ActiveViewportID for view in sc.doc.Views]
    
    for vID in vIDs:
        for objID in objIDs:
            objRef=sc.doc.Objects.Find(objID)
            attr = objRef.Attributes
            attr.SetDisplayModeOverride(dModes[i], vID)
            sc.doc.Objects.ModifyAttributes(objID, attr, False)
    sc.doc.Views.Redraw()
    
SetObjDisplayModeAllViewports()