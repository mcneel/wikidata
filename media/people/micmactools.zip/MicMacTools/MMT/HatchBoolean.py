"""Script to do Boolean operations with hatches
Uses Rhino's CurveBoolean method to determine new borders
Script by Mitch Heynick, version 02.07.15"""

import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def HatchBoolean():
    hatchIDs=rs.GetObjects("Select hatches",65536,preselect=True)
    if not hatchIDs: return
    layers=set()
    for hatchID in hatchIDs: layers.add(rs.ObjectLayer(hatchID))
    if len(layers)==1:
        #result can go to original layer
        orig_layer=layers.pop()
    else:
        #result goes to current layer
        orig_layer=None
    patt=rs.HatchPattern(hatchIDs[0])
    scale=rs.HatchScale(hatchIDs[0])
    rot=rs.HatchRotation(hatchIDs[0])
    
    hatches=[rs.coercegeometry(ID) for ID in hatchIDs]
    hatchBords=[]
    for hatch in hatches:
        hatchBords.extend(hatch.Get3dCurves(True))
        hatchBords.extend(hatch.Get3dCurves(False))
    bordIDs=[]
    for i in range(len(hatchBords)):
        bordIDs.append(sc.doc.Objects.AddCurve(hatchBords[i]))
    rs.UnselectAllObjects()
    rs.LockObjects(hatchIDs)
    rs.SelectObjects(bordIDs)
    rs.Command("_CurveBoolean _DeleteInput=_All _CombineRegions=Yes",False)
    rs.EnableRedraw(False)
    if rs.LastCommandResult()==0:
        newBords=rs.LastCreatedObjects()
        if len(newBords)>0:
            for hatchID in hatchIDs: sc.doc.Objects.Unlock(hatchID,False)
            sc.doc.Objects.Delete(hatchIDs,False)
            new_hatches=rs.AddHatches(newBords,patt,scale,rot)
            if new_hatches and orig_layer:
                for hatch in new_hatches: rs.ObjectLayer(hatch,orig_layer)
            rs.DeleteObjects(newBords)
    try:
        rs.DeleteObjects(bordIDs)
        rs.UnlockObjects(hatchIDs)
    except: pass
HatchBoolean()