Public Class Bond
    Public Father As Int32 = -1
    Public Mother As Int32 = -1

    Public Sub New(ByVal nFather As Int32, ByVal nMother As Int32)
        Father = nFather
        Mother = nMother
    End Sub

    Public Function IsEqualTo(ByVal sBond As Bond) As Boolean
        If Father = sBond.Father And Mother = sBond.Mother Or _
           Father = sBond.Mother And Mother = sBond.Father Then Return True
        Return False
    End Function

    Public Function CastOnLine(ByVal aFather As Atom, ByVal aMother As Atom) As RMA.OpenNURBS.OnLine
        Return New RMA.OpenNURBS.OnLine(aFather.CastONPoint, aMother.CastONPoint)
    End Function

    Public Function CastOnMesh(ByVal aFather As Atom, ByVal aMother As Atom, _
                               Optional ByVal iRadius As Double = 0.5, _
                               Optional ByVal iSegments As Int32 = 10) As RMA.OpenNURBS.IOnMesh
        Return GeometryLibrary.MeshPipe(New RMA.OpenNURBS.On3dPoint(aFather.x, aFather.y, aFather.z), _
                                        New RMA.OpenNURBS.On3dPoint(aMother.x, aMother.y, aMother.z), _
                                        iRadius, iSegments)

    End Function

    Public Function CastOnNurbs(ByVal aFather As Atom, ByVal aMother As Atom, _
                               Optional ByVal iRadius As Double = 0.5) As RMA.OpenNURBS.IOnSurface
        Return GeometryLibrary.NurbsPipe(New RMA.OpenNURBS.On3dPoint(aFather.x, aFather.y, aFather.z), _
                                         New RMA.OpenNURBS.On3dPoint(aMother.x, aMother.y, aMother.z), iRadius)
    End Function

    Public Function CreateDefaultName(ByVal aFather As Atom, ByVal aMother As Atom) As String
        'Bond(FatherElement-MotherElement[FatherSerial-MotherSerial])@FatherMolecule Chain:A Residue:AAA
        Dim Name As String = String.Format("Bond({0}-{1}", _
                             Definitions.ToElementName(aFather.ElementType), _
                             Definitions.ToElementName(aMother.ElementType))
        Name &= String.Format("[{0}-{1}])@{2} ", _
                             aFather.SerialNumber, aMother.SerialNumber, aFather.MoleculeNumber)
        Name &= String.Format("Chain:{0} Residue:{1} ", aFather.Chain, aFather.Residue)
        Return Name
    End Function
End Class
