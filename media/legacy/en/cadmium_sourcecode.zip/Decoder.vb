Public Module Decoder
    Public Function ExtractAtomElement(ByVal nAtomName As String) As String
        Dim iFind(1) As Int32
        iFind(0) = InStr(nAtomName, "Atom(", CompareMethod.Text)
        If iFind(0) < 1 Then Return ""
        iFind(0) += 5
        iFind(1) = InStr(iFind(0), nAtomName, "[", CompareMethod.Text)
        If iFind(1) < 1 Then Return ""

        Return Mid(nAtomName, iFind(0), iFind(1) - iFind(0))
    End Function

    Public Function ExtractAtomResidue(ByVal nAtomName As String) As String
        Dim iFind(1) As Int32
        iFind(0) = InStr(nAtomName, "Residue:", CompareMethod.Text)
        If iFind(0) < 1 Then Return ""
        iFind(0) += 8
        iFind(1) = InStr(iFind(0), nAtomName, " TempFactor:", CompareMethod.Text)
        If iFind(1) < 1 Then Return ""

        Return Mid(nAtomName, iFind(0), iFind(1) - iFind(0))
    End Function

    Public Function ExtractAtomChain(ByVal nAtomName As String) As String
        Dim iFind(1) As Int32
        iFind(0) = InStr(nAtomName, "Chain:", CompareMethod.Text)
        If iFind(0) < 1 Then Return ""
        iFind(0) += 2
        iFind(1) = InStr(iFind(0), nAtomName, " Residue:", CompareMethod.Text)
        If iFind(1) < 1 Then Return ""

        Return Mid(nAtomName, iFind(0), iFind(1) - iFind(0))
    End Function

    Public Function ExtractAtomMolecule(ByVal nAtomName As String) As String
        Dim iFind(1) As Int32
        iFind(0) = InStr(nAtomName, "@", CompareMethod.Text)
        If iFind(0) < 1 Then Return ""
        iFind(0) += 1
        iFind(1) = InStr(iFind(0), nAtomName, " Chain:", CompareMethod.Text)
        If iFind(1) < 1 Then Return ""

        Return Mid(nAtomName, iFind(0), iFind(1) - iFind(0))
    End Function

    Public Function StripNonAlpha(ByVal sString As String) As String
        If Len(sString) = 0 Then Return ""
        Dim iString As String
        Dim i As Int32
        Dim iChar As Char

        For i = 1 To Len(sString)
            iChar = Mid(sString, i, 1)
            If Asc(iChar) >= 65 And Asc(iChar) <= 90 Then
                iString &= iChar
            End If
        Next
        Return iString
    End Function

    Public Function StripDuplicateSpaces(ByVal sString As String) As String
        If Len(sString) = 0 Then Return ""
        Dim iString As String = Trim(sString)
        Dim i As Int32

        'hmm.. a bit nasty
        For i = 1 To 50
            iString = Replace(iString, "  ", " ")
        Next

        Return iString
    End Function
End Module
