Imports System
Imports System.Collections
Imports System.Runtime.InteropServices

<ComVisible(True)> _
Public Class TestRhinoScriptObject

  Public Shared ReadOnly ObjectId As System.Guid = New System.Guid("{D0E1D541-F1AD-4A3B-A6D4-C191EA8D7245}")

  Public Function Hello() As Object
    Dim str As String = "Hello from TestRhino!"
    Return str
  End Function

  Public Function Echo(ByVal obj As Object) As Object
    Dim str As String = TryCast(obj, String)
    If (str IsNot Nothing) Then
      Return str
    Else
      Return String.Empty
    End If
  End Function

End Class
