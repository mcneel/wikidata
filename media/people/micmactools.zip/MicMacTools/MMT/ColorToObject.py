import rhinoscriptsyntax as rs

def ColorToObject():
    msg="Select objects to color by object"
    objs=rs.GetObjects(msg,preselect=True)
    if not objs: return
    rs.EnableRedraw(False)
    for obj in objs:
        cs=rs.ObjectColorSource(obj)
        if cs!=1:
            color=rs.ObjectColor(obj)
            rs.ObjectColorSource(obj,1)
            rs.ObjectColor(obj,color)
ColorToObject()