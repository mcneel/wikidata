import rhinoscriptsyntax as rs

def to_filt(rhino_object, geometry, component_index):
    return rs.IsText(geometry)

def SelTextByHeight():
    msg="Select text object with height to match"
    comp_txt=rs.GetObject(msg,512,preselect=True,custom_filter=to_filt)
    if not comp_txt: return
    font_ht=rs.TextObjectHeight(comp_txt)
    
    all_ann=rs.ObjectsByType(512,state=1)
    txt_objs=[obj for obj in all_ann if rs.IsText(obj)]
    tol=rs.UnitAbsoluteTolerance()
    prec=rs.UnitDistanceDisplayPrecision()
    rs.UnselectAllObjects()
    n=0
    rs.EnableRedraw(False)
    for obj in txt_objs:
        if abs(rs.TextObjectHeight(obj)-font_ht)<tol:
            rs.SelectObject(obj)
            n+=1
    ht=round(font_ht,prec)
    if n == 1: print "No other text objects with font height={} found".format(ht)
    else: print "Found {} text objects with font height={}".format(n,ht)
SelTextByHeight()