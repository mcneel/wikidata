#include "StdAfx.h"


/////////////////////////////////////////////////////////////////////////////
// CRhinoGetTranslationPoint class
//

class CRhinoGetTranslationPoint : public CRhinoGetPoint
{
public:
	CRhinoGetTranslationPoint();
	~CRhinoGetTranslationPoint() {}

	void AddObject(const CRhinoObject* object);
  void SetBasePoint( ON_3dPoint base_point, BOOL bShowDistanceInStatusBar = false );
  void OnMouseMove( CRhinoViewport& vp, UINT flags, const ON_3dPoint& pt, const CPoint* p );
  void DynamicDraw( HDC hdc, CRhinoViewport& vp, const ON_3dPoint& pt );
	void CalculateTranslation( const ON_3dPoint& pt, ON_Xform& xform );

private:
	ON_3dPoint m_start_point;
	ON_Xform m_xform;
  ON_SimpleArray<const CRhinoObject*> m_objects;
};

CRhinoGetTranslationPoint::CRhinoGetTranslationPoint()
{
	m_xform.Identity();
}

void CRhinoGetTranslationPoint::AddObject( const CRhinoObject* object )
{
	m_objects.Append( object );
}

void CRhinoGetTranslationPoint::SetBasePoint( ON_3dPoint base_point, BOOL bShowDistanceInStatusBar )
{
  m_start_point = base_point;
  CRhinoGetPoint::SetBasePoint( base_point, bShowDistanceInStatusBar );
}

void CRhinoGetTranslationPoint::CalculateTranslation( const ON_3dPoint& pt, ON_Xform& xform )
{
	ON_3dVector v = pt - m_start_point;
	if( v.IsTiny() )
		xform.Identity();
	else
		xform.Translation( v );
}

void CRhinoGetTranslationPoint::OnMouseMove( CRhinoViewport& vp, UINT flags, const ON_3dPoint& pt, const CPoint* p )
{
  CalculateTranslation( pt, m_xform );
  CRhinoGetPoint::OnMouseMove( vp, flags, pt, p );
}

void CRhinoGetTranslationPoint::DynamicDraw( HDC hdc, CRhinoViewport& vp, const ON_3dPoint& pt )
{
	int i, count = m_objects.Count();

	if( m_xform.IsIdentity() == false && count > 0 )
	{
	  ON_Color saved_color = vp.DrawColor();

    ON_Xform saved_model_xform;
    vp.GetModelXform( saved_model_xform );
    vp.SetModelXform( m_xform );

    for( i = 0; i < m_objects.Count(); i++ )
    {
      const CRhinoObject* object = m_objects[i];
      if( object == 0 )
				continue;

      vp.SetDrawColor( object->ObjectDrawColor(TRUE) );
      object->Draw( vp );
      
			if( vp.InterruptDrawing() )
				break;
    }

    vp.SetModelXform( saved_model_xform );
		vp.SetDrawColor( saved_color );
  }

  CRhinoGetPoint::DynamicDraw( hdc, vp, pt );
}


/////////////////////////////////////////////////////////////////////////////
// CCommandTestMove command
//

class CCommandTestMove : public CRhinoCommand
{
public:
	CCommandTestMove() {}
	~CCommandTestMove() {}

	UUID CommandUUID()
	{
		// {1C612313-9C71-44CB-8E36-21145FFA5DFF}
		static const GUID TestMoveCommand_UUID =
		{ 0x1C612313, 0x9C71, 0x44CB, { 0x8E, 0x36, 0x21, 0x14, 0x5F, 0xFA, 0x5D, 0xFF } };
		return TestMoveCommand_UUID;
	}

	const wchar_t* EnglishCommandName() { return L"TestMove"; }
	const wchar_t* LocalCommandName() { return L"TestMove"; }

	CRhinoCommand::result RunCommand( const CRhinoCommandContext& );
};

static class CCommandTestMove theTestMoveCommand;

CRhinoCommand::result CCommandTestMove::RunCommand( const CRhinoCommandContext& context )
{
	int i;

	CRhinoGetObject go;
	go.SetCommandPrompt( L"Select objects to move" );
	go.GetObjects( 1, 0 );
	if( go.CommandResult() != CRhinoCommand::success )
		return go.CommandResult();

	CRhinoGetPoint gp;
	gp.SetCommandPrompt( L"Point to move from" );
	gp.GetPoint();
	if( gp.CommandResult() != CRhinoCommand::success )
		return gp.CommandResult();

	CRhinoGetTranslationPoint gt;
	gt.SetCommandPrompt( L"Point to move to" );
	gt.SetBasePoint( gp.Point() );
	gt.DrawLineFromPoint( gp.Point(), TRUE );
	for( i = 0; i < go.ObjectCount(); i++ )
		gt.AddObject( go.Object(i).Object() );
	gt.GetPoint();
	if( gt.CommandResult() != CRhinoCommand::success )
		return gp.CommandResult();

	ON_Xform xform;
	gt.CalculateTranslation( gt.Point(), xform );
	if( xform.IsIdentity() )
		return CRhinoCommand::nothing;

	for( i = 0; i < go.ObjectCount(); i++ )
		context.m_doc.TransformObject( go.Object(i), xform );
	context.m_doc.Redraw();

	return CRhinoCommand::success;
}
