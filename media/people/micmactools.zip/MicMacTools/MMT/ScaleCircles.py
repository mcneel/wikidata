import rhinoscriptsyntax as rs
import scriptcontext as sc
"""Scales circles about their centers.  Script by Mitch Heynick 26.08.15"""

def circ_filt(rhino_object, geometry, component_index):
    return geometry.IsCircle()

def ScaleCircles():
    if "SC_ScaleFactor" in sc.sticky: osf = sc.sticky["SC_ScaleFactor"]
    else: osf = 1.0
    
    msg1="Select circles to scale about centers"
    tol=rs.UnitAbsoluteTolerance()
    objs=rs.GetObjects(msg1,4,preselect=True,custom_filter=circ_filt)
    if not objs: return
    
    sf=rs.GetReal("Scale factor for objects?",osf,minimum=tol)
    if not sf: return
    
    rs.EnableRedraw(False)
    for obj in objs:
        rs.ScaleObject(obj,rs.CircleCenterPoint(obj),[sf,sf,sf],False) 
    print "Scaled {} circles by a factor of {}".format(len(objs),sf)
    sc.sticky["SC_ScaleFactor"] = sf
ScaleCircles()