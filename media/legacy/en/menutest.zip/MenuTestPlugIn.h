/////////////////////////////////////////////////////////////////////////////
// MenuTestPlugIn.h
//

#if !defined(AFX_MENUTESTPLUGIN_H__C03AA821_3FF7_4CCA_A99C_BB41B56F92B7__INCLUDED_)
#define AFX_MENUTESTPLUGIN_H__C03AA821_3FF7_4CCA_A99C_BB41B56F92B7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMenuTestPlugIn
// See MenuTestPlugIn.cpp for the implementation of this class.
//

class CMenuTestPlugIn : public CRhinoUtilityPlugIn
{
public:
  CMenuTestPlugIn();
  ~CMenuTestPlugIn() {}

  const wchar_t* PlugInName() const { return L"MenuTest"; }
  const wchar_t* PlugInVersion() const { return m_plugin_version; }

  GUID PlugInID() const;

  BOOL OnLoadPlugIn();
  void OnUnloadPlugIn();
  BOOL CanUnLoad() { return TRUE; }

  BOOL AddToPlugInHelpMenu() const { return TRUE; }
  BOOL OnDisplayPlugInHelp( HWND ) const;

  void OnInitPlugInMenuPopups( WPARAM, LPARAM );
  BOOL OnPlugInMenuCommand( WPARAM );

private:
  ON_wString m_plugin_version;
  CMenu m_menu;
  bool m_script_mode;
};

CMenuTestPlugIn& MenuTestPlugIn();

#endif // !defined(AFX_MENUTESTPLUGIN_H__C03AA821_3FF7_4CCA_A99C_BB41B56F92B7__INCLUDED_)


