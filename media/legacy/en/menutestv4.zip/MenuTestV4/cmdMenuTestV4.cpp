#include "StdAfx.h"
#include "MenuTestV4PlugIn.h"

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//
// BEGIN mtCommand1 command
//

class CCommandmtCommand1 : public CRhinoCommand
{
public:
	CCommandmtCommand1() {}
	~CCommandmtCommand1() {}
	UUID CommandUUID()
	{
		// {4FFC8A52-48DE-4EEC-BED9-C1FECDDEE272}
		static const GUID mtCommand1Command_UUID =
		{ 0x4FFC8A52, 0x48DE, 0x4EEC, { 0xBE, 0xD9, 0xC1, 0xFE, 0xCD, 0xDE, 0xE2, 0x72 } };
		return mtCommand1Command_UUID;
	}
	const wchar_t* EnglishCommandName() { return L"mtCommand1"; }
	CRhinoCommand::result RunCommand( const CRhinoCommandContext& );
};

// The one and only CCommandmtCommand1 object
static class CCommandmtCommand1 themtCommand1Command;

CRhinoCommand::result CCommandmtCommand1::RunCommand( const CRhinoCommandContext& context )
{
  if( context.IsInteractive() )
    RhinoApp().Print( L"mtCommand1 called - interactive mode\n");
  else
    RhinoApp().Print( L"mtCommand1 called - scripted mode\n");
	return CRhinoCommand::success;
}

//
// END mtCommand1 command
//
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//
// BEGIN mtCommand2 command
//

class CCommandmtCommand2 : public CRhinoCommand
{
public:
	CCommandmtCommand2() {}
	~CCommandmtCommand2() {}
	UUID CommandUUID()
	{
		// {9F2338B7-9287-477D-903D-5F2D0EFD0D11}
		static const GUID mtCommand2Command_UUID =
		{ 0x9F2338B7, 0x9287, 0x477D, { 0x90, 0x3D, 0x5F, 0x2D, 0x0E, 0xFD, 0x0D, 0x11 } };
		return mtCommand2Command_UUID;
	}
	const wchar_t* EnglishCommandName() { return L"mtCommand2"; }
	CRhinoCommand::result RunCommand( const CRhinoCommandContext& );
};

// The one and only CCommandmtCommand2 object
static class CCommandmtCommand2 themtCommand2Command;

CRhinoCommand::result CCommandmtCommand2::RunCommand( const CRhinoCommandContext& context )
{
  if( context.IsInteractive() )
    RhinoApp().Print( L"mtCommand2 called - interactive mode\n");
  else
    RhinoApp().Print( L"mtCommand2 called - scripted mode\n");

  return CRhinoCommand::success;
}

//
// END mtCommand2 command
//
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
