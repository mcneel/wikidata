#pragma once

#include "Resource.h"

class CTestModelessDialog : public CDialog
{
public:
	CTestModelessDialog(CWnd* pParent = NULL);

	//{{AFX_DATA(CTestModelessDialog)
	enum { IDD = IDD_DIALOG2 };
	CButton	m_undo;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CTestModelessDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CTestModelessDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnAddLine();
	afx_msg void OnAddCircle();
	afx_msg void OnAddPoints();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
