Public Class InflectionPointsPlugInAttributes
  Inherits RMA.Rhino.MRhinoPlugInAttributes

  Public Overrides Function Address() As String
    Return "Linnankatu 26A" & vbCrLf & "20100 Turku"
  End Function

  Public Overrides Function Country() As String
    Return "Finland"
  End Function

  Public Overrides Function Email() As String
    Return "david@mcneel.com"
  End Function

  Public Overrides Function Fax() As String
    Return "undefined"
  End Function

  Public Overrides Function Organization() As String
    Return "Robert McNeel & Associates"
  End Function

  Public Overrides Function Phone() As String
    Return "undefined"
  End Function

  Public Overrides Function UpdateURL() As String
    Return "http://www.Rhino3d.com"
  End Function

  Public Overrides Function Website() As String
    Return "http://www.Rhino3d.com"
  End Function
End Class