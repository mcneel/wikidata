/////////////////////////////////////////////////////////////////////////////
// MenuTestV4PlugIn.cpp : defines the initialization routines for the plug-in.
//

#include "StdAfx.h"
#include "MenuTestV4PlugIn.h"
#include "resource.h"

// The plug-in object must be constructed before any plug-in classes
// derived from CRhinoCommand. The #pragma init_seg(lib) ensures that
// this happens.

#pragma warning( push )
#pragma warning( disable : 4073 )
#pragma init_seg( lib )
#pragma warning( pop )

// Rhino plug-in declaration
RHINO_PLUG_IN_DECLARE

// Rhino plug-in developer declarations
RHINO_PLUG_IN_DEVELOPER_ORGANIZATION( L"Robert McNeel & Associates" );
RHINO_PLUG_IN_DEVELOPER_ADDRESS( L"3670 Woodland Park Ave N\r\nSeattle, WA 98103" );
RHINO_PLUG_IN_DEVELOPER_COUNTRY( L"United States" );
RHINO_PLUG_IN_DEVELOPER_PHONE( L"206-545-7000" );
RHINO_PLUG_IN_DEVELOPER_FAX( L"206-545-7321" );
RHINO_PLUG_IN_DEVELOPER_EMAIL( L"tech@mcneel.com" );
RHINO_PLUG_IN_DEVELOPER_WEBSITE( L"http://www.rhino3d.com" );
RHINO_PLUG_IN_UPDATE_URL( L"ftp://ftp.rhino3d.com/updateme.cab" );

// The one and only CMenuTestV4PlugIn object
static CMenuTestV4PlugIn thePlugIn;

/////////////////////////////////////////////////////////////////////////////
// CMenuTestV4PlugIn definition

CMenuTestV4PlugIn& MenuTestV4PlugIn()
{ 
  // Return a reference to the one and only CMenuTestV4PlugIn object
  return thePlugIn; 
}

CMenuTestV4PlugIn::CMenuTestV4PlugIn()
: m_script_mode(false)
{
  // Description:
  //   CMenuTestV4PlugIn constructor. The constructor is called when the
  //   plug-in is loaded and "thePlugIn" is constructed. Once the plug-in
  //   is loaded, CMenuTestV4PlugIn::OnLoadPlugIn() is called. The 
  //   constructor should be simple and solid. Do anything that might fail in
  //   CMenuTestV4PlugIn::OnLoadPlugIn().

  // TODO: Add construction code here
  m_plugin_version = __DATE__"  "__TIME__;
}

CMenuTestV4PlugIn::~CMenuTestV4PlugIn()
{
  // Description:
  //   CMenuTestV4PlugIn destructor. The destructor is called to destroy
  //   "thePlugIn" when the plug-in is unloaded. Immediately before the
  //   DLL is unloaded, CMenuTestV4PlugIn::OnUnloadPlugin() is called. Do
  //   not do too much here. Be sure to clean up any memory you have allocated
  //   with onmalloc(), onrealloc(), oncalloc(), or onstrdup().

  // TODO: Add destruction code here
}

/////////////////////////////////////////////////////////////////////////////
// Required overrides

const wchar_t* CMenuTestV4PlugIn::PlugInName() const
{
  // Description:
  //   Plug-in name display string.  This name is displayed by Rhino when
  //   loading the plug-in, in the plug-in help menu, and in the Rhino 
  //   interface for managing plug-ins.

  // TODO: Return a short, friendly name for the plug-in.
  return L"MenuTestV4";
}

const wchar_t* CMenuTestV4PlugIn::PlugInVersion() const
{
  // Description:
  //   Plug-in version display string. This name is displayed by Rhino 
  //   when loading the plug-in and in the Rhino interface for managing
  //   plug-ins.

  // TODO: Return the version number of the plug-in.
  return m_plugin_version;
}

GUID CMenuTestV4PlugIn::PlugInID() const
{
  // Description:
  //   Plug-in unique identifier. The identifier is used by Rhino to
  //   manage the plug-ins.

  // TODO: Return a unique identifier for the plug-in.
  // {B11415F6-9BE3-40E2-AFCA-B59D1DF71D93}
  static const GUID MenuTestV4PlugIn_UUID =
  { 0xB11415F6, 0x9BE3, 0x40E2, { 0xAF, 0xCA, 0xB5, 0x9D, 0x1D, 0xF7, 0x1D, 0x93 } };
  return MenuTestV4PlugIn_UUID;
}

BOOL CMenuTestV4PlugIn::OnLoadPlugIn()
{
  // Description:
  //   Called after the plug-in is loaded and the constructor has been
  //   run. This is a good place to perform any significant initialization,
  //   license checking, and so on.  This function must return TRUE for
  //   the plug-in to continue to load.
  AFX_MANAGE_STATE( AfxGetStaticModuleState() );

  if( m_menu.LoadMenu(IDR_MENUTEST) )
    InsertPlugInMenuToRhinoMenu( m_menu.GetSafeHmenu(), 0);


  // TODO: Add plug-in initialization code here.
  return CRhinoUtilityPlugIn::OnLoadPlugIn();
}

void CMenuTestV4PlugIn::OnUnloadPlugIn()
{
  // Description:
  //   Called when the plug-in is about to be unloaded.  After
  //   this function is called, the destructor will be called.

  RemovePlugInMenuFromRhino( ::GetSubMenu(m_menu.GetSafeHmenu(), 0) );

  CRhinoUtilityPlugIn::OnUnloadPlugIn();
}

/////////////////////////////////////////////////////////////////////////////
// Online help overrides

BOOL CMenuTestV4PlugIn::AddToPlugInHelpMenu() const
{
  // Description:
  //   Return true to have your plug-in name added to the Rhino help menu.
  //   OnDisplayPlugInHelp will be called when to activate your plug-in help.

  return TRUE;
}

BOOL CMenuTestV4PlugIn::OnDisplayPlugInHelp( HWND hWnd ) const
{
  // Description:
  //   Called when the user requests help about your plug-in.
  //   It should display a standard Windows Help file (.hlp or .chm).

  // TODO: Add support for online help here.
  return CRhinoUtilityPlugIn::OnDisplayPlugInHelp( hWnd );
}

void CMenuTestV4PlugIn::OnInitPlugInMenuPopups( WPARAM wParam, LPARAM )
{
  HMENU hMenu = (HMENU)wParam;
  UINT uCheck = MF_BYCOMMAND;
  if( m_script_mode )
    uCheck |= MF_CHECKED;
  else
    uCheck |= MF_UNCHECKED;

  ::CheckMenuItem( hMenu, ID_TESTMENU_SCRIPTMODE, uCheck );
}

BOOL CMenuTestV4PlugIn::OnPlugInMenuCommand( WPARAM wParam )
{
  switch( wParam )
  {
  case ID_TESTMENU_TESTCOMMAND1:
    {
      if( m_script_mode )
        RhinoApp().RunScript( L"_-mtCommand1" );
      else
        RhinoApp().RunScript( L"_mtCommand1" );
    }
    break;

  case ID_TESTMENU_TESTCOMMAND2:
    {
      if( m_script_mode )
        RhinoApp().RunScript( L"_-mtCommand2" );
      else
        RhinoApp().RunScript( L"_mtCommand2" );
    }
    break;

  case ID_TESTMENU_SCRIPTMODE:
    m_script_mode = (m_script_mode) ? false : true;
    break;

  default:
    return FALSE;
  }

  return TRUE;
}
