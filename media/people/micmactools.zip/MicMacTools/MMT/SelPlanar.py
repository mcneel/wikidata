import rhinoscriptsyntax as rs
#selects planar curves and surfaces
entity="planar"
e2="curve"
e3="surface"
cc=0 ; sc=0
err_msg="No {} {}s or {}s added to selection".format(entity,e2,e3) 
objs=rs.ObjectsByType(4+8,state=1)
if objs:
    select=[]
    for obj in objs:
        if rs.IsCurve(obj) and rs.IsCurvePlanar(obj):
            select.append(obj)
            cc+=1
        elif rs.IsSurface(obj) and rs.IsSurfacePlanar(obj):
            select.append(obj)
            sc+=1
    if select:
        rs.EnableRedraw(False)
        rs.SelectObjects(select)
        if cc==0: cc="No"
        if cc !=1: e2+="s"
        if sc==0: sc="no"
        if sc !=1: e3+="s"
        #if len(select)>1: entity+="s"
        print "{} planar {} and {} planar {} added to selection".format(cc,e2,sc,e3)
    else: print err_msg
else: print err_msg