import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def to_filt(rhino_object, geometry, component_index):
    return rs.IsText(geometry)

def SelTextByFont():
    msg="Select text object with font to match"
    comp_txt=rs.GetObject(msg,512,preselect=True,custom_filter=to_filt)
    if not comp_txt: return
    comp_font=rs.TextObjectFont(comp_txt)
    
    all_ann=rs.ObjectsByType(512,state=1)
    txt_objs=[obj for obj in all_ann if rs.IsText(obj)]
    rs.UnselectAllObjects()
    n=0
    rs.EnableRedraw(False)
    for obj in txt_objs:
        if rs.TextObjectFont(obj)==comp_font:
            rs.SelectObject(obj)
            n+=1
    if n == 1: print "No other text objects with {} font found".format(comp_font)
    else: print "Found {} text objects with {} font".format(n,comp_font)
SelTextByFont()