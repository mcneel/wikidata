"""Splits selected objects with active CPlane. Objects can be curves, surfaces, 
polysurfaces or meshes. Script by Mitch Heynick version 02.07.15
Future: Use RhinoCommon virtual geometry for splitting."""

import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def GetObjAttrs(obj):
    source_attr = Rhino.DocObjects.ObjectAttributes()
    source = rs.coercerhinoobject(obj, True, True)
    source_attr = source.Attributes
    return source_attr
    
def AssignObjAttrs(obj,attr):
    sc.doc.Objects.ModifyAttributes(obj, attr, True)

def SplitCurveWithPlane(crv,plane):
    splitParts=[]
    pars=[]
    intRes=rs.PlaneCurveIntersection(plane,crv)
    if intRes:
        for i in range(len(intRes)):
            #rs.AddPoint(intRes[i][1]) #debug
            pars.append(intRes[i][5])
            if intRes[i][0]==2:
                #rs.AddPoint(intRes[i][2]) #debug
                pars.append(intRes[i][6])
        splitRes=(rs.SplitCurve(crv,pars,True))
        if splitRes:
            splitParts=[splitRes[j] for j in range(len(splitRes))]
    return splitParts
    
def SplitBrepWithPlaneSrf(brep,planeSrf):
    splitParts=[]
    splitRes=rs.SplitBrep(brep,planeSrf,True)
    if splitRes:
        splitParts=[splitRes[j] for j in range(len(splitRes))]
    return splitParts
    
def SplitMeshWithPlaneMesh(mesh,planeMesh):
    splitParts=[]
    splitRes=rs.MeshBooleanSplit(mesh,planeMesh,True)
    if splitRes:
        splitParts=[splitRes[j] for j in range(len(splitRes))]
    return splitParts
    
def SplitObjsWithCPlane():
    msg="Select curves, surfaces or meshes to split with current CPlane"
    objs=rs.GetObjects(msg,4+8+16+32,preselect=True)
    if not objs: return
    currCP=rs.ViewCPlane()
    rs.EnableRedraw(False)
    bb=rs.BoundingBox(objs,currCP)
    rect=rs.AddPolyline([bb[0],bb[1],bb[2],bb[3],bb[0]])
    xForm=rs.XformPlanarProjection(currCP)
    rect=rs.TransformObject(rect,xForm,False)
    planeSrf=rs.AddPlanarSrf(rect)
    planeMesh=rs.AddPlanarMesh(rect)
    rs.DeleteObject(rect)
    splitResult=[]
    for obj in objs:
        obj_attrs=GetObjAttrs(obj)
        if rs.IsCurve(obj):
            splitRes=SplitCurveWithPlane(obj,currCP)
            if splitRes:
                for res in splitRes:
                    AssignObjAttrs(res,obj_attrs)
                    splitResult.append(res)
        elif rs.IsBrep(obj):
            splitRes=SplitBrepWithPlaneSrf(obj,planeSrf)
            if splitRes:
                for res in splitRes:
                    AssignObjAttrs(res,obj_attrs)
                    splitResult.append(res)
        elif rs.IsMesh(obj):
            splitRes=SplitMeshWithPlaneMesh(obj,planeMesh)
            if splitRes:
                for res in splitRes:
                    AssignObjAttrs(res,obj_attrs)
                    splitResult.append(res)
    rs.DeleteObjects([planeSrf,planeMesh])
    if splitResult:
        rs.SelectObjects(splitResult)
    
SplitObjsWithCPlane()