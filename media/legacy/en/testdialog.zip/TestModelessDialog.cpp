#include "StdAfx.h"
#include "TestDialog.h"
#include "TestModelessDialog.h"
#include "TestDialogPlugIn.h"

CTestModelessDialog::CTestModelessDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CTestModelessDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestModelessDialog)
	//}}AFX_DATA_INIT
}

void CTestModelessDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestModelessDialog)
	DDX_Control(pDX, IDC_CHECK1, m_undo);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestModelessDialog, CDialog)
	//{{AFX_MSG_MAP(CTestModelessDialog)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON1, OnAddLine)
	ON_BN_CLICKED(IDC_BUTTON2, OnAddCircle)
	ON_BN_CLICKED(IDC_BUTTON3, OnAddPoints)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CTestModelessDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	return TRUE;
}

void CTestModelessDialog::PostNcDestroy() 
{
	CDialog::PostNcDestroy();
	delete this;
}

void CTestModelessDialog::OnDestroy() 
{
	CDialog::OnDestroy();
	TestDialogPlugIn().DestroyDialog();
}

void CTestModelessDialog::OnOK() 
{
	DestroyWindow();
}

void CTestModelessDialog::OnCancel() 
{
	DestroyWindow();
}

void CTestModelessDialog::OnAddLine() 
{
  CRhinoDoc* doc = ::RhinoApp().ActiveDoc();
  if( doc )
  {
    if( m_undo.GetCheck() )
      doc->BeginUndoRecord( L"TestModelessDialog" );

    ON_Line line( ON_3dPoint(10,10,0), ON_3dPoint(20,20,0) );
    doc->AddCurveObject( line );
    doc->Redraw();

    if( m_undo.GetCheck() )
      doc->EndUndoRecord();
  }
}

void CTestModelessDialog::OnAddCircle() 
{
  CRhinoDoc* doc = ::RhinoApp().ActiveDoc();
  if( doc )
  {
    if( m_undo.GetCheck() )
      doc->BeginUndoRecord( L"TestModelessDialog" );

    ON_Circle circle( ON_3dPoint(15,15,0), 10.0 );
    doc->AddCurveObject( circle );
    doc->Redraw();

    if( m_undo.GetCheck() )
      doc->EndUndoRecord();
  }
}

void CTestModelessDialog::OnAddPoints() 
{
  CRhinoDoc* doc = ::RhinoApp().ActiveDoc();
  if( doc )
  {
    if( m_undo.GetCheck() )
      doc->BeginUndoRecord( L"TestModelessDialog" );

    doc->AddPointObject( ON_3dPoint(5,5,0) );
    doc->AddPointObject( ON_3dPoint(15,5,0) );
    doc->AddPointObject( ON_3dPoint(15,15,0) );
    doc->AddPointObject( ON_3dPoint(5,15,0) );
    doc->Redraw();

    if( m_undo.GetCheck() )
      doc->EndUndoRecord();
  }	
}
