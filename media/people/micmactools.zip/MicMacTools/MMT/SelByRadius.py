import rhinoscriptsyntax as rs
import scriptcontext as sc
from Rhino import RhinoMath
    
def SelByRadius():
    objs=rs.ObjectsByType(4,state=1)
    if not objs: return
    tol=sc.doc.ModelAbsoluteTolerance
    ff=RhinoMath.SqrtEpsilon #"fuzz factor"
    entity="arc"
    entity2="circle"
    measure="radius"
    cl=["LessThan","GreaterThan","EqualTo","LTorEqualTo","GTorEqualTo","Between"]
    
    #get previous settings
    if "SBR_Type_Choice" in sc.sticky: type_choice = sc.sticky["SBR_Type_Choice"]
    else: type_choice = cl[0]
    if "SBR_User_R" in sc.sticky: user_L = sc.sticky["SBR_User_R"]
    else: user_L = 1.0
    if "SBR_Max_R" in sc.sticky: max_R = sc.sticky["SBR_Max_R"]
    else: max_R = 1.0
    if "SBR_Min_R" in sc.sticky: min_R = sc.sticky["SBR_Min_R"]
    else: min_R = 1.0
    
    rs.UnselectAllObjects()
    msg="Selection type for {} or {} {}?".format(entity,entity2,measure)
    while True:
        compare=rs.GetString(msg,type_choice,cl)
        if not compare: return
        if compare in cl: break
    
    if compare == cl[5]:
        min_R=rs.GetReal("Minimum radius?",min_R,minimum=tol)
        if not min_R: return
        if max_R<min_R: max_R=min_R
        max_R=rs.GetReal("Maximum radius?",max_R,minimum=min_R)
        if not max_R: return
    else:
        radius=rs.GetReal("Radius?",user_L,minimum=tol)
        if not radius: return
        
    rs.EnableRedraw(False)
    for obj in objs:
        obj_len=rs.ArcRadius(obj)  #covers circle radius as well
        if compare==cl[0]:
            if obj_len < radius-ff: rs.SelectObject(obj)
        elif compare==cl[1]:
            if obj_len > radius+ff: rs.SelectObject(obj)
        elif compare==cl[2]:
            if abs(radius-obj_len)<ff: rs.SelectObject(obj)
        elif compare==cl[3]:
            if obj_len <= radius: rs.SelectObject(obj)
        elif compare==cl[4]:
            if obj_len >= radius: rs.SelectObject(obj)
        elif compare==cl[5]:
            if obj_len >= min_R and obj_len <= max_R: rs.SelectObject(obj)
            
    selObjs=rs.SelectedObjects()
    msg="found that match selection criteria"
    if selObjs:
        q=len(selObjs)
        if q>1:
            entity+="s" ; entity2+="s"
    else: q="No" ; entity+="s" ; entity2+="s"
    print "{} {} or {} {}".format(q,entity,entity2,msg)
        
    #store previous settings
    sc.sticky["SBR_Type_Choice"] = compare
    try: sc.sticky["SBR_User_R"] = radius
    except: pass
    try: sc.sticky["SBR_Max_R"] = max_R
    except: pass
    try: sc.sticky["SBR_Min_R"] = min_R
    except: pass
SelByRadius()
