/////////////////////////////////////////////////////////////////////////////
// cmdTestCommand2,cpp
//

#include "StdAfx.h"

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//
// BEGIN TestCommand2 command
//

class CCommandTestCommand2 : public CRhinoCommand
{
public:
	CCommandTestCommand2() {}
	~CCommandTestCommand2() {}

	UUID CommandUUID()
	{
		// {94E40A57-10C2-4606-872B-D469DE6D0B1A}
		static const GUID TestCommand2Command_UUID =
		{ 0x94E40A57, 0x10C2, 0x4606, { 0x87, 0x2B, 0xD4, 0x69, 0xDE, 0x6D, 0x0B, 0x1A } };
		return TestCommand2Command_UUID;
	}

	const wchar_t* EnglishCommandName() { return L"TestCommand2"; }
	const wchar_t* LocalCommandName() { return L"TestCommand2"; }

	CRhinoCommand::result RunCommand( const CRhinoCommandContext& );
};

static class CCommandTestCommand2 theTestCommand2Command;

CRhinoCommand::result CCommandTestCommand2::RunCommand( const CRhinoCommandContext& context )
{
	ON_wString sPrompt;
	sPrompt.Format( L"The \"%s\" command is under construction.\n", EnglishCommandName() );
	if( context.IsInteractive() )
		RhinoMessageBox( sPrompt, EnglishCommandName(), MB_OK );
	else
		RhinoApp().Print( sPrompt );

	return CRhinoCommand::success;
}

//
// END TestCommand2 command
//
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
