"""Script by Mitch Heynick, 20 June 2013
Applies a random display color on a group of objects
Limited within an RGB range mixed with black or white
(order is the order of the objects in the file)"""
import rhinoscriptsyntax as rs
import scriptcontext
import random

def RandomColorRange():
    
    #check for previous settings
    if scriptcontext.sticky.has_key("RedChoice"):
        rChoice = scriptcontext.sticky["RedChoice"]
    else:
        rChoice=True
        
    if scriptcontext.sticky.has_key("GreenChoice"):
        gChoice = scriptcontext.sticky["GreenChoice"]
    else:
        gChoice=True
        
    if scriptcontext.sticky.has_key("BlueChoice"):
        bChoice = scriptcontext.sticky["BlueChoice"]
    else:
        bChoice=True
        
    if scriptcontext.sticky.has_key("FadeChoice"):
        fChoice = scriptcontext.sticky["FadeChoice"]
    else:
        fChoice=True
    objs=rs.GetObjects("Select objects to random color",preselect=True)
    if not objs: return
    
    #user input
    rangeList=[("Red","No","Yes"),("Green","No","Yes"),("Blue","No","Yes"),("MixWith","White","Black")]
    rangeChoice=rs.GetBoolean("ColorRanges",rangeList,[rChoice,gChoice,bChoice,fChoice])
    if rangeChoice==None: return
    
    ranges = reduce(lambda x, y: x+y, rangeChoice[0:3])
    #if all add to 0: all are False, exit
    if ranges==0: return
    
    num=len(objs)
    
    r=[random.randint(0,255) for i in range(num)]
    g=[random.randint(0,255) for i in range(num)]
    b=[random.randint(0,255) for i in range(num)]
    
    if rangeChoice[3]:
        #to black
        if not rangeChoice[0]:
            r=[0]*num
        if not rangeChoice[1]:
            g=[0]*num
        if not rangeChoice[2]:
            b=[0]*num
    else:
        if ranges!=3:
            #to white (if not all 3 colors chosen)
            if rangeChoice[0]:
                r=[255]*num
            if rangeChoice[1]:
                g=[255]*num
            if rangeChoice[2]:
                b=[255]*num
            
    rs.EnableRedraw(False)
    for i in range(num):
        rs.ObjectColor(objs[i],(r[i],g[i],b[i]))
        
    #set previous values
    scriptcontext.sticky["RedChoice"]=rangeChoice[0]
    scriptcontext.sticky["GreenChoice"]=rangeChoice[1]
    scriptcontext.sticky["BlueChoice"]=rangeChoice[2]
    scriptcontext.sticky["FadeChoice"]=rangeChoice[3]

RandomColorRange()