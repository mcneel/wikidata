/////////////////////////////////////////////////////////////////////////////
// MenuTestV4App.h : main header file for the MenuTestV4 DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "Resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMenuTestV4App
// See MenuTestV4App.cpp for the implementation of this class
//

class CMenuTestV4App : public CWinApp
{
public:
	CMenuTestV4App();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};
