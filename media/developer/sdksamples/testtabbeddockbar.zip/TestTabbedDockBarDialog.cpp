/////////////////////////////////////////////////////////////////////////////
// TestTabbedDockBarDialog.cpp

#include "stdafx.h"
#include "TestTabbedDockBarPlugIn.h"
#include "TestTabbedDockBarDialog.h"

IMPLEMENT_DYNCREATE( CTestTabbedDockBarDialog, CRhinoTabbedDockBarDialog )

CTestTabbedDockBarDialog::CTestTabbedDockBarDialog()
: CRhinoTabbedDockBarDialog()
{
}

CTestTabbedDockBarDialog::~CTestTabbedDockBarDialog()
{
}

void CTestTabbedDockBarDialog::DoDataExchange( CDataExchange* pDX )
{
	CRhinoTabbedDockBarDialog::DoDataExchange( pDX );
  DDX_Control( pDX, IDC_CLICKME_BUTTON, m_clickme_button );
}

BEGIN_MESSAGE_MAP( CTestTabbedDockBarDialog, CRhinoTabbedDockBarDialog )
  ON_BN_CLICKED( IDC_CLICKME_BUTTON, &CTestTabbedDockBarDialog::OnClickedClickMeButton )
END_MESSAGE_MAP()

const wchar_t* CTestTabbedDockBarDialog::Caption() const 
{ 
	return L"Test";
}

ON_UUID CTestTabbedDockBarDialog::TabId() const
{
	return ID();
}

ON_UUID CTestTabbedDockBarDialog::ID()
{
  // {F9258012-26E4-4D89-A497-C31D53007DA1}
  static const GUID TestTabbedDockBarDialog_UUID =
  { 0xF9258012, 0x26E4, 0x4D89, { 0xA4, 0x97, 0xC3, 0x1D, 0x53, 0x00, 0x7D, 0xA1 } };
	return TestTabbedDockBarDialog_UUID;
}

ON_UUID CTestTabbedDockBarDialog::PlugInId() const
{
	return TestTabbedDockBarPlugIn().PlugInID();
}

HICON CTestTabbedDockBarDialog::Icon() const
{
	AFX_MANAGE_STATE( AfxGetStaticModuleState() );
	return ::LoadIcon( AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_TESTTABBEDDOCKBAR_ICON) );
}

void CTestTabbedDockBarDialog::OnShowTab( bool bShowTab, const ON_UUID& tabId )
{
  // TODO: Add "On Show" or "On Hide" tab code here
}

BOOL CTestTabbedDockBarDialog::OnInitDialog() 
{
  m_Resize.Add( IDC_CLICKME_BUTTON, CRhinoUiDialogItemResizer::resize_lockleft | CRhinoUiDialogItemResizer::resize_lockright );
  	
  CRhinoTabbedDockBarDialog::OnInitDialog();

  return TRUE;
}

void CTestTabbedDockBarDialog::OnClickedClickMeButton()
{
  // TODO: Add your control notification handler code here
}
