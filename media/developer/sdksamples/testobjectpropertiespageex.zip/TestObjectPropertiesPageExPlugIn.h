/////////////////////////////////////////////////////////////////////////////
// TestObjectPropertiesPageExPlugIn.h

#pragma once

/////////////////////////////////////////////////////////////////////////////
// CTestObjectPropertiesPageExPlugIn

class CTestObjectPropertiesPageExPlugIn : public CRhinoUtilityPlugIn
{
public:
  CTestObjectPropertiesPageExPlugIn();
  ~CTestObjectPropertiesPageExPlugIn();

  // Required overrides
  const wchar_t* PlugInName() const;
  const wchar_t* PlugInVersion() const;
  GUID PlugInID() const;
  BOOL OnLoadPlugIn();
  void OnUnloadPlugIn();

  // Optional overrides
  void AddPagesToObjectPropertiesDialog( ON_SimpleArray<class CRhinoObjectPropertiesDialogPage*>& pages );

private:
  ON_wString m_plugin_version;

  // TODO: Add additional class information here
};

CTestObjectPropertiesPageExPlugIn& TestObjectPropertiesPageExPlugIn();



