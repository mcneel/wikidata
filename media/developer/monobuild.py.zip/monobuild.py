import sys
import os
import string
import shutil

oldname = sys.argv[1]
for i in range(2,len(sys.argv)):
    oldname += " " + sys.argv[i]
newname = string.replace(oldname, ".dll", ".rhp")
print "oldname =", oldname
print "newname =", newname
os.rename(oldname, newname)
os.rename(oldname+".mdb", newname+".mdb")
