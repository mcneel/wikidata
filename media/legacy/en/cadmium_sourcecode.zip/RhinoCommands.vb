Option Strict On

Imports RMA.Rhino

Public Class SelectAtomByProperty
    Inherits RMA.Rhino.MRhinoCommand

    Public Overrides ReadOnly Property EnglishCommandName() As String
        Get
            Return "SelAtomProperty"
        End Get
    End Property

    Public Overrides Function RunCommand(ByVal context As RMA.Rhino.IRhinoCommandContext) As RMA.Rhino.IRhinoCommand.result
        Dim getInterface As New RMA.Rhino.MRhinoGetString
        getInterface.AcceptString(False)
        getInterface.SetCommandPrompt("Specify which atom property you would like to filter")
        getInterface.AddCommandOption(New RMA.Rhino.MRhinoCommandOptionName("Element_Type", "Element_Type"))
        getInterface.AddCommandOption(New RMA.Rhino.MRhinoCommandOptionName("Molecular_structure", "Molecular_structure"))
        getInterface.AddCommandOption(New RMA.Rhino.MRhinoCommandOptionName("Protein_Chain", "Protein_Chain"))
        getInterface.AddCommandOption(New RMA.Rhino.MRhinoCommandOptionName("Protein_Residue", "Protein_Residue"))

        Select Case getInterface.GetString
            Case IRhinoGet.result.option
                Select Case UCase(getInterface.Option.m_english_option_name)
                    Case "ELEMENT_TYPE"
                        Return SelectionTools.SelectByElement
                    Case "MOLECULAR_STRUCTURE"
                        Return SelectionTools.SelectByMolecularStructure
                    Case "PROTEIN_CHAIN"
                        Return SelectionTools.SelectByChain
                    Case "PROTEIN_RESIDUE"
                        Return SelectionTools.SelectByResidue
                    Case Else
                        MsgBox(getInterface.Option.m_english_option_name, MsgBoxStyle.OKOnly, "Unrecognized option")
                End Select

                MsgBox(getInterface.Option.m_english_option_name)
            Case Else
                Return IRhinoCommand.result.cancel
        End Select
    End Function
End Class

Public Class CADmiumCommand
    Inherits RMA.Rhino.MRhinoCommand

    Public Overrides ReadOnly Property EnglishCommandName() As String
        Get
            Return "CADmium"
        End Get
    End Property

    Public Overrides Function RunCommand(ByVal context As IRhinoCommandContext) As IRhinoCommand.result
        Dim iDialog As New Windows.Forms.OpenFileDialog
        iDialog.Title = "Import Brookhaven Protein Databank file"
        iDialog.Filter = "Protein Databank (*.pdb)|*.pdb;*.ent|All files|*.*"
        If iDialog.ShowDialog <> Windows.Forms.DialogResult.OK Then Exit Function

        Dim nMolecule As New Molecule
        If Not nMolecule.ReadFromPDBFile(iDialog.FileName) Then Return IRhinoCommand.result.failure

        Dim iFilter As New AtomFilter
        iFilter.set_Molecules = nMolecule.set_Molecules
        iFilter.set_Chains = nMolecule.set_Chains
        iFilter.set_Residues = nMolecule.set_Residues

        Dim nOptionsDialog As New OptionsDialog
        nOptionsDialog.SetRecordLibraries(iFilter)
        nOptionsDialog.mol_Pointer = nMolecule
        If nOptionsDialog.ShowDialog(RMA.Rhino.RhUtil.RhinoApp.MainWnd) <> _
            Windows.Forms.DialogResult.OK Then Return IRhinoCommand.result.failure

        iFilter = nOptionsDialog.GetRecordLibraries
        Dim iAttributes As GeometryAttributes = nOptionsDialog.g_Attributes
        iAttributes.mol_Pointer = nMolecule

        If iAttributes.o_ApplyFilter Then nMolecule.FilterAtomList(iFilter)
        If iAttributes.o_IgnoreHydrogen Then nMolecule.CullElements(AtomCode.H)
        If iAttributes.b_BondGeometry <> BondGeometry.None Or iAttributes.b_BondGeometry <> BondGeometry.Unknown Then
            nMolecule.CalculateBonds(iAttributes.b_SearchDepth)
        End If

        RMA.Rhino.RhUtil.RhinoApp.ActiveDoc.BeginUndoRecord("Add molecule")
        nMolecule.Insert(iAttributes)
        RMA.Rhino.RhUtil.RhinoApp.ActiveDoc.EndUndoRecord()
        nOptionsDialog.Dispose()

        nMolecule.SynchronizeViewportsToMolecule()
        RMA.Rhino.RhUtil.RhinoApp.ActiveDoc.Redraw()

        Return IRhinoCommand.result.success
    End Function
End Class
