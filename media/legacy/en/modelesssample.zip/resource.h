//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ModelessSample.rc
//
#define IDD_DIALOG1                     19000
#define IDC_EDIT1                       19000
#define IDC_EDIT2                       19001
#define IDC_EDIT3                       19002
#define IDC_BUTTON1                     19003
#define IDC_BUTTON2                     19004
#define IDC_BUTTON3                     19005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        19001
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         19006
#define _APS_NEXT_SYMED_VALUE           19000
#endif
#endif
