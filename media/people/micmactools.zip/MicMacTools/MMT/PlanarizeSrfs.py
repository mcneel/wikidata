import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino
"""Script to transform non-planar surfaces into planar surfaces using either
best-fit plane or current view CPlane. Works best with "near planar" surfaces.
Works by projecting all control points to a plane; may cause folds or other
anomalies if surface is not near-planar.  Script by Mitch Heynick 17.06.15"""

def CommandLineOptions(prompt,msg1,b_opts1,msg2,b_opts2,msg3,b_opts3):
    go = Rhino.Input.Custom.GetOption()
    go.SetCommandPrompt(prompt)    
    # set up the options
    boolOption1 = Rhino.Input.Custom.OptionToggle(*b_opts1)
    boolOption2 = Rhino.Input.Custom.OptionToggle(*b_opts2)
    boolOption3 = Rhino.Input.Custom.OptionToggle(*b_opts3)
    go.AddOptionToggle(msg1, boolOption1)
    go.AddOptionToggle(msg2, boolOption2)
    go.AddOptionToggle(msg3, boolOption3)
    go.AcceptNothing(True)
    
    #user input
    while True:
        get_rc = go.Get()
        a=boolOption1.CurrentValue
        b=boolOption2.CurrentValue
        c=boolOption3.CurrentValue
        if go.CommandResult()== Rhino.Commands.Result.Cancel:
            return
        elif go.CommandResult()== Rhino.Commands.Result.Nothing:
            break
        elif get_rc==Rhino.Input.GetResult.Option:
            continue
        break
    return a, b, c

def MaxDeviationInPlane(obj, plane):
    bb = rs.BoundingBox(obj, plane, False)
    if bb: return (bb[0].DistanceTo(bb[4]))*0.5
    
def ProjPtsToPlaneAlongVector(pts,plane,vec):
    proj_pts=[]
    for pt in pts:
        line=Rhino.Geometry.Line(pt,vec)
        rc,ipt=Rhino.Geometry.Intersect.Intersection.LinePlane(line,plane)
        if not rc: return
        proj_pts.append(line.PointAt(ipt))
    return proj_pts
    
def GetNurbsSrfFromBrepID(objID):
    brep=sc.doc.Objects.Find(objID).Geometry
    faces=brep.Faces
    if faces.Count==1: return faces[0].ToNurbsSurface()
    
def PlanarizeSrfs():
    msg="Select near-planar surfaces to planarize"
    srfs = rs.GetObjects(msg,8,preselect=True)
    if not srfs: return
    pick_view = rs.CurrentView()
    
    #get previous settings
    if "Planarize_S_Proj" in sc.sticky: pc_proj = sc.sticky["Planarize_S_Proj"]
    else: pc_proj = True
    if "Planarize_S_Del" in sc.sticky: pc_del = sc.sticky["Planarize_S_Del"]
    else: pc_del = True
    if "Planarize_S_Axis" in sc.sticky: pc_axis = sc.sticky["Planarize_S_Axis"]
    else: pc_axis = True
    
    #get user input
    prompt="Planarize options:"
    msg1="ProjectionType"
    msg2="DeleteInput"
    msg3="ProjectionVector"
    opts1=(pc_proj,"ActiveCPlaneParallel", "BestFitPlane")
    opts2=(pc_del,"No","Yes")
    opts3=(pc_axis,"ViewCPlane","BestFitPlane")
    user_opts=CommandLineOptions(prompt,msg1,opts1,msg2,opts2,msg3,opts3)
    if not user_opts: return
    plane_choice, del_choice, proj_choice=user_opts
    
    #initialize and run
    prec = rs.UnitDistanceDisplayPrecision()
    unit_sys_name = rs.UnitSystemName(False, False, True)
    max_dev = 0.0 ; bad_srfs = 0 ; new_srfs=[]
    rs.EnableRedraw(False)
    for srf in srfs:
        if plane_choice:
            pts = rs.SurfacePoints(srf)
            bf_plane = rs.PlaneFitFromPoints(pts)
        else:
            bb = rs.BoundingBox(srf, pick_view, False)
            bf_plane = rs.ViewCPlane(pick_view)
            bf_plane.Origin = (bb[0]+bb[6])/2
            
        if bf_plane:
            dev = MaxDeviationInPlane(srf, bf_plane)
            #0=BestFitPlane,1=ViewCPlane,2=Xaxis,3=Yaxis,4=Zaxis
            if proj_choice:
                xform = rs.XformPlanarProjection(bf_plane)
                new_srf = rs.TransformObject(srf, xform, not del_choice)
                if new_srf: new_srfs.append(new_srf)
            else:
                vec=rs.ViewCPlane(pick_view).Normal
                rs.EnableObjectGrips(srf,True)
                grip_pts=rs.ObjectGripLocations(srf)
                proj_pts=ProjPtsToPlaneAlongVector(grip_pts,bf_plane,vec)
                rs.ObjectGripLocations(srf,proj_pts)
                rs.EnableObjectGrips(srf,False)
            if dev is not None and dev > max_dev: max_dev = dev
        else: bad_srfs+=1
    if new_srfs: rs.SelectObjects(new_srfs)
    
    #reporting
    msg="{} surfaces planarized - max deviation: ".format(len(srfs)-bad_srfs)
    msg+="{} {}".format(round(max_dev,prec),unit_sys_name)
    if bad_srfs>0: msg+=" || {} surfaces unable to be processed".format(bad_srfs)
    print msg
    #store options
    sc.sticky["Planarize_S_Proj"] = plane_choice
    sc.sticky["Planarize_S_Del"] = del_choice
    sc.sticky["Planarize_S_Axis"] = proj_choice
PlanarizeSrfs()