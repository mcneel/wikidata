namespace TestObjectManager
{
  public class TestObjectManagerPlugIn : RMA.Rhino.MRhinoUtilityPlugIn
  {
    private RMA.UI.MRhinoUiDockBar m_dockbar;
    private TestObjectManagerControl m_control;

    public override System.Guid PlugInID()
    {
      return new System.Guid("{949aefeb-407a-4b87-b477-1df3ee0ae375}");
    }

    public override string PlugInName()
    {
      return "TestObjectManager";
    }

    public override string PlugInVersion()
    {
      return "1.0.0.0";
    }

    public override int OnLoadPlugIn()
    {
      m_control = new TestObjectManagerControl();
      m_dockbar = new RMA.UI.MRhinoUiDockBar(TestObjectManagerDockBar.ID(), "Object Manager", m_control);
      RMA.UI.MRhinoDockBarManager.CreateRhinoDockBar(this, m_dockbar, false);
      return 1;
    }

    public override void OnUnloadPlugIn()
    {
    }
  }
}
