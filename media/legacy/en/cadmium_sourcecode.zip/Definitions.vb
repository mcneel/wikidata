Option Compare Text

Module Definitions
    Public Const PluginVersion As String = "0.6 beta"

    Public Function ToElementName(ByVal sAtom As AtomCode, _
                                  Optional ByVal Capitalize As Boolean = True) As String
        Dim sName As String
        Select Case sAtom
            Case AtomCode.Unknown : sName = "unknown"
            Case AtomCode.Other : sName = "other"
            Case AtomCode.Ac : sName = "actinium"
            Case AtomCode.Ag : sName = "silver"
            Case AtomCode.Al : sName = "aluminium"
            Case AtomCode.Ar : sName = "argon"
            Case AtomCode.As_ : sName = "arsenic"
            Case AtomCode.At : sName = "astatine"
            Case AtomCode.Au : sName = "gold"
            Case AtomCode.B : sName = "boron"
            Case AtomCode.Ba : sName = "barium"
            Case AtomCode.Be : sName = "beryllium"
            Case AtomCode.Bh : sName = "bohrium"
            Case AtomCode.Bi : sName = "bismuth"
            Case AtomCode.Br : sName = "bromine"
            Case AtomCode.C : sName = "carbon"
            Case AtomCode.Ca : sName = "calcium"
            Case AtomCode.Cd : sName = "cadmium"
            Case AtomCode.Cl : sName = "chlorine"
            Case AtomCode.Co : sName = "cobalt"
            Case AtomCode.Cr : sName = "chromium"
            Case AtomCode.Cs : sName = "cesium"
            Case AtomCode.Cu : sName = "copper"
            Case AtomCode.Db : sName = "dubnium"
            Case AtomCode.F : sName = "fluorine"
            Case AtomCode.Fe : sName = "iron"
            Case AtomCode.Fr : sName = "francium"
            Case AtomCode.Ga : sName = "gallium"
            Case AtomCode.Ge : sName = "germanium"
            Case AtomCode.H : sName = "hydrogen"
            Case AtomCode.He : sName = "helium"
            Case AtomCode.Hf : sName = "hafnium"
            Case AtomCode.Hg : sName = "mercury"
            Case AtomCode.Hs : sName = "hassium"
            Case AtomCode.I : sName = "iodine"
            Case AtomCode.In_ : sName = "indium"
            Case AtomCode.Ir : sName = "iridium"
            Case AtomCode.K : sName = "potassium"
            Case AtomCode.Kr : sName = "krypton"
            Case AtomCode.La : sName = "lanthanum"
            Case AtomCode.Li : sName = "lithium"
            Case AtomCode.Mg : sName = "magnesium"
            Case AtomCode.Mn : sName = "manganese"
            Case AtomCode.Mo : sName = "molybdenum"
            Case AtomCode.Mt : sName = "meitnerium"
            Case AtomCode.N : sName = "nitrogen"
            Case AtomCode.Na : sName = "sodium"
            Case AtomCode.Nb : sName = "niobium"
            Case AtomCode.Ne : sName = "neon"
            Case AtomCode.Ni : sName = "nickel"
            Case AtomCode.O : sName = "oxygen"
            Case AtomCode.Os : sName = "osmium"
            Case AtomCode.P : sName = "phosphorus"
            Case AtomCode.Pb : sName = "lead"
            Case AtomCode.Pd : sName = "palladium"
            Case AtomCode.Po : sName = "polonium"
            Case AtomCode.Pt : sName = "platinum"
            Case AtomCode.Ra : sName = "radium"
            Case AtomCode.Rb : sName = "rubidium"
            Case AtomCode.Re : sName = "rhenium"
            Case AtomCode.Rf : sName = "rutherfordium"
            Case AtomCode.Rh : sName = "rhodium"
            Case AtomCode.Rn : sName = "radon"
            Case AtomCode.Ru : sName = "ruthenium"
            Case AtomCode.S : sName = "sulfur"
            Case AtomCode.Sb : sName = "antimony"
            Case AtomCode.Sc : sName = "scandium"
            Case AtomCode.Se : sName = "selenium"
            Case AtomCode.Sg : sName = "seaborgium"
            Case AtomCode.Si : sName = "silicon"
            Case AtomCode.Sn : sName = "tin"
            Case AtomCode.Sr : sName = "strontium"
            Case AtomCode.Ta : sName = "tantalum"
            Case AtomCode.Tc : sName = "technetium"
            Case AtomCode.Te : sName = "tellurium"
            Case AtomCode.Ti : sName = "titatium"
            Case AtomCode.Tl : sName = "thallium"
            Case AtomCode.V : sName = "vanadium"
            Case AtomCode.W : sName = "tungsten"
            Case AtomCode.Xe : sName = "xenon"
            Case AtomCode.Y : sName = "yttrium"
            Case AtomCode.Zn : sName = "zinc"
            Case AtomCode.Zr : sName = "zirconium"
        End Select
        If Capitalize Then
            sName = UCase(Left(sName, 1)) & LCase(Mid(sName, 2))
        End If
        Return sName
    End Function


    Public Function ToElementType(ByVal sAtomCode As String) As AtomCode
        Select Case UCase(sAtomCode)
            Case "H", "HYDROGEN" : Return AtomCode.H
            Case "HE", "HELIUM" : Return AtomCode.He
            Case "LI", "LITHIUM" : Return AtomCode.Li
            Case "BE", "BERYLLIUM" : Return AtomCode.Be
            Case "B", "BORON" : Return AtomCode.B
            Case "C", "CARBON" : Return AtomCode.C
            Case "N", "NITROGEN" : Return AtomCode.N
            Case "O", "OXYGEN" : Return AtomCode.O
            Case "F", "FLUORINE" : Return AtomCode.F
            Case "NE", "NEON" : Return AtomCode.Ne
            Case "NA", "SODIUM" : Return AtomCode.Na
            Case "MG", "MAGNESIUM" : Return AtomCode.Mg
            Case "AL", "ALUMINIUM", "ALUMINUM" : Return AtomCode.Al
            Case "SI", "SILICON" : Return AtomCode.Si
            Case "P", "PHOSPHORUS" : Return AtomCode.P
            Case "S", "SULFUR" : Return AtomCode.S
            Case "CL", "CLORINE" : Return AtomCode.Cl
            Case "AR", "ARGON" : Return AtomCode.Ar
            Case "K", "POTASSIUM" : Return AtomCode.K
            Case "CA", "CALCIUM" : Return AtomCode.Ca
            Case "SC", "SCANDIUM" : Return AtomCode.Sc
            Case "TI", "TITANIUM" : Return AtomCode.Ti
            Case "V", "VANADIUM" : Return AtomCode.V
            Case "CR", "CHROME" : Return AtomCode.Cr
            Case "MN", "MANGANESE" : Return AtomCode.Mn
            Case "FE", "IRON" : Return AtomCode.Fe
            Case "CO", "COBALT" : Return AtomCode.Co
            Case "NI", "NICKEL" : Return AtomCode.Ni
            Case "CU", "COPPER" : Return AtomCode.Cu
            Case "ZN", "ZINC" : Return AtomCode.Zn
            Case "GA", "GALLIUM" : Return AtomCode.Ga
            Case "GE", "GERMANIUM" : Return AtomCode.Ge
            Case "AS", "ARSENIC" : Return AtomCode.As_
            Case "SE", "SELENIUM" : Return AtomCode.Se
            Case "BR", "BROMINE" : Return AtomCode.Br
            Case "KR", "KRYPTON" : Return AtomCode.Kr
            Case "RB", "RUBIDIUM" : Return AtomCode.Rb
            Case "SR", "STRONTIUM" : Return AtomCode.Sr
            Case "Y", "YTTRIUM" : Return AtomCode.Y
            Case "ZR", "ZIRCONIUM" : Return AtomCode.Zr
            Case "NB", "NIOBIUM" : Return AtomCode.Nb
            Case "MO", "MOLYBDENUM" : Return AtomCode.Mo
            Case "TC", "TECHNETIUM" : Return AtomCode.Tc
            Case "RU", "RUTHENIUM" : Return AtomCode.Ru
            Case "RH", "RHODIUM" : Return AtomCode.Rh
            Case "PD", "PALLADIUM" : Return AtomCode.Pd
            Case "AG", "SILVER" : Return AtomCode.Ag
            Case "CD", "CADMIUM" : Return AtomCode.Cd
            Case "IN", "INDIUM" : Return AtomCode.In_
            Case "SN", "TIN" : Return AtomCode.Sn
            Case "SB", "ANTIMONY" : Return AtomCode.Sb
            Case "TE", "TELLURIUM" : Return AtomCode.Te
            Case "I", "IODINE" : Return AtomCode.I
            Case "XE", "XENON" : Return AtomCode.Xe
            Case "CS", "CESIUM" : Return AtomCode.Cs
            Case "BA", "BARIUM" : Return AtomCode.Ba
            Case "LA", "LATHANIUM" : Return AtomCode.La
            Case "HF", "HAFNIUM" : Return AtomCode.Hf
            Case "TA", "TANTALUM" : Return AtomCode.Ta
            Case "W", "WOLFRAM", "TUNGSTEN" : Return AtomCode.W
            Case "RE", "RHENIUM" : Return AtomCode.Re
            Case "OS", "OSMIUM" : Return AtomCode.Os
            Case "IR", "IRIDIUM" : Return AtomCode.Ir
            Case "PT", "PLUTONIUM" : Return AtomCode.Pt
            Case "AU", "GOLD" : Return AtomCode.Au
            Case "HG", "MERCURY", "QUICKSILVER" : Return AtomCode.Hg
            Case "TL", "THALLIUM" : Return AtomCode.Tl
            Case "PB", "LEAD" : Return AtomCode.Pb
            Case "BI", "BISMUT" : Return AtomCode.Bi
            Case "PO", "POLONIUM" : Return AtomCode.Po
            Case "AT", "ASTATINE" : Return AtomCode.At
            Case "RN", "RADON" : Return AtomCode.Rn
            Case "FR", "FRANCIUM" : Return AtomCode.Fr
            Case "RA", "RADIUM" : Return AtomCode.Ra
            Case "AC", "ACTINIUM" : Return AtomCode.Ac
            Case "RF", "RUTHERFORDIUM" : Return AtomCode.Rf
            Case "DB", "DUBNIUM" : Return AtomCode.Db
            Case "SG", "SEABORGHIUM" : Return AtomCode.Sg
            Case "BH", "BOHRIUM" : Return AtomCode.Bh
            Case "HS", "HASSIUM" : Return AtomCode.Hs
            Case "MT", "MEITNERIUM" : Return AtomCode.Mt
            Case Else : Return AtomCode.Unknown
        End Select
    End Function

    Public Function ToElementRadius(ByVal sAtom As AtomCode, _
                                    Optional ByVal rType As AtomRadius = CADmium.AtomRadius.AtomicRadius) As Double
        Dim aRadius As Double
        Dim bRadius As Double
        Dim wRadius As Double
        Select Case sAtom
            Case AtomCode.Unknown : aRadius = 0.0 : bRadius = 0.0 : wRadius = 0.0
            Case AtomCode.Other : aRadius = 1.0 : bRadius = 0.0 : wRadius = 2.0
            Case AtomCode.Ag : aRadius = 1.75 : bRadius = 1.34 : wRadius = 1.72
            Case AtomCode.Al : aRadius = 1.82 : bRadius = 1.18 : wRadius = 2.0
            Case AtomCode.Ar : aRadius = 0.88 : bRadius = 0.98 : wRadius = 1.88
            Case AtomCode.As_ : aRadius = 1.33 : bRadius = 1.2 : wRadius = 1.85
            Case AtomCode.At : aRadius = 1.43 : bRadius = 1.45 : wRadius = 2.0
            Case AtomCode.Au : aRadius = 1.79 : bRadius = 1.34 : wRadius = 1.66
            Case AtomCode.B : aRadius = 1.17 : bRadius = 0.82 : wRadius = 2.0
            Case AtomCode.Ba : aRadius = 2.78 : bRadius = 1.98 : wRadius = 2.0
            Case AtomCode.Be : aRadius = 1.4 : bRadius = 0.9 : wRadius = 2.0
            Case AtomCode.Bi : aRadius = 1.63 : bRadius = 1.46 : wRadius = 2.0
            Case AtomCode.Br : aRadius = 1.12 : bRadius = 1.14 : wRadius = 1.85
            Case AtomCode.C : aRadius = 0.91 : bRadius = 0.77 : wRadius = 1.7
            Case AtomCode.Ca : aRadius = 2.23 : bRadius = 1.74 : wRadius = 1.58
            Case AtomCode.Cd : aRadius = 1.71 : bRadius = 1.48 : wRadius = 2.0
            Case AtomCode.Cl : aRadius = 0.97 : bRadius = 0.99 : wRadius = 1.75
            Case AtomCode.Co : aRadius = 1.67 : bRadius = 1.16 : wRadius = 2.0
            Case AtomCode.Cr : aRadius = 1.85 : bRadius = 1.18 : wRadius = 2.0
            Case AtomCode.Cs : aRadius = 3.34 : bRadius = 2.35 : wRadius = 2.0
            Case AtomCode.Cu : aRadius = 1.57 : bRadius = 1.17 : wRadius = 1.4
            Case AtomCode.F : aRadius = 0.57 : bRadius = 0.72 : wRadius = 1.47
            Case AtomCode.Fe : aRadius = 1.72 : bRadius = 1.17 : wRadius = 2.0
            Case AtomCode.Ga : aRadius = 1.82 : bRadius = 1.16 : wRadius = 1.87
            Case AtomCode.Ge : aRadius = 1.52 : bRadius = 1.22 : wRadius = 2.0
            Case AtomCode.H : aRadius = 0.79 : bRadius = 0.32 : wRadius = 1.2
            Case AtomCode.He : aRadius = 0.49 : bRadius = 0.93 : wRadius = 1.4
            Case AtomCode.Hf : aRadius = 2.16 : bRadius = 1.44 : wRadius = 2.0
            Case AtomCode.Hg : aRadius = 1.76 : bRadius = 1.49 : wRadius = 1.55
            Case AtomCode.I : aRadius = 1.32 : bRadius = 1.33 : wRadius = 1.98
            Case AtomCode.In_ : aRadius = 2.0 : bRadius = 1.44 : wRadius = 1.93
            Case AtomCode.Ir : aRadius = 1.87 : bRadius = 1.27 : wRadius = 2.0
            Case AtomCode.K : aRadius = 2.77 : bRadius = 2.03 : wRadius = 2.75
            Case AtomCode.Kr : aRadius = 1.03 : bRadius = 1.12 : wRadius = 2.02
            Case AtomCode.La : aRadius = 2.74 : bRadius = 1.69 : wRadius = 2.0
            Case AtomCode.Li : aRadius = 2.05 : bRadius = 1.23 : wRadius = 1.82
            Case AtomCode.Mg : aRadius = 1.72 : bRadius = 1.36 : wRadius = 1.73
            Case AtomCode.Mn : aRadius = 1.79 : bRadius = 1.17 : wRadius = 2.0
            Case AtomCode.Mo : aRadius = 2.01 : bRadius = 1.3 : wRadius = 2.0
            Case AtomCode.N : aRadius = 0.75 : bRadius = 0.75 : wRadius = 1.55
            Case AtomCode.Na : aRadius = 2.23 : bRadius = 1.54 : wRadius = 2.27
            Case AtomCode.Nb : aRadius = 2.08 : bRadius = 1.34 : wRadius = 2.0
            Case AtomCode.Ne : aRadius = 0.51 : bRadius = 0.71 : wRadius = 1.54
            Case AtomCode.Ni : aRadius = 1.62 : bRadius = 1.15 : wRadius = 1.63
            Case AtomCode.O : aRadius = 0.65 : bRadius = 0.73 : wRadius = 1.52
            Case AtomCode.Os : aRadius = 1.92 : bRadius = 1.26 : wRadius = 2.0
            Case AtomCode.P : aRadius = 1.23 : bRadius = 1.06 : wRadius = 1.8
            Case AtomCode.Pb : aRadius = 1.81 : bRadius = 1.47 : wRadius = 2.02
            Case AtomCode.Pd : aRadius = 1.79 : bRadius = 1.28 : wRadius = 1.63
            Case AtomCode.Po : aRadius = 1.53 : bRadius = 1.46 : wRadius = 2.0
            Case AtomCode.Pt : aRadius = 1.83 : bRadius = 1.3 : wRadius = 1.72
            Case AtomCode.Rb : aRadius = 2.98 : bRadius = 2.16 : wRadius = 2.0
            Case AtomCode.Re : aRadius = 1.97 : bRadius = 1.28 : wRadius = 2.0
            Case AtomCode.Rh : aRadius = 1.83 : bRadius = 1.25 : wRadius = 2.0
            Case AtomCode.Rn : aRadius = 1.34 : bRadius = 1.0 : wRadius = 2.0
            Case AtomCode.Ru : aRadius = 1.89 : bRadius = 1.25 : wRadius = 2.0
            Case AtomCode.S : aRadius = 1.09 : bRadius = 1.02 : wRadius = 1.8
            Case AtomCode.Sb : aRadius = 1.53 : bRadius = 1.4 : wRadius = 2.0
            Case AtomCode.Sc : aRadius = 2.09 : bRadius = 1.44 : wRadius = 2.0
            Case AtomCode.Se : aRadius = 1.22 : bRadius = 1.16 : wRadius = 1.9
            Case AtomCode.Si : aRadius = 1.46 : bRadius = 1.11 : wRadius = 2.1
            Case AtomCode.Sn : aRadius = 1.72 : bRadius = 1.41 : wRadius = 2.17
            Case AtomCode.Sr : aRadius = 2.45 : bRadius = 1.91 : wRadius = 2.0
            Case AtomCode.Ta : aRadius = 2.09 : bRadius = 1.34 : wRadius = 2.0
            Case AtomCode.Tc : aRadius = 1.95 : bRadius = 1.27 : wRadius = 2.0
            Case AtomCode.Te : aRadius = 1.42 : bRadius = 1.36 : wRadius = 2.06
            Case AtomCode.Ti : aRadius = 2.0 : bRadius = 1.32 : wRadius = 2.0
            Case AtomCode.Tl : aRadius = 2.08 : bRadius = 1.48 : wRadius = 1.96
            Case AtomCode.V : aRadius = 1.92 : bRadius = 1.22 : wRadius = 2.0
            Case AtomCode.W : aRadius = 2.02 : bRadius = 1.3 : wRadius = 2.0
            Case AtomCode.Xe : aRadius = 1.24 : bRadius = 1.31 : wRadius = 2.16
            Case AtomCode.Y : aRadius = 2.27 : bRadius = 1.62 : wRadius = 2.0
            Case AtomCode.Zn : aRadius = 1.53 : bRadius = 1.25 : wRadius = 1.39
            Case AtomCode.Zr : aRadius = 2.16 : bRadius = 1.45 : wRadius = 2.0
            Case Else
                aRadius = 1.0
                bRadius = 1.0
                wRadius = 2.0
        End Select

        Select Case rType
            Case CADmium.AtomRadius.AtomicRadius
                Return aRadius
            Case CADmium.AtomRadius.BondingRadius
                Return bRadius
            Case CADmium.AtomRadius.VanDerWaalsRadius
                Return wRadius
            Case CADmium.AtomRadius.Unknown
                Return 1.0
        End Select
    End Function

    Public Function ToElementNumber(ByVal sAtom As AtomCode) As Int32
        Return System.Convert.ToInt32(sAtom)
    End Function

    Public Function ToElementColour(ByVal sAtom As Atom, ByVal sProps As GeometryAttributes) As RMA.OpenNURBS.OnColor
        Dim r, g, b As Int32
        Select Case sProps.a_AtomColour
            Case CADmium.AtomColour.None, CADmium.AtomColour.Unknown
                r = 0
                g = 0
                b = 0
            Case CADmium.AtomColour.CPK
                Select Case sAtom.ElementType
                    Case AtomCode.H
                        r = 255 : g = 255 : b = 255
                    Case AtomCode.C
                        r = 200 : g = 200 : b = 200
                    Case AtomCode.N
                        r = 143 : g = 143 : b = 255
                    Case AtomCode.S
                        r = 255 : g = 200 : b = 50
                    Case AtomCode.I
                        r = 160 : g = 32 : b = 240
                    Case AtomCode.O
                        r = 240 : g = 0 : b = 0
                    Case AtomCode.F, AtomCode.Si, AtomCode.Au
                        r = 218 : g = 165 : b = 32
                    Case AtomCode.P, AtomCode.Fe, AtomCode.Ba
                        r = 255 : g = 165 : b = 0
                    Case AtomCode.Cl, AtomCode.B
                        r = 0 : g = 255 : b = 0
                    Case AtomCode.Br, AtomCode.Zn, AtomCode.Ni, AtomCode.Cu
                        r = 165 : g = 42 : b = 42
                    Case AtomCode.Na
                        r = 0 : g = 0 : b = 255
                    Case AtomCode.Mg
                        r = 34 : g = 139 : b = 34
                    Case AtomCode.Ca, AtomCode.Mn, AtomCode.Al, AtomCode.Ti, AtomCode.Cr, AtomCode.Ag
                        r = 128 : g = 128 : b = 144
                    Case AtomCode.Li
                        r = 178 : g = 34 : b = 34
                    Case AtomCode.He
                        r = 255 : g = 192 : b = 203
                    Case Else
                        r = 255 : g = 20 : b = 147
                End Select
            Case CADmium.AtomColour.BySerialNumber
                r = System.Convert.ToInt32(sAtom.SerialNumber / (sProps.mol_Pointer.Original_Atom_Count) * 255)
                g = System.Convert.ToInt32(sAtom.SerialNumber / (sProps.mol_Pointer.Original_Atom_Count) * 255)
                b = System.Convert.ToInt32(sAtom.SerialNumber / (sProps.mol_Pointer.Original_Atom_Count) * 255)
            Case CADmium.AtomColour.BySequence
                Dim Rnd As New System.Random(sAtom.ResidueSequence)
                r = Rnd.Next(0, 255)
                g = Rnd.Next(0, 255)
                b = Rnd.Next(0, 255)
            Case CADmium.AtomColour.ByResidue
                Dim Rnd As New System.Random(StringToInt32(sAtom.Residue))
                r = Rnd.Next(0, 255)
                g = Rnd.Next(0, 255)
                b = Rnd.Next(0, 255)
            Case CADmium.AtomColour.ByPosition
                Dim iBBox As RMA.OpenNURBS.OnBoundingBox = sProps.mol_Pointer.BoundingBox
                r = (sAtom.x - iBBox.m_min.x) / (iBBox.m_max.x - iBBox.m_min.x) * 255
                g = (sAtom.y - iBBox.m_min.y) / (iBBox.m_max.y - iBBox.m_min.y) * 255
                b = (sAtom.z - iBBox.m_min.z) / (iBBox.m_max.z - iBBox.m_min.z) * 255
            Case CADmium.AtomColour.ByOccupancy
                Dim iOcc As Double = sAtom.Occupancy
                r = 127 * iOcc
                g = 0
                b = 255 - 127 * iOcc
            Case CADmium.AtomColour.ByMolecule
                Dim Rnd As New System.Random(System.Convert.ToInt32(sAtom.MoleculeNumber * 1000))
                r = Rnd.Next(0, 255)
                g = Rnd.Next(0, 255)
                b = Rnd.Next(0, 255)
            Case CADmium.AtomColour.ByChain
                Dim Rnd As New System.Random(StringToInt32(sAtom.Chain))
                r = Rnd.Next(0, 255)
                g = Rnd.Next(0, 255)
                b = Rnd.Next(0, 255)
            Case CADmium.AtomColour.ByTemperature
                Dim iTemp As Double = sAtom.TempFactor
                r = 2.55F * iTemp
                g = 0
                b = 255 - 2.55F * iTemp
            Case Else
                r = 128
                g = 128
                b = 128
        End Select

        r = System.Math.Max(r, 0)
        g = System.Math.Max(g, 0)
        b = System.Math.Max(b, 0)
        r = System.Math.Min(r, 255)
        g = System.Math.Min(g, 255)
        b = System.Math.Min(b, 255)

        Return New RMA.OpenNURBS.OnColor(r, g, b)
    End Function

    Public Function ToFullResidueName(ByVal sResCode As String, Optional ByVal Capitalize As Boolean = True) As String
        Dim iName As String
        Select Case sResCode
            Case "G" : iName = "guanosine"
            Case "T" : iName = "thymidine"
            Case "C" : iName = "cytidine"
            Case "A" : iName = "adenosine"
            Case "I" : iName = "iosine"
            Case "U" : iName = "uridine"
            Case "ALA" : iName = "alanine"
            Case "ARG" : iName = "arginine"
            Case "ASN" : iName = "asparagine"
            Case "ASP" : iName = "aspartic acid"
            Case "ASX" : iName = "aspartic/asparagine ambiguous"
            Case "CYS" : iName = "cysteine"
            Case "GLN" : iName = "glutamine"
            Case "GLU" : iName = "glutamic acid"
            Case "GLX" : iName = "glutamine/glutamic ambiguous"
            Case "GLY" : iName = "glycine"
            Case "HIS" : iName = "histidine"
            Case "ILE" : iName = "isoleucine"
            Case "LEU" : iName = "leucine"
            Case "LYS" : iName = "lysine"
            Case "MET" : iName = "methionine"
            Case "PHE" : iName = "phenylalanine"
            Case "PRO" : iName = "proline"
            Case "SER" : iName = "serine"
            Case "THR" : iName = "threonine"
            Case "TRP" : iName = "tryptophan"
            Case "TYR" : iName = "tyrosine"
            Case "VAL" : iName = "valine"
            Case "UNK" : iName = "unknown"
            Case Else : Return ""
        End Select

        If Capitalize Then
            iName = UCase(Left(iName, 1)) & LCase(Mid(iName, 2))
        End If
        Return iName
    End Function

    Public Function StringToInt32(ByVal sString As String) As Int32
        Dim i As Int32
        Dim N As Int32 = 0

        For i = 1 To Len(sString)
            N += Asc(Mid(sString, i, 1))
        Next
        Return N
    End Function
End Module

Public Class AtomFilter
    Public set_Molecules As New RecordSet
    Public set_Chains As New RecordSet
    Public set_Residues As New RecordSet
End Class

Public Class GeometryAttributes
    Public a_AtomGeometry As AtomGeometry = AtomGeometry.Unknown
    Public a_AtomRadius As AtomRadius = AtomRadius.Unknown
    Public a_ConstRadius As Double = 1.0
    Public a_AtomColour As AtomColour = AtomColour.Unknown

    Public b_BondGeometry As BondGeometry = BondGeometry.Unknown
    Public b_SearchDepth As Int32 = 1000
    Public b_MeshFaceCount As Int32 = 3
    Public b_PipeRadius As Double = 0.25
    Public o_Group As Boolean = True
    Public o_IgnoreHydrogen As Boolean = False
    Public o_ApplyFilter As Boolean = False

    Public mol_Pointer As Molecule

    Public Sub New(Optional ByVal nAtomGeometry As AtomGeometry = AtomGeometry.Point, _
                   Optional ByVal nAtomRadius As AtomRadius = AtomRadius.Constant, _
                   Optional ByVal nAtomConstantRadius As Double = 1.0, _
                   Optional ByVal nAtomColour As AtomColour = AtomColour.None, _
                   Optional ByVal nBondGeometry As BondGeometry = BondGeometry.None, _
                   Optional ByVal nBondSearchDepth As Int32 = 100, _
                   Optional ByVal nBondFaceCount As Int32 = 3, _
                   Optional ByVal nBondRadius As Double = 0.25, _
                   Optional ByVal nGroupObjects As Boolean = True)
        a_AtomGeometry = nAtomGeometry
        a_AtomRadius = nAtomRadius
        a_ConstRadius = nAtomConstantRadius
        a_AtomColour = nAtomColour
        b_BondGeometry = nBondGeometry
        b_SearchDepth = nBondSearchDepth
        b_MeshFaceCount = nBondFaceCount
        b_PipeRadius = nBondRadius
        o_Group = nGroupObjects
    End Sub
End Class

Public Enum AtomColour
    Unknown = -1
    None = 0
    CPK = 1
    ByResidue = 2
    ByChain = 3
    ByMolecule = 4
    ByTemperature = 5
    ByOccupancy = 6
    ByPosition = 7
    BySequence = 8
    BySerialNumber = 9
End Enum

Public Enum AtomGeometry
    Unknown = -1
    None = 0
    Point = 1
    PointSet = 2
    NurbsSphere = 3
    HQ_MeshSphere = 4
    LQ_MeshSphere = 5
    MeshBox = 6
End Enum

Public Enum BondGeometry
    Unknown = -1
    None = 0
    Line = 1
    NurbsPipe = 2
    MeshPipe = 3
End Enum

Public Enum AtomRadius
    Unknown = 0
    AtomicRadius = 1
    BondingRadius = 2
    VanDerWaalsRadius = 3
    Constant = 4
End Enum

Public Enum AtomCode
    Unknown = -1
    Other = 0
    H = 1
    He = 2
    Li = 3
    Be = 4
    B = 5
    C = 6
    N = 7
    O = 8
    F = 9
    Ne = 10
    Na = 11
    Mg = 12
    Al = 13
    Si = 14
    P = 15
    S = 16
    Cl = 17
    Ar = 18
    K = 19
    Ca = 20
    Sc = 21
    Ti = 22
    V = 23
    Cr = 24
    Mn = 25
    Fe = 26
    Co = 27
    Ni = 28
    Cu = 29
    Zn = 30
    Ga = 31
    Ge = 32
    As_ = 33
    Se = 34
    Br = 35
    Kr = 36
    Rb = 37
    Sr = 38
    Y = 39
    Zr = 40
    Nb = 41
    Mo = 42
    Tc = 43
    Ru = 44
    Rh = 45
    Pd = 46
    Ag = 47
    Cd = 48
    In_ = 49
    Sn = 50
    Sb = 51
    Te = 52
    I = 53
    Xe = 54
    Cs = 55
    Ba = 56
    La = 57
    Hf = 72
    Ta = 73
    W = 74
    Re = 75
    Os = 76
    Ir = 77
    Pt = 78
    Au = 79
    Hg = 80
    Tl = 81
    Pb = 82
    Bi = 83
    Po = 84
    At = 85
    Rn = 86
    Fr = 87
    Ra = 88
    Ac = 89
    Rf = 104
    Db = 105
    Sg = 106
    Bh = 107
    Hs = 108
    Mt = 109
End Enum