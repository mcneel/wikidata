Imports RMA.Rhino
Imports RMA.OpenNURBS
Imports RMA.Rhino.RhUtil

'''<summary>
''' This is a custom command that is called by the docking dialog
'''</summary>
Public Class VBDockDlgMakeLine
  Inherits RMA.Rhino.MRhinoCommand

  '''<summary>
  ''' Rhino tracks commands by their unique ID. Every command must have a unique id.
  ''' The Guid created by the project wizard is unique. You can create more Guids using
  ''' the "Create Guid" tool in the Tools menu.
  '''</summary>
  '''<returns>The id for this command</returns>
  Public Overrides Function CommandUUID() As System.Guid
    Return New Guid("{248af639-58e6-4a14-924e-b541f1251d76}")
  End Function

  '''<returns>The command name as it appears on the Rhino command line</returns>
  Public Overrides Function EnglishCommandName() As String
    Return "VBDockDlgMakeLine"
  End Function

  '''<summary> This gets called when when the user runs this command.</summary>
  Public Overrides Function RunCommand(ByVal context As RMA.Rhino.IRhinoCommandContext) As RMA.Rhino.IRhinoCommand.result
    Dim random As New Random()
    Dim x1 As Double = random.NextDouble * 10
    Dim y1 As Double = random.NextDouble * 10
    Dim z1 As Double = random.NextDouble * 10
    Dim x2 As Double = random.NextDouble * 10
    Dim y2 As Double = random.NextDouble * 10
    Dim z2 As Double = random.NextDouble * 10

    Dim line As New OnLine(New On3dPoint(x1, y1, z1), New On3dPoint(x2, y2, z2))
    context.m_doc.AddCurveObject(line)
    context.m_doc.Redraw()

    Return IRhinoCommand.result.success
  End Function
End Class
