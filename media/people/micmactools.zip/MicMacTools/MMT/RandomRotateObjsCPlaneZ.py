import rhinoscriptsyntax as rs
import random

""" Script by Mitch Heynick  17 April 2013
    this script random rotates all selected objects between user set limits 
    Modified 20 April - added choice of World or CPlane Z axis """
    
def RandomRotateObjsCPlaneZ():
    objs=rs.GetObjects("Select objects to random rotate", preselect=True)
    if not objs: return
    
    min=rs.GetReal("Minimum rotation angle?")
    if min==None: return
    
    max=rs.GetReal("Maximum rotation angle?")
    if max==None: return
    
    if min==max==0: return
    
    resp=rs.GetBoolean("Rotation axis to use",[("Axis","CPlaneZ","WorldZ")],[False])
    if resp==None: return
    if resp[0]:
        axis=[0,0,1]
    else:
        axis=rs.ViewCPlane().ZAxis
    
    rs.EnableRedraw(False)
    for obj in objs:
        bb=rs.BoundingBox(obj)
        ctr=(bb[6]+bb[0])/2
        ang=random.randrange(min,max)
        rs.RotateObject(obj,ctr,ang,axis)
        
RandomRotateObjsCPlaneZ()