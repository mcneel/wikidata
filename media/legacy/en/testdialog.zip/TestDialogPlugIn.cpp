#include "StdAfx.h"
#include "TestDialogPlugIn.h"
#include "Resource.h"

#pragma warning( push )
#pragma warning( disable : 4073 )
#pragma init_seg( lib )
#pragma warning( pop )

// The one and only CTestDialogPlugIn object
static CTestDialogPlugIn thePlugIn;
 
// Returns reference to the plug-in object
CTestDialogPlugIn& TestDialogPlugIn() { return thePlugIn; }

// Rhino plug-in declaration
RHINO_PLUG_IN_DECLARE
RHINO_PLUG_IN_DEVELOPER_ORGANIZATION( L"My Company Name" );
RHINO_PLUG_IN_DEVELOPER_ADDRESS( L"123 Programmer Lane\r\nCity State 12345-6789" );
RHINO_PLUG_IN_DEVELOPER_COUNTRY( L"MY COUNTRY" );
RHINO_PLUG_IN_DEVELOPER_PHONE( L"123.456.7890" );
RHINO_PLUG_IN_DEVELOPER_FAX( L"123.456.7891" );
RHINO_PLUG_IN_DEVELOPER_EMAIL( L"product.support@mycompany.com" );
RHINO_PLUG_IN_DEVELOPER_WEBSITE( L"http://www.mycompany.com" );
RHINO_PLUG_IN_UPDATE_URL( L"ftp://ftp.mycompany.com/updateme.cab" );

CTestDialogPlugIn::CTestDialogPlugIn()
{
  m_sPlugInVersion = __DATE__"  "__TIME__;
}

CTestDialogPlugIn::~CTestDialogPlugIn()
{
}

const wchar_t* CTestDialogPlugIn::PlugInName() const
{
  return L"TestDialog";
}

const wchar_t* CTestDialogPlugIn::PlugInVersion() const
{
  return m_sPlugInVersion;
}

GUID CTestDialogPlugIn::PlugInID() const
{
  // {13D2CDBA-E6EE-4F9F-B880-8F2A212E1DE8}
  static const GUID TestDialogPlugIn_GUID =
  { 0x13D2CDBA, 0xE6EE, 0x4F9F, { 0xB8, 0x80, 0x8F, 0x2A, 0x21, 0x2E, 0x1D, 0xE8 } };
  return TestDialogPlugIn_GUID;
}

BOOL CTestDialogPlugIn::OnLoadPlugIn()
{
  return CRhinoUtilityPlugIn::OnLoadPlugIn();
}

void CTestDialogPlugIn::OnUnloadPlugIn()
{
  CRhinoUtilityPlugIn::OnUnloadPlugIn();
}

bool CTestDialogPlugIn::IsDialogVisible()
{
  return (m_pDialog) ? true : false;
}

void CTestDialogPlugIn::SetDialogFocus()
{
  if( m_pDialog )
    m_pDialog->SetFocus();
}

bool CTestDialogPlugIn::DisplayDialog()
{
  if( m_pDialog )
    return true;

  m_pDialog = new CTestModelessDialog();
  if( m_pDialog->Create(IDD_DIALOG2, CWnd::FromHandle(RhinoApp().MainWnd())) )
  {
    m_pDialog->ShowWindow( SW_SHOW );
	 	m_pDialog->UpdateWindow();
    return true;
  }

  return false;
}

void CTestDialogPlugIn::DestroyDialog()
{
  m_pDialog = NULL;
}

