import rhinoscriptsyntax as rs
import scriptcontext as sc
from Rhino import RhinoMath

def ac_filt(rhino_object, geometry, component_index):
    return geometry.IsCircle() or geometry.IsArc()

def SelSameRadArcsCircles():
    entity="arc"
    entity2="circle"
    measure="radius"
    msg="Select {} or {} to match {}".format(entity,entity2,measure)
    arc=rs.GetObject(msg,4,preselect=True,select=True,custom_filter=ac_filt)
    if not arc: return
    ref_rad=rs.ArcRadius(arc)
    tol=sc.doc.ModelAbsoluteTolerance
    ff=RhinoMath.SqrtEpsilon #"fuzz factor"
    
    rs.EnableRedraw(False)
    objs=rs.ObjectsByType(4,state=1)
    for obj in objs:
        if rs.IsCircle(obj) or rs.IsArc(obj):
            if RhinoMath.EpsilonEquals(rs.ArcRadius(obj),ref_rad,ff):
                rs.SelectObject(obj)
                
    selObjs=rs.SelectedObjects() #original is always selected
    msg="found that match selection criteria"
    q=len(selObjs)-1
    if q==0 or q>1:
        entity+="s" ; entity2+="s"
        if q==0: q="No other"
    print "{} {} or {} {}".format(q,entity,entity2,msg)
    
SelSameRadArcsCircles()