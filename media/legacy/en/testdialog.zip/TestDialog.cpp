#include "StdAfx.h"
#include "TestDialog.h"

BEGIN_MESSAGE_MAP(CTestDialogApp, CWinApp)
	//{{AFX_MSG_MAP(CTestDialogApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CTestDialogApp::CTestDialogApp()
{
}

// The one and only CTestDialogApp object
CTestDialogApp theApp;
