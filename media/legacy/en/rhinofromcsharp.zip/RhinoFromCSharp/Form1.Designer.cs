namespace RhinoFromCSharp
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
      this.m_btnDrawLines = new System.Windows.Forms.Button();
      this.m_btnShowRhino = new System.Windows.Forms.Button();
      this.m_btnHideRhino = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // m_btnDrawLines
      // 
      this.m_btnDrawLines.Location = new System.Drawing.Point(46, 47);
      this.m_btnDrawLines.Name = "m_btnDrawLines";
      this.m_btnDrawLines.Size = new System.Drawing.Size(120, 30);
      this.m_btnDrawLines.TabIndex = 4;
      this.m_btnDrawLines.Text = "Draw Lines";
      this.m_btnDrawLines.UseVisualStyleBackColor = true;
      this.m_btnDrawLines.Click += new System.EventHandler(this.m_btnDrawLines_Click);
      // 
      // m_btnShowRhino
      // 
      this.m_btnShowRhino.Location = new System.Drawing.Point(46, 11);
      this.m_btnShowRhino.Name = "m_btnShowRhino";
      this.m_btnShowRhino.Size = new System.Drawing.Size(120, 30);
      this.m_btnShowRhino.TabIndex = 3;
      this.m_btnShowRhino.Text = "Show Rhino";
      this.m_btnShowRhino.UseVisualStyleBackColor = true;
      this.m_btnShowRhino.Click += new System.EventHandler(this.m_btnShowRhino_Click);
      // 
      // m_btnHideRhino
      // 
      this.m_btnHideRhino.Location = new System.Drawing.Point(46, 83);
      this.m_btnHideRhino.Name = "m_btnHideRhino";
      this.m_btnHideRhino.Size = new System.Drawing.Size(120, 30);
      this.m_btnHideRhino.TabIndex = 5;
      this.m_btnHideRhino.Text = "Hide Rhino";
      this.m_btnHideRhino.UseVisualStyleBackColor = true;
      this.m_btnHideRhino.Click += new System.EventHandler(this.m_btnHideRhino_Click);
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(212, 125);
      this.Controls.Add(this.m_btnHideRhino);
      this.Controls.Add(this.m_btnDrawLines);
      this.Controls.Add(this.m_btnShowRhino);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "Form1";
      this.Text = "Rhino - C# App";
      this.ResumeLayout(false);

    }

    #endregion

    internal System.Windows.Forms.Button m_btnDrawLines;
    internal System.Windows.Forms.Button m_btnShowRhino;
    internal System.Windows.Forms.Button m_btnHideRhino;
  }
}

