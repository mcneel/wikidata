BOOL AddGlobalVar()
{
  LPCSTR lpszAtom = "$RMA$AUTORUN$";
	ATOM atom = 0;

  // Check to see if it is already running, if it is then bail.
	atom = GlobalFindAtom( lpszAtom);

	if( atom)
		return FALSE;

 	if( !atom)
		atom = GlobalAddAtom( lpszAtom);

  if( atom)
    return TRUE;

  return FALSE;
}

BOOL DeleteGlobalVar()
{
  LPCSTR lpszAtom = "$RMA$AUTORUN$";
	ATOM atom = 0;

  // Check to see if it is already running, if it is then bail.
	atom = GlobalFindAtom( lpszAtom);

  if( !atom)
    return TRUE;

  return( GlobalDeleteAtom( atom) == 0);
}

