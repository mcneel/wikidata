Imports RMA.OpenNURBS
Imports System.Math

Public Class InflectionFinder
  Protected m_Curve As OnNurbsCurve
  Protected m_Inflections As New List(Of CurveInflection)

#Region "Construction"
  Public Sub New(ByVal iCurve As IOnCurve)
    If (iCurve Is Nothing) Then
      Throw New Exception("CInflectionFinder can only be constructed with a proper OnCurve reference")
    End If

    Me.m_Curve = New OnNurbsCurve
    If (iCurve.GetNurbForm(Me.m_Curve, RMA.Rhino.RhUtil.RhinoApp.ActiveDoc.AbsoluteTolerance) = 0) Then
      Throw New Exception("CInflectionFinder constructor failed to create a valid Nurbs curve from the input")
    End If

    Me.CalculateAllInflections()
  End Sub
#End Region

#Region "Properties"
  Public ReadOnly Property Inflections() As List(Of CurveInflection)
    Get
      Return Me.m_Inflections
    End Get
  End Property
#End Region

#Region "Inflection logic"
  Protected Sub CalculateAllInflections()
    Me.m_Inflections.Clear()

    Dim cSpan As New List(Of CurveSpan)
    Me.AppendSpanIntervals(cSpan)

    If (cSpan.Count = 0) Then Return

    For Each Span As CurveSpan In cSpan
      If (Me.IsSegmentLinear(Span)) Then Continue For
      Me.SolveInflections(Span)
    Next
  End Sub

  'Protected Sub AppendSpanIntervals(ByVal cList As List(Of CurveSpan))
  '  cList.Clear()

  '  Dim kPrev As Double = Me.m_Curve.Knot(0)
  '  Dim k As Double = Double.NaN

  '  For i As Int32 = 1 To Me.m_Curve.KnotCount - 1
  '    k = Me.m_Curve.Knot(i)

  '    If (k > kPrev) Then
  '      cList.Add(New CurveSpan(kPrev, k))
  '      kPrev = k
  '    End If
  '  Next
  'End Sub
  Protected Sub AppendSpanIntervals(ByVal cList As List(Of CurveSpan))
    cList.Clear()

    Dim kPrev As Double = Me.m_Curve.Knot(0)
    Dim k As Double = Double.NaN

    For i As Int32 = 1 To Me.m_Curve.KnotCount - 1
      k = Me.m_Curve.Knot(i)

      If (k > kPrev) Then
        If (Me.m_Curve.Degree < 4) Then
          'Degree 3 and less can only have 1 inflection point per span, we can afford to be coarse
          cList.Add(New CurveSpan(kPrev, k))
        Else
          'Degree 4 and above can have multiple inflections per span, we have to be careful
          Dim jStep As Double = 0.005 * (k - kPrev)

          For j As Double = kPrev To k - (0.5 * jStep) Step jStep
            cList.Add(New CurveSpan(j, j + jStep))
          Next
        End If

        kPrev = k
      End If
    Next
  End Sub

  Protected Const epsilon As Double = 1.0E-20
  Protected Const spanstep As Double = 0.1

  Protected Function SolveInflections(ByVal Span As CurveSpan, Optional ByVal depth As Int32 = 0) As Boolean
    If (depth > 25) Then
      RMA.Rhino.RhUtil.RhinoApp.Print("Inflection routine aborted due to excessive recursion depth..." & vbCrLf)
      Return False
    End If

    Dim rc As Boolean = False

    Dim kappa0 As Double = Double.NaN
    Dim kappa1 As Double = Double.NaN

    Dim prev_inflection As CurveInflection = Nothing
    Dim kappa_hint As New On3dVector(0, 0, 0)

    Dim c_param As Double

    For t As Double = 0.0 To (1.0 + (0.1 * spanstep)) Step spanstep
      c_param = Span.ValueAt(t)
      kappa0 = kappa1

      If (t = 0.0) Then
        kappa1 = Me.SolveInflectionAmplitude(c_param, kappa_hint, +1)
      Else
        kappa1 = Me.SolveInflectionAmplitude(c_param, kappa_hint, -1)
      End If

      If (Double.IsNaN(kappa1)) Then Continue For

      If (Math.Abs(kappa1) < epsilon) Then
        Dim pInflection As New CurveInflection(c_param, kappa1, Me.m_Curve.PointAt(c_param), Me.m_Curve.TangentAt(c_param))

        If (prev_inflection Is Nothing) Then
          Me.m_Inflections.Add(pInflection)
          prev_inflection = pInflection
        Else
          If (Math.Abs(prev_inflection.Kappa) < Math.Abs(kappa1)) Then
            'The previous point was more accurate, ignore this solution
            Continue For
          Else
            'This point is more accurate, remove the previous solution
            Me.m_Inflections.RemoveAt(Me.m_Inflections.Count - 1)

            Me.m_Inflections.Add(pInflection)
            prev_inflection = pInflection
          End If
        End If

        rc = True
        Continue For
      End If

      prev_inflection = Nothing

      If (Double.IsNaN(kappa0)) Then Continue For

      If (Math.Sign(kappa1) <> Math.Sign(kappa0)) AndAlso (Math.Abs(kappa0) > epsilon) Then
        'we have opposing signs, there is an inflection point in between kPrev and k
        rc = rc And SolveInflections(Span.SubSet(t - spanstep, t), depth + 1)
      End If
    Next

    Return rc
  End Function

  Protected Function SolveInflectionAmplitude(ByVal t As Double, ByRef hint As On3dVector, ByVal side As Int32) As Double
    Dim ev_pt As New On3dPoint
    Dim ev_tan As New On3dVector
    Dim ev_kappa As New On3dVector

    If Me.m_Curve.EvCurvature(t, ev_pt, ev_tan, ev_kappa, side) Then
      If (hint.IsZero) Then hint.Set(ev_kappa.x, ev_kappa.y, ev_kappa.z)

      Dim fSign As Int32 = +1
      If (ev_kappa.IsParallelTo(hint, 0.5 * Math.PI) < 0) Then fSign = -1

      hint.Set(ev_kappa.x, ev_kappa.y, ev_kappa.z)
      Return fSign * ev_kappa.LengthSquared()

    Else
      Return Double.NaN
    End If
  End Function
  Protected Function IsSegmentLinear(ByVal Span As CurveSpan) As Boolean
    Dim lSegment As New OnLine(Me.m_Curve.PointAt(Span.A), Me.m_Curve.PointAt(Span.B))
    Dim linearity_accuracy As Double = 0.0000000001

    If (lSegment.DistanceTo(Me.m_Curve.PointAt(Span.ValueAt(0.2))) > linearity_accuracy) Then Return False
    If (lSegment.DistanceTo(Me.m_Curve.PointAt(Span.ValueAt(0.5))) > linearity_accuracy) Then Return False
    If (lSegment.DistanceTo(Me.m_Curve.PointAt(Span.ValueAt(0.8))) > linearity_accuracy) Then Return False

    Return True
  End Function
#End Region
End Class

Public Class CurveSpan
  Protected m_Span As OnInterval

  Public Sub New(ByVal dFrom As Double, ByVal dTo As Double)
    Me.m_Span = New OnInterval(dFrom, dTo)
  End Sub
  Public Sub New(ByVal nSpan As CurveSpan)
    Me.m_Span = New OnInterval(nSpan.m_Span)
  End Sub

  Public Property Span() As OnInterval
    Get
      Return Me.m_Span
    End Get
    Set(ByVal value As OnInterval)
      Me.m_Span = value
    End Set
  End Property
  Public Property A() As Double
    Get
      Return Me.m_Span.m_t(0)
    End Get
    Set(ByVal value As Double)
      Me.m_Span.m_t(0) = value
    End Set
  End Property
  Public Property B() As Double
    Get
      Return Me.m_Span.m_t(1)
    End Get
    Set(ByVal value As Double)
      Me.m_Span.m_t(1) = value
    End Set
  End Property
  Public Function ValueAt(ByVal t As Double) As Double
    Return Me.m_Span.m_t(0) + t * (Me.m_Span.m_t(1) - Me.m_Span.m_t(0))
  End Function

  Public Function SubSet(ByVal t0 As Double, ByVal t1 As Double) As CurveSpan
    Return New CurveSpan(Me.ValueAt(t0), Me.ValueAt(t1))
  End Function
End Class

Public Class CurveInflection
  Protected m_Parameter As Double
  Protected m_Kappa As Double

  Protected m_Point As On3dPoint
  Protected m_Tangent As On3dVector

  Public Sub New(ByVal nParameter As Double, _
                 ByVal nKappa As Double, _
                 ByVal nPoint As IOn3dPoint, _
                 ByVal nTangent As IOn3dVector)

    Me.m_Parameter = nParameter
    Me.m_Kappa = nKappa
    Me.m_Point = New On3dPoint(nPoint)
    Me.m_Tangent = New On3dVector(nTangent)
  End Sub

  Public ReadOnly Property Point() As On3dPoint
    Get
      Return Me.m_Point
    End Get
  End Property
  Public ReadOnly Property Tangent() As On3dVector
    Get
      Return Me.m_Point
    End Get
  End Property
  Public ReadOnly Property Parameter() As Double
    Get
      Return Me.m_Parameter
    End Get
  End Property
  Public ReadOnly Property Kappa() As Double
    Get
      Return Me.m_Kappa
    End Get
  End Property
End Class