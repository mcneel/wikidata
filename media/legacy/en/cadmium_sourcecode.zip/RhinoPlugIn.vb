Option Strict On

Public Class RhinoPlugIn
  Inherits RMA.Rhino.MRhinoUtilityPlugIn

  Public Overrides ReadOnly Property PlugInName() As String
    Get
            Return "Molecular modeling"
    End Get
  End Property
End Class
