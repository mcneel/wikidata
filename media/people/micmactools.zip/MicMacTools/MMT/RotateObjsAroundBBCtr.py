import rhinoscriptsyntax as rs
import scriptcontext as sc

def RotateObjsAroundBBCtr():
    msg="Select objects to rotate"
    objs=rs.GetObjects(msg,preselect=True,select=True)
    if not objs: return
    if "RAC_ANG" in sc.sticky: user_ang = sc.sticky["RAC_ANG"]
    else: user_ang = 90
    ang=rs.GetReal("Rotation angle?",user_ang)
    if ang is None: return
    
    rs.EnableRedraw(False)
    for obj in objs:
        bb=rs.BoundingBox(obj)
        if bb: rs.RotateObject(obj,(bb[0]+bb[6])/2,ang,copy=False)
    sc.sticky["RAC_ANG"] = ang
RotateObjsAroundBBCtr()