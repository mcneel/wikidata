"""Removes any custom display mode that has been set for one or more objects 
in all viewports.  Script by Mitch Heynick 26.08.15"""

import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def RemObjDisplayModeAllViewports():
    msg="Select objects to reset display mode to default"
    objIDs=rs.GetObjects(msg,8+16+32,preselect=True)
    if not objIDs: return
        
    vIDs=[view.ActiveViewportID for view in sc.doc.Views]
    for vID in vIDs:
        for objID in objIDs:
            objRef=sc.doc.Objects.Find(objID)
            attr = objRef.Attributes
            attr.RemoveDisplayModeOverride(vID)
            sc.doc.Objects.ModifyAttributes(objID, attr, False)
    sc.doc.Views.Redraw()
    
RemObjDisplayModeAllViewports()