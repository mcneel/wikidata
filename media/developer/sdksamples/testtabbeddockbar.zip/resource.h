//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TestTabbedDockBar.rc
//
#define IDD_TESTTABBEDDOCKBAR_DIALOG    30000
#define IDC_CLICKME_BUTTON              30000
#define IDI_ICON1                       30001
#define IDI_TESTTABBEDDOCKBAR_ICON      30001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        30002
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         30001
#define _APS_NEXT_SYMED_VALUE           30000
#endif
#endif
