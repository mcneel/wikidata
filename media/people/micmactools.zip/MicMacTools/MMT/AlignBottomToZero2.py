import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

"""Aligns a set of objects lowest points to World or CPlane 0.
Uses either World (default) or active CPlane for reference.
Indivudually(default) - each object is aligned to 0 individually
(group relationship is not preserved, objects move separately)
AsGroup - lowest point of the group is found, that point is aligned to 0 
(group relationship is preserved, objects move together)
If objects preselected, previous or default setting is used."""

def GetObjsPlusBool(prompt,b_opts1,b_opts2,def_1,def_2,filter):
    #prompt==command line prompt
    #b_opts==tuple of strings for Boolean choices - (Name,FalseValue,TrueValue)
    #def_1==default value for Boolean
    #returns None if Esc is pressed or no objects are chosen
    #otherwise, returns tuple of ([object ids], Boolean)
    
    go = Rhino.Input.Custom.GetObject()
    go.SetCommandPrompt(prompt)
    boolOption1 = Rhino.Input.Custom.OptionToggle(def_1,b_opts1[1],b_opts1[2])
    boolOption2 = Rhino.Input.Custom.OptionToggle(def_2,b_opts2[1],b_opts2[2])
    go.AddOptionToggle(b_opts1[0], boolOption1)
    go.AddOptionToggle(b_opts2[0], boolOption2)
    go.GeometryFilter=filter
    while True:
        get_rc = go.GetMultiple(1,0)
        if get_rc==Rhino.Input.GetResult.Cancel: return
        elif get_rc==Rhino.Input.GetResult.Option: continue
        elif get_rc==Rhino.Input.GetResult.Object: break
        else: return
    ids = [go.Object(i).ObjectId for i in range(go.ObjectCount)]
    return (ids,boolOption1.CurrentValue,boolOption2.CurrentValue)

def AlignBottomToWorldZero():
    msg="Select objects to align botttom to 0"
    bool_opts1=("TransformObjects","Individually","AsGroup")
    bool_opts2=("CPlane","Current","World")
    ot=Rhino.DocObjects.ObjectType()
    filt = ot.Curve | ot.Brep | ot.Mesh | ot.Extrusion
    
    #Get previous settings
    if "ABT0_Group" in sc.sticky: group_objs = sc.sticky["ABT0_Group"]
    else: group_objs = False
    if "ABT0_Plane" in sc.sticky: world_plane = sc.sticky["ABT0_Plane"]
    else: world_plane = True
    
    result=GetObjsPlusBool(msg,bool_opts1,bool_opts2,group_objs,world_plane,filt)
    if result is None: return
    objs=result[0]
    
    rs.EnableRedraw(False)
    if result[2]: plane=rs.WorldXYPlane()
    else: plane=rs.ViewCPlane()
    if result[1]:
        #transform objects as group
        if not result[2]:
            #transform in active CPlane
            bb=rs.BoundingBox(objs,plane,False) #CPlane coords
            if bb: rs.MoveObjects(objs,-bb[0].Z*plane.Normal)
        else:
            #transform in World
            bb=rs.BoundingBox(objs)
            if bb: rs.MoveObjects(objs,Rhino.Geometry.Vector3d(0,0,-bb[0][2]))
    else:
        #transform objects individually
        if not result[2]:
            #transform in active CPlane
            for obj in objs:
                bb=rs.BoundingBox(obj,plane,False)
                if bb: rs.MoveObject(obj,-bb[0].Z*plane.Normal)
        else:
            #transform in World
            for obj in objs:
                bb=rs.BoundingBox(obj)
                if bb: rs.MoveObject(obj,Rhino.Geometry.Vector3d(0,0,-bb[0][2]))
    sc.sticky["ABT0_Group"] = result[1]
    sc.sticky["ABT0_Plane"] = result[2]
AlignBottomToWorldZero()

