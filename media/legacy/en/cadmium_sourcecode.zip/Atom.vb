Public Class Atom
    Public x, y, z As Double
    Public SerialNumber As Int32 = -1
    Public MoleculeNumber As Int32 = -1
    Public ResidueSequence As Int32 = -1
    Public ElementType As AtomCode = AtomCode.Unknown
    Public Name As String = ""
    Public Residue As String = ""
    Public Chain As String = ""
    Public Occupancy As Double = 0
    Public TempFactor As Double = 0
    Public Segment As String = ""
    Public Charge As String = ""

    Public Function ReadFromASCII(ByVal datLine As String, Optional ByVal nMolecule As Int32 = -1) As Boolean
        Try
            x = System.Convert.ToDouble(Trim(Mid(datLine, 31, 8)))
            y = System.Convert.ToDouble(Trim(Mid(datLine, 39, 8)))
            z = System.Convert.ToDouble(Trim(Mid(datLine, 47, 8)))

            MoleculeNumber = nMolecule

            TempFactor = System.Convert.ToDouble(Trim(Mid(datLine, 61, 6)))
            Occupancy = System.Convert.ToDouble(Trim(Mid(datLine, 55, 6)))

            SerialNumber = System.Convert.ToInt32(Trim(Mid(datLine, 7, 5)))
            ResidueSequence = System.Convert.ToInt32(Trim(Mid(datLine, 23, 4)))

            Residue = Trim(Mid(datLine, 18, 3))
            Chain = Trim(Mid(datLine, 22, 1))
            Segment = Trim(Mid(datLine, 73, 4))
            Charge = Trim(Mid(datLine, 79, 2))

            ElementType = Definitions.ToElementType(UCase(Trim(Mid(datLine, 77, 2))))
            If ElementType = AtomCode.Unknown Then
                Dim iAtomName As String = UCase(Trim(Mid(datLine, 13, 4)))
                If Len(iAtomName) > 0 Then
                    ElementType = Definitions.ToElementType(Decoder.StripNonAlpha(iAtomName))
                End If
            End If

            CreateDefaultName()
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Sub New(Optional ByVal nX As Double = 0.0, _
                   Optional ByVal nY As Double = 0.0, _
                   Optional ByVal nZ As Double = 0.0, _
                   Optional ByVal nType As AtomCode = AtomCode.Unknown)
        x = nX
        y = nY
        z = nY
        ElementType = nType
    End Sub

    Public Sub CreateDefaultName()
        'Atom(Element[Serial])@1 Chain:A Residue:AAA TempFactor:0.0 Occupancy:0.0
        Name = String.Format("Atom({0}[" & SerialNumber & "])@{1} Chain:{2} ", Definitions.ToElementName(Me.ElementType, True), Me.MoleculeNumber, Me.Chain)
        Name &= String.Format("Residue:{0} TempFactor:{1} Occupancy:{2}", Me.Residue, Me.TempFactor, Me.Occupancy)
    End Sub

    Public Function CastONPoint() As RMA.OpenNURBS.IOn3dPoint
        Return New RMA.OpenNURBS.On3dPoint(x, y, z)
    End Function

    Public Function CastOnSurface(Optional ByVal rType As AtomRadius = AtomRadius.AtomicRadius) As RMA.OpenNURBS.IOnSurface
        Dim iSphere As New RMA.OpenNURBS.OnSphere(CastONPoint, Definitions.ToElementRadius(Me.ElementType, rType))
        Dim iSurface As New RMA.OpenNURBS.OnNurbsSurface
        iSphere.GetNurbForm(iSurface)
        Return iSurface
    End Function

    Public Function CastOnMeshSphere(ByVal rType As AtomRadius, _
                                     Optional ByVal HQ_Mesh As Boolean = True) As RMA.OpenNURBS.OnMesh
        Dim iRadius As Double = Definitions.ToElementRadius(Me.ElementType, rType)
        If HQ_Mesh Then
            Return GeometryLibrary.HQ_Mesh(iRadius, x, y, z)
        Else
            Return GeometryLibrary.LQ_Mesh(iRadius, x, y, z)
        End If
    End Function

    Public Function CastOnMeshSphere(ByVal rRadius As Double, _
                                     Optional ByVal HQ_Mesh As Boolean = True) As RMA.OpenNURBS.OnMesh
        If HQ_Mesh Then
            Return GeometryLibrary.HQ_Mesh(rRadius, x, y, z)
        Else
            Return GeometryLibrary.LQ_Mesh(rRadius, x, y, z)
        End If
    End Function

    Public Function CastOnMeshBox(Optional ByVal rType As AtomRadius = AtomRadius.AtomicRadius, _
                                  Optional ByVal HQ_Mesh As Boolean = True) As RMA.OpenNURBS.IOnMesh
        Dim iRadius As Double = Definitions.ToElementRadius(Me.ElementType, rType)
        Return GeometryLibrary.MeshBox(iRadius, x, y, z)
    End Function

    Public Function CastOnColor(ByVal aProps As GeometryAttributes) As RMA.OpenNURBS.IOnColor
        Return Definitions.ToElementColour(Me, aProps)
    End Function

    Public Function IsWithinBondingRange(ByVal sAtom As Atom) As Boolean
        Dim iDistance As Double = ((x - sAtom.x) * (x - sAtom.x)) + _
                                  ((y - sAtom.y) * (y - sAtom.y)) + _
                                  ((z - sAtom.z) * (z - sAtom.z))
        iDistance = System.Math.Sqrt(iDistance)
        Dim iRadius As Double = Definitions.ToElementRadius(Me.ElementType, AtomRadius.BondingRadius) + _
                                Definitions.ToElementRadius(sAtom.ElementType, AtomRadius.BondingRadius) + 0.25
        Return CBool(iDistance <= iRadius)
    End Function
End Class
