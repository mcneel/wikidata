import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino
"""Script by Mitch Heynick 03.07.15 - GetColor() is not hooked up yet on MAC
Temporary substitute RGB entry via command line"""

def ParseRGBString(input_string):
    #expects a string "rrr,ggg,bbb"
    #returns a tuple of rgb integers if successful or None if not
    rgb=input_string.split(",")
    if not rgb or len(rgb) !=3: return
    if rgb[0].isdigit() and rgb[1].isdigit() and rgb[2].isdigit():
        r=int(rgb[0]) ; g=int(rgb[1]) ; b=int(rgb[2])
        if r != None and g != None and b != None:
            if (r>=0 and r<=255) and (g>=0 and g<=255) and (b>=0 and b<=255):
                return (r,g,b)

def SetBackgroundColor():
    currColor=rs.AppearanceColor(0)
    #modify following as desired
    color_list=["White","LtGray190","MedGray130","DkGray70","Black","RGB"] 
    while True:
        choice=rs.GetString("New background color",strings=color_list)
        if not choice: return
        if choice not in color_list:
            print "Invalid entry" ; continue
        else: break
    if choice==color_list[0]:
        rs.AppearanceColor(0,(255,255,255))
    elif choice==color_list[1]:
        rs.AppearanceColor(0,(190,190,190))
    elif choice==color_list[2]:
        rs.AppearanceColor(0,(130,130,130))
    elif choice==color_list[3]:
        rs.AppearanceColor(0,(70,70,70))
    elif choice==color_list[4]:
        rs.AppearanceColor(0,(0,0,0))
    elif choice==color_list[-1]:
        #color=rs.GetColor() #not working on Mac, use r, g, b entry
        r=rs.GetInteger("Red component",255,0,255)
        if r is None: return
        g=rs.GetInteger("Green component",255,0,255)
        if g is None: return
        b=rs.GetInteger("Blue component",255,0,255)
        if b is None: return
        color=rs.coercecolor([r,g,b])
        if color is None: return
        rs.AppearanceColor(0,color)
    else:
        return
SetBackgroundColor()