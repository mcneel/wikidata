// NOTE!!!
// In order to get external access to Rhino from a separate program, we need
// to use the Rhino and RhinoScript COM interfaces.
// Make sure your project has references for the Rhino and RhinoScript type
// libraries

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RhinoFromCSharp
{
  public partial class Form1 : Form
  {
    private Rhino4.Application m_rhino;
    private RhinoScript4.IRhinoScript m_rhinoscript;

    public Form1()
    {
      InitializeComponent();
      m_rhino = null;
      m_rhinoscript = null;
    }

    // this function ensures that we have a connection to rhino and rhinoscript
    private bool ConnectToRhinoScript()
    {
      if (m_rhino == null)
      {
        this.UseWaitCursor = true;
        m_rhino = new Rhino4.Application();

        // when rhino first loads, it needs to load up the RhinoScript plug-in which
        // can take a little time. Make a few attempts to get rhinoscript interface
        int attempts = 10;
        for (int i = 0; i < attempts; i++)
        {
          //sleep for a half a second to allow rhino load rhinoscript
          System.Threading.Thread.Sleep(500);
          object obj = m_rhino.GetScriptObject();
          if (obj != null)
          {
            // we got it
            m_rhinoscript = (RhinoScript4.IRhinoScript)obj;
            break;
          }
        }
        this.UseWaitCursor = false;
      }
      return (m_rhinoscript != null);
    }

    private void m_btnShowRhino_Click(object sender, EventArgs e)
    {
      if (ConnectToRhinoScript())
        m_rhino.Visible = 1; // 1 == true
    }

    private void m_btnDrawLines_Click(object sender, EventArgs e)
    {
      if (ConnectToRhinoScript())
      {
        // Draw some stuff
        List<double[]> list = new List<double[]>();
        list.Add(new double[] {0, 0, 0});
        list.Add(new double[] {10, 0, 0});
        list.Add(new double[] {10, 10, 0});
        list.Add(new double[] {0, 10, 0});
        list.Add(new double[] {0, 0, 0});
        list.Add(new double[] {10, 10, 0});
        list.Add(new double[] {0, 10, 0});
        list.Add(new double[] {10, 0, 0});

        for( int i=0; i<list.Count-1; i++)
          m_rhinoscript.AddLine( list[i], list[i+1] );
      }
    }

    private void m_btnHideRhino_Click(object sender, EventArgs e)
    {
      if (ConnectToRhinoScript())
        m_rhino.Visible = 0; // 0 == false
    }
  }
}