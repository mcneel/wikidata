Imports RMA.Rhino

Public Class MyUserControl
  Public Sub New()
    ' This call is required by the Windows Form Designer.
    InitializeComponent()
  End Sub

  Public Shared Function BarID() As Guid
    Dim g As New Guid("{91A2D5CD-CC07-4ab6-8C74-00ED4F416924}")
    Return g
  End Function

  ' This function is called when the 'Print to Command Line' button is clicked
  ' Takes the contents of the textbox and post it to the command line
  Private Sub m_btnPrintToCommandLine_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles m_btnPrintToCommandLine.Click
    Dim message As String = m_textbox.Text + vbCrLf
    RhUtil.RhinoApp.Print(message)
  End Sub


  ' This function is called when the 'Make Line' button is clicked
  ' The best way to modify the document is by running a command. This event
  ' handler just turns around and calls our hidden command
  Private Sub m_btnMakeLine_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles m_btnMakeLine.Click
    'This makes it so thing like undo will work
    RhUtil.RhinoApp.RunScript("VBDockDlgMakeLine")
  End Sub

End Class
