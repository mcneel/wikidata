ArchCut Scripting Help

Notes:

To access ArchCut help from inside Monkey scripting editor, save ArchCut.chm and ArchCut.dec files inside the following folder:
.../Program Files/Rhino.../Plug-ins/Monkey/Resources

If you don't have or use Monkey scripting editor, you can save ArchCut.chm files in any location.