import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino
"""Script to transform non-planar curves into planar cuves using either
best-fit plane or current view CPlane. Works best with "near planar" curves.
Non-polyline curves will be "sampled" with 100 points to find best fit plane
Script by Mitch Heynick 17.06.15"""

def CommandLineOptions(prompt,msg1,b_opts1,msg2,b_opts2):
    go = Rhino.Input.Custom.GetOption()
    go.SetCommandPrompt(prompt)    
    # set up the options
    boolOption1 = Rhino.Input.Custom.OptionToggle(*b_opts1)
    boolOption2 = Rhino.Input.Custom.OptionToggle(*b_opts2)
    go.AddOptionToggle(msg1, boolOption1)
    go.AddOptionToggle(msg2, boolOption2)
    go.AcceptNothing(True)
    
    #let the user input
    while True:
        get_rc = go.Get()
        if go.CommandResult()== Rhino.Commands.Result.Cancel:
            return
        elif go.CommandResult()== Rhino.Commands.Result.Nothing:
            break
        elif get_rc==Rhino.Input.GetResult.Option:
            continue
        break
    return boolOption1.CurrentValue, boolOption2.CurrentValue

def MaxDeviationInPlane(obj, plane):
    bb = rs.BoundingBox(obj, plane, False)
    if bb: return (bb[0].DistanceTo(bb[4]))*0.5

def PlanarizeCurves():
    sample = 100
    msg="Select near-planar curves to planarize"
    crvs = rs.GetObjects(msg,4,preselect=True)
    if not crvs: return
    pick_view = rs.CurrentView()
    
    #get previous settings
    if "Planarize_C_Proj" in sc.sticky: pc_proj = sc.sticky["Planarize_C_Proj"]
    else: pc_proj = True
    if "Planarize_C_Del" in sc.sticky: pc_del = sc.sticky["Planarize_C_Del"]
    else: pc_del = True
    
    #get user input
    prompt="Planarize options:"
    msg1="ProjectionType"
    msg2="DeleteInput"
    opts1=(pc_proj,"ActiveCPlaneParallel", "BestFitPlane")
    opts2=(pc_del,"No","Yes")
    user_opts=CommandLineOptions(prompt,msg1,opts1,msg2,opts2)
    if not user_opts: return
    plane_choice, del_choice=user_opts
    
    #initialize and run
    prec = rs.UnitDistanceDisplayPrecision()
    unit_sys_name = rs.UnitSystemName(False, False, True)
    max_dev = 0.0 ; bad_crvs = 0 ; new_crvs=[]
    rs.EnableRedraw(False)
    for crv in crvs:
        if plane_choice:
            if rs.IsPolyline(crv) :
                pts = rs.CurvePoints(crv)
            else:
                pts = rs.DivideCurve(crv, sample, False)
            bf_plane = rs.PlaneFitFromPoints(pts)
        else:
            bb = rs.BoundingBox(crv, pick_view, False)
            bf_plane = rs.ViewCPlane(pick_view)
            bf_plane.Origin = (bb[0]+bb[6])/2
            
        if bf_plane:
            dev = MaxDeviationInPlane(crv, bf_plane)
            xform = rs.XformPlanarProjection(bf_plane)
            new_crv = rs.TransformObject(crv, xform, not del_choice)
            if new_crv: new_crvs.append(new_crv)
            if dev is not None and dev > max_dev: max_dev = dev
        else: bad_crvs+=1
    if new_crvs: rs.SelectObjects(new_crvs)
    
    #reporting
    msg="{} curves planarized - max deviation: ".format(len(crvs)-bad_crvs)
    msg+="{} {}".format(round(max_dev,prec),unit_sys_name)
    if bad_crvs>0: msg+=" || {} curves unable to be processed".format(bad_crvs)
    print msg
    #store options
    sc.sticky["Planarize_C_Proj"] = plane_choice
    sc.sticky["Planarize_C_Del"] = del_choice
PlanarizeCurves()