import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def AveragePoints():
    msg="Select points and/or pointclouds to average"
    objs=rs.GetObjects(msg,1+2,preselect=True)
    if not objs: return
    p=rs.UnitDistanceDisplayPrecision()
    master_ptlist=[]
    for obj in objs:
        if rs.IsPoint(obj):
            master_ptlist.append(rs.PointCoordinates(obj))
        else:
            master_ptlist.extend(rs.PointCloudPoints(obj))
    if len(master_ptlist)>1:
        apt = reduce(lambda x, y: x+y, master_ptlist)/len(master_ptlist)
    else:
        apt = master_ptlist[0]
    if not apt: 
        print "Unable to calculate average point" ; return
    rs.SelectObject(rs.AddPoint(apt))
    msg="Average point: "
    print "{} ({}, {}, {})".format(msg,round(apt.X,p),round(apt.Y,),round(apt.Z,p))
AveragePoints()