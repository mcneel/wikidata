"""Attempts to replace planar faces in selected surfaces/polysurfaces
simple with trimmed planes. Script by Mitch Heynick 03.07.15"""

import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def TryMakeNewPlanarFace(face):
    #tries to make a new planar face if it can, otherwise returns original face
    #input argument is a BrepFace object, return is a Brep object
    if face.IsPlanar():
        edges=[loop.To3dCurve() for loop in face.Loops]
        new_face=Rhino.Geometry.Brep.CreatePlanarBreps(edges)
        if new_face and len(new_face)==1:
            return new_face[0]
    return face

def SimplifyPlanarFaces():
    msg = "Select surfaces or polysurfaces to convert"
    srf_objs = rs.GetObjects(msg, 8 + 16, preselect=True)
    if not (srf_objs): return
    
    rs.EnableRedraw(False)
    tol=sc.doc.ModelAbsoluteTolerance
    count = len(srf_objs)
    for objID in srf_objs:
        brep=sc.doc.Objects.Find(objID).Geometry
        faces=brep.Faces
        new_face_list=[]
        for face in faces: new_face_list.append(TryMakeNewPlanarFace(face))
        if len(new_face_list)>1:
            new_brep=Rhino.Geometry.Brep.JoinBreps(new_face_list,tol)
            #check for one object, if something went wrong, skip this one
            if len(new_brep) != 1: continue
        else: new_brep=new_face_list
        sc.doc.Objects.Replace(objID,new_brep[0])
    sc.doc.Views.Redraw()
SimplifyPlanarFaces()

