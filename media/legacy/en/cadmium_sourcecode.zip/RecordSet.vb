Option Compare Text

Public Class RecordSet
    Public libRecord As New Collection
    Private ShadowRecord As String = "|"

    Public Sub AddRecord(ByVal sRecord As String)
        If Len(sRecord) = 0 Then Return
        libRecord.Add(sRecord)
        ShadowRecord &= sRecord & "|"
    End Sub

    Public Sub AddUniqueRecord(ByVal sRecord As String)
        If Len(sRecord) = 0 Then Return
        If libRecord.Count = 0 Then
            AddRecord(sRecord)
            Return
        End If

        If InStrRev(ShadowRecord, "|" & sRecord & "|", , CompareMethod.Text) <= 0 Then
            AddRecord(sRecord)
        End If
    End Sub

    Public Function IsRecord(ByVal sRecord As String) As Boolean
        If Len(sRecord) = 0 Then Return False
        Dim i As String
        If InStr(ShadowRecord, "|" & sRecord & "|") <= 0 Then Return False
        Return True
    End Function

    Public Function RecordCount() As Int32
        Return libRecord.Count
    End Function

    Public Sub RebuildShadowRecord()
        ShadowRecord = "|"
        If libRecord.Count = 0 Then Return
        Dim iRec As String
        For Each iRec In libRecord
            ShadowRecord &= iRec & "|"
        Next
    End Sub
End Class

Public Enum AtomAttributes
    Unknown = 0
    Element = 1
    Molecule = 2
    Chain = 3
    Residue = 4
    Temperature = 5
    Occupancy = 6
End Enum