#pragma once

#include "resource.h"
// CMyTabDialog dialog

class CMyTabDialog : public CRhinoTabbedDockBarDialog
{
	//Your dialog must support dynamic creation
	DECLARE_DYNCREATE(CMyTabDialog)

public:
	CMyTabDialog();  //Must provide a default constructor
	virtual ~CMyTabDialog();

// Dialog Data
	enum { IDD = IDD_MYTAB };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()


protected:
	virtual const wchar_t* Caption(void) const;
	virtual ON_UUID TabId(void) const;
	virtual ON_UUID PlugInId(void) const;
	virtual HICON	Icon(void) const;
};
