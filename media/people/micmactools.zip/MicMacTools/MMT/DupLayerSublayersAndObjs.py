"""Duplicates a layer and all its sublayers incuding objects and layer attributes
Script by Mitch Heynick 21 April 2014"""

import rhinoscriptsyntax as rs
import scriptcontext as sc

def CopyObjectsToLayer(objs,layer):
    copies=rs.CopyObjects(objs)
    rs.ObjectLayer(copies,layer)
    
def CopyLayerAttribs(source_layer,target_layer):
    layers=sc.doc.Layers
    source_index=layers.FindByFullPath(source_layer,True)
    target_index=layers.FindByFullPath(target_layer,True)
    sLayer=layers[source_index]
    tLayer=layers[target_index]
    tLayer.Color=sLayer.Color
    tLayer.IsVisible=sLayer.IsVisible
    tLayer.IsLocked=sLayer.IsLocked
    tLayer.PlotColor=sLayer.PlotColor
    tLayer.PlotWeight=sLayer.PlotWeight
    tLayer.LinetypeIndex=sLayer.LinetypeIndex
    tLayer.RenderMaterialIndex=sLayer.RenderMaterialIndex
    sc.doc.Layers.Modify(tLayer,target_index,True)

def UniqueLayerCopyName(layer,top):
    #Extract main level name; add - Copy to top level layer name only
    layers=rs.LayerNames()
    nameList=layer.split("::")
    newName=nameList[-1]
    if top: newName+=" - Copy"
    if newName in layers:
        i=0
        while True:
            i+=1
            testName=newName+"({})".format(i)
            if not testName in layers: return testName
    return newName
    
def DupAllSubLayers(layer,layerCopy):
    subs=rs.LayerChildren(layer)
    if subs:
        for sub in subs:
            color=rs.LayerColor(sub)
            objs=rs.ObjectsByLayer(sub)
            name=UniqueLayerCopyName(sub,False)
            addLayer=rs.AddLayer(name,color,parent=layerCopy)
            CopyObjectsToLayer(objs,addLayer)
            rs.ExpandLayer(addLayer,rs.IsLayerExpanded(sub))
            CopyLayerAttribs(sub,addLayer)
            DupAllSubLayers(sub,addLayer)

def DupLayerSublayersAndObjs():
    layer=rs.GetLayer("Select layer to duplicate")
    if layer==None: return
    #do initial run with selected layer
    rs.EnableRedraw(False)
    objs=rs.ObjectsByLayer(layer)
    parentLayer=rs.ParentLayer(layer)
    copyName=UniqueLayerCopyName(layer,True)
    layerCopy=rs.AddLayer(copyName,parent=parentLayer)
    CopyObjectsToLayer(objs,layerCopy)
    rs.ExpandLayer(layerCopy,rs.IsLayerExpanded(layer))
    CopyLayerAttribs(layer,layerCopy)
    DupAllSubLayers(layer,layerCopy)
    sc.doc.Views.Redraw()

DupLayerSublayersAndObjs()