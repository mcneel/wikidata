"""Arrays objects diagonally in x, Y and Z (optional) along active CPlane
Script by Mitch Heynick 02.07.15"""
import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def ArrayDiagonal():
    objs = rs.GetObjects("Select objects to array diagonally",preselect=True)
    if not(objs): return
    tol=rs.UnitAbsoluteTolerance()
    plane = rs.ViewCPlane()
    
    if "ARR_DIAG_X" in sc.sticky: user_x = sc.sticky["ARR_DIAG_X"]
    else: user_x = 1.0
    if "ARR_DIAG_Y" in sc.sticky: user_y = sc.sticky["ARR_DIAG_Y"]
    else: user_y = 1.0
    if "ARR_DIAG_Z" in sc.sticky: user_z = sc.sticky["ARR_DIAG_Z"]
    else: user_z = 0
    if "ARR_DIAG_COUNT" in sc.sticky: user_count = sc.sticky["ARR_DIAG_COUNT"]
    else: user_count = 10
    
    obj_count = rs.GetInteger("Number of copies?", user_count, 2)
    if not obj_count: return
    
    dx = rs.GetReal("X spacing?", user_x, tol)
    if dx is None: return
    
    dy = rs.GetReal("Y spacing?", user_y, tol)
    if dy is None: return
    
    dz = rs.GetReal("Z spacing? (enter 0 for array in XY only)", user_z, 0)
    if dz is None: return
    
    disp_vec = Rhino.Geometry.Vector3d(dx, dy, dz)
    disp_vec = rs.XformCPlaneToWorld(disp_vec, plane)
    rs.EnableRedraw(False)
    copies=[]
    for i in range(1,obj_count):
        xform=rs.XformTranslation(i*disp_vec)
        for obj in objs:
            copies.append(sc.doc.Objects.TransformWithHistory(obj,xform))
    if len(copies)>0: rs.SelectObjects(copies)
    
    sc.sticky["ARR_DIAG_X"] = dx
    sc.sticky["ARR_DIAG_Y"] = dy
    sc.sticky["ARR_DIAG_Z"] = dz
    sc.sticky["ARR_DIAG_COUNT"] = obj_count
ArrayDiagonal()