/////////////////////////////////////////////////////////////////////////////
// TestObjectPropertiesPageExApp.h : main header file for the TestObjectPropertiesPageEx DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "Resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTestObjectPropertiesPageExApp
// See TestObjectPropertiesPageExApp.cpp for the implementation of this class
//

class CTestObjectPropertiesPageExApp : public CWinApp
{
public:
	CTestObjectPropertiesPageExApp();

// Overrides
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

	DECLARE_MESSAGE_MAP()
};
