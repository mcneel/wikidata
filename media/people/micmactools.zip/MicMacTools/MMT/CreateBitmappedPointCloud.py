"""Creates a colored point cloud from an image with 1 pixel = 1 point
User chosen point cloud width which automatically determines cell spacing.
Script by Mitch Heynick, 24 February, 2014
To do, possibly - draw rectangle in proportion"""

import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino, System

def CreateBitmappedPointCLoud():
    
    msg="Select an image file to map"
    filter = "PNG (*.png)|*.png|JPG (*.jpg)|*.jpg|BMP (*.bmp)|*.bmp|All (*.*)|*.*||"
    rs.Prompt(msg)
    filename = rs.OpenFileName(msg, filter)
    if not filename: return
    # use Microsoft System.Drawing.Bitmap to extract image info
    img = System.Drawing.Bitmap(filename)
    iw=img.Width ; ih=img.Height
    
    print "Image pixel dimensions: {} x {}".format(iw,ih)
    msg="Enter image width (X dimension) in file units"
    width=rs.GetReal(msg,iw,minimum=sc.doc.ModelAbsoluteTolerance)
    if not width: return
    
    ipt=rs.GetPoint("Image insertion point?")
    if not ipt: return
    
    cellsize=width/(iw-1)
    #image domain starts in upper left corner, add total Y height to insert point
    ipt.Y=ipt.Y+(cellsize*(ih-1))
    xo=ipt.X ; yo=ipt.Y
    
    #start the music...
    rs.Prompt("Creating point cloud from image...")    
    pc = Rhino.Geometry.PointCloud()
    for i in range(iw):
        for j in range(ih):
            color=img.GetPixel(i,j)
            pt=Rhino.Geometry.Point3d(xo+(i*cellsize),yo-(j*cellsize),ipt.Z)
            pc.Add(pt, color)
    rc=sc.doc.Objects.AddPointCloud(pc)
    sc.doc.Views.Redraw()
CreateBitmappedPointCLoud()