using System;
using System.Collections.Generic;
using Rhino;

namespace TestRhinoPluginCS
{
  ///<summary>
  /// Every RhinoCommon plug-In must have one and only one Rhino.PlugIns.PlugIn 
  /// inherited class. DO NOT create an instance of this class. It is the 
  /// responsibility of Rhino to create an instance of this class.
  ///</summary>
  public class TestRhinoPluginCSPlugIn : Rhino.PlugIns.PlugIn
  {
    // The one and only TestRhinoPluginCSPlugIn object
    static TestRhinoPluginCSPlugIn m_theplugin;

    ///<summary>
    /// Returns the one and only instance of this plug-in
    ///</summary>
    public static TestRhinoPluginCSPlugIn ThePlugIn
    {
      get { return m_theplugin; } 
    }

    /// <summary>
    /// Public constructor
    /// </summary>
    public TestRhinoPluginCSPlugIn()
    {
      m_theplugin = this;
    }

    /// <summary>
    /// Rhino.PlugIns.PlugIn.OnLoad override
    /// </summary>
    protected override Rhino.PlugIns.LoadReturnCode OnLoad(ref string errorMessage)
    {
      // Ask Rhino to get a product license for us.
      bool rc = GetLicense(Rhino.PlugIns.LicenseBuildType.Release, this.ValidateProductKey);
      if (!rc)
        return Rhino.PlugIns.LoadReturnCode.ErrorNoDialog;

      return Rhino.PlugIns.LoadReturnCode.Success;
    }

    /// <summary>
    /// Create a method with the same signature as the 
    /// Rhino.PlugIns.ValidateProductKeyDelegate delegate.
    /// </summary>
    private Rhino.PlugIns.ValidateResult ValidateProductKey(string productKey, out Rhino.PlugIns.LicenseData licenseData)
    {
      // This class contains information about your product's license.
      licenseData = new Rhino.PlugIns.LicenseData();

      // If this example, we won't do much valiation...
      if (string.IsNullOrEmpty(productKey))
        return Rhino.PlugIns.ValidateResult.ErrorShowMessage;

      // This value will never be display in any user interface.
      // When your plugin's ValidateProductKey member is called, it is
      // passed a a product, or CD, key that was entered into the Zoo
      // administrator console. Your ValidateProductKey will validate
      // the product key and decode it into a product license. This is
      // where you can store this license. This value will be passed
      // to your application at runtime when it requests a license.
      licenseData.ProductLicense = productKey;

      // This value will display in user interface items, such as in
      // the Zoo console and in About dialog boxes. Also, this value
      // is used to uniquely identify this license. Thus, it is
      // critical that this value be unique per product key, entered
      // by the administrator. No other license of this product, as
      // validated by this plugin, should return this value.
      //
      // This example just scrambles the productKey...
      licenseData.SerialNumber = Scramble(productKey);

      // This value will display in user interface items, such as in
      // the Zoo console and in About dialog boxes.
      // (e.g. "Rhinoceros 5.0", "Rhinoceros 5.0 Commercial", etc.)
      licenseData.LicenseTitle = "TestRhinoPluginCS 1.0 Educational";

      // The build of the product that this license work with.
      // When your product requests a license from the Zoo, it
      // will specify one of these build types.
      licenseData.BuildType = Rhino.PlugIns.LicenseBuildType.Release;

      // Zoo licenses can be used by more than one instance of any application.
      // For example, a single Rhion Education Lab license can be used by up
      // to 30 systems simulaneously. If your license supports multiple instance,
      // then specify the number of supported instances here. Otherwise just
      // specify a value of 1 for single instance use.
      licenseData.LicenseCount = 1;

      // The Zoo supports licenses that expire. If your licensing scheme
      // is sophisticated enough to support this, then specify the
      // expiration date here. Note, this value must be speicified in
      // Coordinated Universal Time (UTC). If your license does not expire,
      // then just this value to null.
      licenseData.DateToExpire = null;

      // This icon will displayed in the "Licenses" page in the Options dialog.
      // Note, this can be null. Also note, LicenseData creates it's own copy
      // of the icon.
      licenseData.ProductIcon = Properties.Resources.TestRhinoPluginCS;

      return Rhino.PlugIns.ValidateResult.Success;
    }

    /// <summary>
    /// Randomizes character positions in string
    /// </summary>
    static string Scramble(string input)
    {
      if (string.IsNullOrEmpty(input))
        return input;

      List<char> inputChars = new List<char>(input);
      char[] outputChars = new char[inputChars.Count];

      Random rand = new Random();

      for (int i = inputChars.Count - 1; i >= 0; i--)
      {
        int index = rand.Next(i);
        outputChars[i] = inputChars[index];
        inputChars.RemoveAt(index);
      }

      return new string(outputChars);
    }
  }
}