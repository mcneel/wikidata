Imports RMA.Rhino
Imports RMA.OpenNURBS

Public Class DivisionPoint
  Public m_param As Double
  Public m_p As On3dPoint
  Public m_t As On3dVector
End Class

Public Class CurveDivider
  Protected m_curve As OnCurve

  Public Sub New(ByVal nCurve As IOnCurve)
    Me.m_curve = nCurve.DuplicateCurve()
  End Sub

  Public ReadOnly Property Curve() As IOnCurve
    Get
      Return Me.m_curve
    End Get
  End Property

  ''' <summary>
  ''' Divide the curve with equal distance segments
  ''' </summary>
  ''' <param name="length">The distance between division points</param>
  Public Function Divide(ByVal length As Double, Optional ByRef dRemainder As Double = 0.0) As List(Of DivisionPoint)
    Return Me.Divide(Me.m_curve.Domain(), length, dRemainder)
  End Function

  ''' <summary>
  ''' Divide the curve with equal distance segments
  ''' </summary>
  ''' <param name="d">The curve domain to take into account</param>
  ''' <param name="length">The distance between division points</param>
  ''' <returns></returns>
  ''' <remarks></remarks>
  Public Function Divide(ByVal d As OnInterval, ByVal length As Double, Optional ByRef dRemainder As Double = 0.0) As List(Of DivisionPoint)
    Dim t0 As Double = Me.m_curve.Domain.Min()
    Dim t1 As Double = Me.m_curve.Domain.Max()

    If (d.Min() > t1) Then Return Nothing
    If (d.Max() < t0) Then Return Nothing

    Dim t As Double = d.Min()
    Dim x As New DivisionPoint

    'Add first point
    Dim pts As New List(Of DivisionPoint)

    x.m_param = t
    x.m_p = Me.m_curve.PointAt(t)
    x.m_t = Me.m_curve.TangentAt(t)
    pts.Add(x)

    Do
      x = Me.SolveDivisionPoint(t, length)
      If (x Is Nothing) Then Exit Do

      pts.Add(x)
      t = x.m_param
    Loop

    Dim rem_int As New OnInterval(pts(pts.Count() - 1).m_param, t1)
    Me.m_curve.GetLength(dRemainder, 0.0, rem_int)

    Return pts
  End Function

  ''' <summary>
  ''' Create a RevSurface Sphere surface.
  ''' </summary>
  ''' <param name="t">Parameter on the curve for sphere center</param>
  ''' <param name="r">Radius of the sphere</param>
  Protected Function XSphere(ByVal t As Double, ByVal r As Double) As OnRevSurface
    Dim wave As New OnSphere(Me.m_curve.PointAt(t), r)
    Return wave.RevSurfaceForm()
  End Function

  ''' <summary>
  ''' Find the next division point on the curve.
  ''' </summary>
  ''' <param name="t">Parameter to start searching</param>
  ''' <param name="distance">distance between C(t) and C(tn)</param>
  ''' 
  Public Function SolveDivisionPoint(ByVal t As Double, ByVal distance As Double) As DivisionPoint
    Dim x_dom As New OnInterval(t, Me.m_curve.Domain().Max())
    Dim x As New ArrayOnX_EVENT()

    If (Me.m_curve.IntersectSurface(XSphere(t, distance), x, 0.0, 0.0, x_dom) = 0) Then
      'No intersections found
      Return Nothing
    Else
      'At least 1 intersection found, the first one is always the nearest.
      Dim x_p As New DivisionPoint()
      x_p.m_param = x(0).m_a(0)
      x_p.m_p = Me.m_curve.PointAt(x_p.m_param)
      x_p.m_t = Me.m_curve.TangentAt(x_p.m_param)

      Return x_p
    End If
  End Function
End Class