<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MyUserControl
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.m_textbox = New System.Windows.Forms.TextBox
    Me.m_btnPrintToCommandLine = New System.Windows.Forms.Button
    Me.m_btnMakeLine = New System.Windows.Forms.Button
    Me.SuspendLayout()
    '
    'm_textbox
    '
    Me.m_textbox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.m_textbox.Location = New System.Drawing.Point(4, 4)
    Me.m_textbox.Name = "m_textbox"
    Me.m_textbox.Size = New System.Drawing.Size(186, 22)
    Me.m_textbox.TabIndex = 0
    '
    'm_btnPrintToCommandLine
    '
    Me.m_btnPrintToCommandLine.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.m_btnPrintToCommandLine.Location = New System.Drawing.Point(4, 33)
    Me.m_btnPrintToCommandLine.Name = "m_btnPrintToCommandLine"
    Me.m_btnPrintToCommandLine.Size = New System.Drawing.Size(186, 25)
    Me.m_btnPrintToCommandLine.TabIndex = 1
    Me.m_btnPrintToCommandLine.Text = "Print to Command Line"
    Me.m_btnPrintToCommandLine.UseVisualStyleBackColor = True
    '
    'm_btnMakeLine
    '
    Me.m_btnMakeLine.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.m_btnMakeLine.Location = New System.Drawing.Point(3, 179)
    Me.m_btnMakeLine.Name = "m_btnMakeLine"
    Me.m_btnMakeLine.Size = New System.Drawing.Size(186, 25)
    Me.m_btnMakeLine.TabIndex = 2
    Me.m_btnMakeLine.Text = "Make Line"
    Me.m_btnMakeLine.UseVisualStyleBackColor = True
    '
    'MyUserControl
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.Controls.Add(Me.m_btnMakeLine)
    Me.Controls.Add(Me.m_btnPrintToCommandLine)
    Me.Controls.Add(Me.m_textbox)
    Me.Name = "MyUserControl"
    Me.Size = New System.Drawing.Size(193, 224)
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents m_textbox As System.Windows.Forms.TextBox
  Friend WithEvents m_btnPrintToCommandLine As System.Windows.Forms.Button
  Friend WithEvents m_btnMakeLine As System.Windows.Forms.Button

End Class
