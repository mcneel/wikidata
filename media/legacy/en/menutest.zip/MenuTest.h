/////////////////////////////////////////////////////////////////////////////
// MenuTest.h
//

#if !defined(AFX_MENUTEST_H__24767075_9634_4BF8_98EF_8ABE043C1587__INCLUDED_)
#define AFX_MENUTEST_H__24767075_9634_4BF8_98EF_8ABE043C1587__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'StdAfx.h' before including this file for PCH
#endif

#include "Resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMenuTestApp
// See MenuTest.cpp for the implementation of this class.
//

class CMenuTestApp : public CWinApp
{
public:
	CMenuTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMenuTestApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CMenuTestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MENUTEST_H__24767075_9634_4BF8_98EF_8ABE043C1587__INCLUDED_)
