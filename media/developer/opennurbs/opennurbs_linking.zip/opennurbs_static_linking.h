/////////////////////////////////////////////////////////////////////////////
// linking_pragmas_static.h

// This file is specific to Micrsoft's compiler.

#pragma once

#if defined(ON_DLL_IMPORTS) || defined(ON_DLL_EXPORTS)
#error This file contains STATIC LIBRARY linking pragmas.
#endif

#if defined(WIN64)

// x64 (64 bit) static libraries

#if defined(NDEBUG)

// Release x64 (64 bit) libs
#pragma message( " --- Opennurbs Release x64 (64 bit) build." )
#pragma comment(lib, "../opennurbs/zlib/x64/Release/zlibx64.lib")
#pragma comment(lib, "../opennurbs/x64/ReleaseStaticLib/opennurbsx64_static.lib")

#else // _DEBUG

// Debug x64 (64 bit) libs
#pragma message( " --- Opennurbs Debug x64 (64 bit) build." )
#pragma comment(lib, "../opennurbs/zlib/x64/Debug/zlibx64_d.lib")
#pragma comment(lib, "../opennurbs/x64/DebugStaticLib/opennurbsx64_staticd.lib")

#endif // NDEBUG else _DEBUG

#else // WIN32

// x86 (32 bit) static libraries

#if defined(NDEBUG)

// Release x86 (32 bit) libs
#pragma message( " --- Opennurbs Release x86 (32 bit) build." )
#pragma comment(lib, "../opennurbs/zlib/Release/zlib.lib")
#pragma comment(lib, "../opennurbs/ReleaseStaticLib/opennurbs_static.lib")

#else // _DEBUG

// Debug x86 (32 bit) libs
#pragma message( " --- Opennurbs Debug x86 (32 bit) build." )
#pragma comment(lib, "../opennurbs/zlib/Debug/zlib_d.lib")
#pragma comment(lib, "../opennurbs/DebugStaticLib/opennurbs_staticd.lib")

#endif // NDEBUG else _DEBUG

#endif // WIN64 else WIN32
