This is a toolbar with 3 buttons and 3 scripts to add notes to objects

1. Add & Edit ObjectNotes
2. Delete ObjectNotes
3. Select Objects with Notes

To install it define the path to the 3 scripts under RhinoOptions /
Files / SearchPath / FileSearchPath and then open or import the
workspace file from the menu (Tools/Toolbar Layout/File/Open).

Check the main section for detailed instructions on how to create file search paths and import toolbars.  You may also copy the scripts directly to the toolbar buttons once you have imported them.
