/////////////////////////////////////////////////////////////////////////////
// cmdTestCommand1,cpp
//

#include "StdAfx.h"

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//
// BEGIN TestCommand1 command
//

class CCommandTestCommand1 : public CRhinoCommand
{
public:
	CCommandTestCommand1() {}
	~CCommandTestCommand1() {}

	UUID CommandUUID()
	{
		// {36AE3E81-1C33-405B-A945-4A603A76D2DD}
		static const GUID TestCommand1Command_UUID =
		{ 0x36AE3E81, 0x1C33, 0x405B, { 0xA9, 0x45, 0x4A, 0x60, 0x3A, 0x76, 0xD2, 0xDD } };
		return TestCommand1Command_UUID;
	}

	const wchar_t* EnglishCommandName() { return L"TestCommand1"; }
	const wchar_t* LocalCommandName() { return L"TestCommand1"; }

	CRhinoCommand::result RunCommand( const CRhinoCommandContext& );
};

static class CCommandTestCommand1 theTestCommand1Command;

CRhinoCommand::result CCommandTestCommand1::RunCommand( const CRhinoCommandContext& context )
{
	ON_wString sPrompt;
	sPrompt.Format( L"The \"%s\" command is under construction.\n", EnglishCommandName() );
	if( context.IsInteractive() )
		RhinoMessageBox( sPrompt, EnglishCommandName(), MB_OK );
	else
		RhinoApp().Print( sPrompt );

	return CRhinoCommand::success;
}

//
// END TestCommand1 command
//
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
