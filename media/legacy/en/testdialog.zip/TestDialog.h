#pragma once

#ifndef __AFXWIN_H__
	#error include 'StdAfx.h' before including this file for PCH
#endif

#include "Resource.h"

class CTestDialogApp : public CWinApp
{
public:
	CTestDialogApp();

	//{{AFX_VIRTUAL(CTestDialogApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CTestDialogApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
