import Rhino
import rhinoscriptsyntax as rs
import scriptcontext as sc

def GetObjectEscCancel(prompt,filt=None):
    #prompt==command line prompt
    go = Rhino.Input.Custom.GetObject()
    go.SetCommandPrompt(prompt)
    if filt: go.GeometryFilter=filt
    go.AcceptNothing(True)
    value=None
    
    get_rc = go.Get()
    if get_rc==Rhino.Input.GetResult.Cancel: value=False
    elif get_rc==Rhino.Input.GetResult.Nothing: value=True
    elif get_rc==Rhino.Input.GetResult.Object:
        value=go.Object(0)
    else: value=False
    return value

def SelHatchByPattern():
    objs = rs.ObjectsByType(65536)
    if not objs:
        print "No hatch objects found in document" ; return
    hp_coll=set(rs.HatchPattern(obj) for obj in objs)
    if not hp_coll:
        print "No hatch patterns found in document" ; return
    hp_list=sorted(list(hp_coll))
    
    msg1="Pick hatch object to match or press Enter to choose by name"
    gf=Rhino.DocObjects.ObjectType.Hatch
    result=GetObjectEscCancel(msg1,gf)
    if not result: return
    if isinstance(result,Rhino.DocObjects.ObjRef):
        hp=rs.HatchPattern(result.ObjectId)
    else:
        hp=rs.ListBox(hp_list,"Select hatch pattern","Hatch Names")
        if not hp: return
    
    rs.EnableRedraw(False)
    n = 0
    for obj in objs:
        if rs.IsObjectSelectable(obj):
            obj_hp=rs.HatchPattern(obj)
            if obj_hp.lower() == hp.lower():
                rs.SelectObject(obj)
                n += 1
    if n >0: 
        if n==1: s=""
        else: s="es"
        print "Selected {} hatch{} with the chosen pattern".format(n,s)
    else: print ("No hatches of chosen pattern found")

SelHatchByPattern()