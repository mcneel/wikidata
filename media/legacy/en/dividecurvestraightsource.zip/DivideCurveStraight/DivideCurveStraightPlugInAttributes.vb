'''<summary>
''' The following class is required for all Rhino.NET plug-ins.
''' These are used to display plug-in information in the plug-in manager.
''' Any string will work for these attributes, so if you don't have a fax
''' number it is OK to enter something like "none"
'''</summary>
Public Class DivideCurveStraightPlugInAttributes
  Inherits RMA.Rhino.MRhinoPlugInAttributes

  Public Overrides Function Address() As String
    Return "Lantinen Pitkakatu 21D" & vbCrLf & "20100 Turku"
  End Function

  Public Overrides Function Country() As String
    Return "Finland"
  End Function

  Public Overrides Function Email() As String
    Return "david@mcneel.com"
  End Function

  Public Overrides Function Fax() As String
    Return "undefined"
  End Function

  Public Overrides Function Organization() As String
    Return "Robert McNeel & Associates"
  End Function

  Public Overrides Function Phone() As String
    Return "undefined"
  End Function

  Public Overrides Function UpdateURL() As String
    Return "http://www.Rhino3d.com"
  End Function

  Public Overrides Function Website() As String
    Return "http://www.Rhino3d.com"
  End Function
End Class