import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino
"""Mutually splits curves, surfaces and polysurfaces at all possible
intersections. Script by Mitch Heynick Version 16.06.15"""

def IntersectObjects(objs):
    rs.SelectObjects(objs)
    rs.Command("_Intersect",False)
    rs.UnselectAllObjects()
    return rs.LastCreatedObjects()

def SplitAllSelected():
    msg = "Select group of curves and/or surfaces to split mutally"
    objs = rs.GetObjects(msg, 4+8+16, preselect=True, select=True)
    if not objs: return
    
    crvs=[] ; breps=[]
    #split objects into curves and breps
    for obj in objs:
        if rs.IsCurve(obj): crvs.append(obj)
        else: breps.append(obj)
    
    rs.EnableRedraw(False)
    i_objs=IntersectObjects(objs)
    if not i_objs:
        print "No intersections found" ; return
    i_pts=[] ; i_crvs=[]
    for obj in i_objs:
        if rs.IsPoint(obj): i_pts.append(obj)
        else: i_crvs.append(obj)    
    insec_group = rs.AddGroup()
    rs.AddObjectsToGroup(i_objs, insec_group)
    
    rs.Prompt("Splitting objects, please wait...")
    split_count=0
    if crvs:
        rs.UnselectAllObjects()
        rs.SelectObjects(crvs)
        rs.Command("_Split _-SelGroup "+insec_group+" _Enter", False)
        crv_splits=rs.LastCreatedObjects()
        if crv_splits: split_count+=(len(crv_splits))
        
    if breps and i_crvs:
        rs.UnselectAllObjects()
        rs.SelectObjects(breps)
        rs.Command("_Split _-SelGroup "+insec_group+" _Enter", False)
        rs.UnselectAllObjects()
        srf_splits=rs.LastCreatedObjects()
        rs.DeleteGroup(insec_group)
        if srf_splits: split_count+=(len(srf_splits))
        
    rs.DeleteGroup(insec_group)
    rs.DeleteObjects(i_objs)
    if split_count>0:
        print "{} objects split into {} parts".format(len(objs),split_count)
    else:
        print "No objects were split"
SplitAllSelected()