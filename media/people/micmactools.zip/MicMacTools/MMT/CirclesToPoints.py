import rhinoscriptsyntax as rs
import scriptcontext as sc

def CirclesToPoints():
    tol=rs.UnitAbsoluteTolerance()
    if "CIRCTP_Rad" in sc.sticky: user_rad = sc.sticky["CIRCTP_Rad"]
    else: user_rad = 1.0
    msg="Select points to apply circles - orientation plane will be active view"
    ptIDs=rs.GetObjects(msg,1,preselect=True)
    if not ptIDs: return
    plane=rs.ViewCPlane()
    rad=rs.GetReal("Circle radius",user_rad,tol)
    if not rad: return
    
    rs.EnableRedraw(False)
    pts=rs.coerce3dpointlist(ptIDs)
    copies=[]
    for pt in pts:
        plane.Origin=pt
        copies.append(rs.AddCircle(plane,rad))
    rs.SelectObjects(copies)
    sc.sticky["CIRCTP_Rad"] = rad
CirclesToPoints()