Imports System
Imports System.Runtime.InteropServices
Imports System.Reflection

Module MainModule

  Public Enum ExitCode
    Success = 0
    ErrorGettingApplication = 1
    ErrorGettingRhinoScript = 2
    ErrorGettingScriptObject = 3
    UnknownError = 99
  End Enum

  Declare Auto Function SendMessage Lib "user32.dll" (ByVal hWnd As IntPtr, ByVal Msg As Integer, ByVal wParam As IntPtr, ByRef lParam As IntPtr) As IntPtr

  Function Main() As Integer

    ' Get Rhino application object
    Dim rhinoApp As Rhino4.Rhino4Application = Nothing
    rhinoApp = CreateObject("Rhino4.Application")
    If (rhinoApp Is Nothing) Then
      Return CType(ExitCode.ErrorGettingApplication, Integer)
    End If

    ' Get RhinoScript object
    Dim rhinoScript As RhinoScript4.RhinoScript = Nothing
    For i As Integer = 1 To 10
      Dim obj As Object = rhinoApp.GetScriptObject()
      If Not obj.Equals(System.DBNull.Value) Then
        rhinoScript = CType(obj, RhinoScript4.RhinoScript)
        If (rhinoScript IsNot Nothing) Then
          Exit For
        End If
      End If
      System.Threading.Thread.Sleep(500)
    Next

    If (rhinoScript Is Nothing) Then
      Return CType(ExitCode.ErrorGettingRhinoScript, Integer)
    End If

    ' Get TestRhinoScriptObject object
    Dim pluginStr As String = "6CFAA302-793D-42AE-BA2F-862224A6C706" 'from TestRhinoPlugIn.vb
    Dim objectStr As String = "D0E1D541-F1AD-4A3B-A6D4-C191EA8D7245" 'from TestRhinoScriptObject.vb
    Dim scriptObj As Object = Nothing
    For i As Integer = 1 To 10
      scriptObj = rhinoApp.GetPlugInObject(pluginStr, objectStr)
      If (scriptObj IsNot Nothing) Then
        Exit For
      Else
        System.Threading.Thread.Sleep(500)
      End If
    Next

    If (scriptObj Is Nothing) Then
      Return CType(ExitCode.ErrorGettingScriptObject, Integer)
    End If

    ' Invoke a TestRhinoScriptObject member
    Dim scriptType As Type = scriptObj.GetType()
    Try
      Dim str As String
      str = CType(scriptType.InvokeMember("Hello", BindingFlags.InvokeMethod, Nothing, scriptObj, Nothing), String)
      Console.WriteLine(str)
    Catch ex As Exception
      Console.WriteLine(ex.Message)
    End Try

    ' Set the document modified flag to false do we don't see the
    ' "Do you want to save this file..." message when Rhino closes.
    rhinoScript.DocumentModified(False)

    ' Unlike VB 6.0, VB.NET does not (seem) to release the Rhino 
    ' application object (correctly). So, we will help Rhino close
    ' by sending Rhino a Windows WM_CLOSE message.
    Dim lWnd As Long = CType(rhinoScript.WindowHandle(), Long)
    Dim hWnd As New IntPtr(lWnd)
    Const WM_CLOSE As Integer = &H10
    SendMessage(hWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero)

    Return CType(ExitCode.Success, Integer)

  End Function

End Module
