using System;
using Rhino;

namespace TestRhinoPluginCS
{
  [System.Runtime.InteropServices.Guid("acba7196-db19-4bd8-8cec-356a9bcfcb37")]
  public class TestRhinoPluginCSCommand : Rhino.Commands.Command
  {
    // The one and only TestRhinoPluginCSCommand object
    static TestRhinoPluginCSCommand m_thecommand;

    ///<summary>
    /// Returns the one and only instance of this command
    ///</summary>
    public static TestRhinoPluginCSCommand TheCommand
    { 
      get { return m_thecommand; } 
    }

    /// <summary>
    /// Public constructor
    /// </summary>
    public TestRhinoPluginCSCommand()
    {
      // Rhino only creates one instance of each defined public command class,
      // so it is safe to hold on to a static reference.
      m_thecommand = this;
    }

    /// <summary>
    /// Command name as it appears on the Rhino command line
    /// </summary>
    public override string EnglishName
    { 
      get { return "TestRhinoPluginCS"; } 
    }

    /// <summary>
    /// The command entry point
    /// </summary>
    protected override Rhino.Commands.Result RunCommand(RhinoDoc doc, Rhino.Commands.RunMode mode)
    {
      RhinoApp.WriteLine("The {0} command is under construction", EnglishName);
      return Rhino.Commands.Result.Success;
    }
  }
}

