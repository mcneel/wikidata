import rhinoscriptsyntax as rs
import random

"""this script puts a random non uniform scale on all selected objects
 acting about their bounding box center"""

objs=rs.GetObjects("Select objects to random scale", preselect=True)
rs.EnableRedraw(False)
for obj in objs:
    bb=rs.BoundingBox(obj)
    ctr=(bb[6]+bb[0])/2
    x=random.uniform(0.5,1.5)
    y=random.uniform(0.5,1.5)
    z=random.uniform(0.5,1.5)
    rs.ScaleObject(obj,ctr,[x,y,z])