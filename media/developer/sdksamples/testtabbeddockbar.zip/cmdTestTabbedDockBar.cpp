/////////////////////////////////////////////////////////////////////////////
// cmdTestTabbedDockBar.cpp : command file
//

#include "StdAfx.h"
#include "TestTabbedDockBarPlugIn.h"
#include "TestTabbedDockBarDialog.h"

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//
// BEGIN TestTabbedDockBar command
//

#pragma region TestTabbedDockBar command

class CCommandTestTabbedDockBar : public CRhinoCommand
{
public:
	CCommandTestTabbedDockBar() {}
  ~CCommandTestTabbedDockBar() {}
	UUID CommandUUID()
	{
		// {72C6CA47-5B89-4219-948F-118C4A99D9AB}
    static const GUID TestTabbedDockBarCommand_UUID =
    { 0x72C6CA47, 0x5B89, 0x4219, { 0x94, 0x8F, 0x11, 0x8C, 0x4A, 0x99, 0xD9, 0xAB } };
    return TestTabbedDockBarCommand_UUID;
	}
	const wchar_t* EnglishCommandName() { return L"TestTabbedDockBar"; }
	const wchar_t* LocalCommandName() { return L"TestTabbedDockBar"; }
	CRhinoCommand::result RunCommand( const CRhinoCommandContext& );
};
static class CCommandTestTabbedDockBar theTestTabbedDockBarCommand;

CRhinoCommand::result CCommandTestTabbedDockBar::RunCommand( const CRhinoCommandContext& context )
{
  ON_UUID tabId = CTestTabbedDockBarDialog::ID();

  if( context.IsInteractive() )
  {
    CRhinoTabbedDockBarDialog::OpenDockbarTab( tabId );
  }
  else
  {
    bool bVisible = CRhinoTabbedDockBarDialog::IsTabVisible( tabId );
 
    ON_wString str;
    str.Format( L"%s is %s. New value", LocalCommandName(), bVisible ? L"visible" : L"hidden" );
 
    CRhinoGetOption go;
    go.SetCommandPrompt( str );
    int h_option = go.AddCommandOption( RHCMDOPTNAME(L"Hide") );
    int s_option = go.AddCommandOption( RHCMDOPTNAME(L"Show") );
    int t_option = go.AddCommandOption( RHCMDOPTNAME(L"Toggle") );
    go.GetOption();
    if( go.CommandResult() != CRhinoCommand::success )
      return go.CommandResult();
 
    const CRhinoCommandOption* option = go.Option();
    if( 0 == option )
      return CRhinoCommand::failure;
 
    int option_index = option->m_option_index;

    if( h_option == option_index && bVisible )
      CRhinoTabbedDockBarDialog::ShowDockbarTab( tabId, false );
    else if( s_option == option_index && !bVisible  )
      CRhinoTabbedDockBarDialog::ShowDockbarTab( tabId, true );
    else if( t_option == option_index )
      CRhinoTabbedDockBarDialog::ShowDockbarTab( tabId, !bVisible );
  }

  return CRhinoCommand::success;
}

#pragma endregion

//
// END TestTabbedDockBar command
//
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
