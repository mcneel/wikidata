/////////////////////////////////////////////////////////////////////////////
// cmdTestRhinoPluginCPP.cpp : command file
//

#include "StdAfx.h"
#include "TestRhinoPluginCPPPlugIn.h"

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//
// BEGIN TestRhinoPluginCPP command
//

#pragma region TestRhinoPluginCPP command

class CCommandTestRhinoPluginCPP : public CRhinoCommand
{
public:
	CCommandTestRhinoPluginCPP() {}
  ~CCommandTestRhinoPluginCPP() {}
	UUID CommandUUID()
	{
		// {976EA1B4-47EB-4398-A077-1F2A47BB6313}
    static const GUID TestRhinoPluginCPPCommand_UUID =
    { 0x976EA1B4, 0x47EB, 0x4398, { 0xA0, 0x77, 0x1F, 0x2A, 0x47, 0xBB, 0x63, 0x13 } };
    return TestRhinoPluginCPPCommand_UUID;
	}
	const wchar_t* EnglishCommandName() { return L"TestRhinoPluginCPP"; }
	const wchar_t* LocalCommandName() { return L"TestRhinoPluginCPP"; }
	CRhinoCommand::result RunCommand( const CRhinoCommandContext& );
};
static class CCommandTestRhinoPluginCPP theTestRhinoPluginCPPCommand;

CRhinoCommand::result CCommandTestRhinoPluginCPP::RunCommand( const CRhinoCommandContext& context )
{
  ON_wString wStr;
  wStr.Format( L"The \"%s\" command is under construction.\n", EnglishCommandName() );
  if( context.IsInteractive() )
    RhinoMessageBox( wStr, PlugIn()->PlugInName(), MB_OK );
  else
	  RhinoApp().Print( wStr );
  return CRhinoCommand::success;
}

#pragma endregion

//
// END TestRhinoPluginCPP command
//
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
