"""Duplicates a layer and the objects on it
Script by Mitch Heynick 14.04.2014
revised 03.07.15 - corrected parent layer attribution, naming, layer attributes"""

import rhinoscriptsyntax as rs
import scriptcontext as sc

def CopyLayerAttribs(source_layer,target_layer):
    layers=sc.doc.Layers
    source_index=layers.FindByFullPath(source_layer,True)
    target_index=layers.FindByFullPath(target_layer,True)
    sLayer=layers[source_index]
    tLayer=layers[target_index]
    tLayer.Color=sLayer.Color
    tLayer.IsVisible=sLayer.IsVisible
    tLayer.IsLocked=sLayer.IsLocked
    tLayer.PlotColor=sLayer.PlotColor
    tLayer.PlotWeight=sLayer.PlotWeight
    tLayer.LinetypeIndex=sLayer.LinetypeIndex
    tLayer.RenderMaterialIndex=sLayer.RenderMaterialIndex
    sc.doc.Layers.Modify(tLayer,target_index,True)

def DupLayerPlusObjs():
    layers=rs.LayerNames()
    layer=rs.GetLayer(layer=rs.CurrentLayer())
    if layer==None: return
    p_layer=rs.ParentLayer(layer)
    if p_layer:
        layer_tokens=layer.split("::")
        new_name=layer_tokens[-1]+" - Copy"
    else:
        new_name=layer+" - Copy"
    if new_name in layers:
        i=0
        while True:
            i+=1
            test_name=new_name+"({})".format(i)
            if not test_name in layers:
                new_name=test_name
                break
    rs.EnableRedraw(False)            
    new_layer=rs.AddLayer(new_name,parent=p_layer)
    CopyLayerAttribs(layer,new_layer)
    objs=rs.ObjectsByLayer(layer)
    if objs :
        copies=rs.CopyObjects(objs)
        rs.ObjectLayer(copies,new_layer)
DupLayerPlusObjs()