import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino
from random import uniform as randu

"""Generates box of random points in 1, 2 or 3D, lower left corner at 0.
OneD creates a line of random points in X. Script by Mitch Heynick 14.06.15"""

def GetScaleAlongAxis(axis,default=None,min=None,max=None):
    msg="Maximum dist from 0 along {} axis?".format(axis)
    return rs.GetReal(msg,default,min,max)

def RandomPointGenerator3D():
    #Get previous settings
    if "RPG_PtCount" in sc.sticky: aa_aa = sc.sticky["RPG_PtCount"]
    else: aa_aa = 100
    if "RPG_SpaceChoice" in sc.sticky: bb_bb = sc.sticky["RPG_SpaceChoice"]
    else: bb_bb = "ThreeD"
    if "RPG_PCChoice" in sc.sticky: cc_cc = sc.sticky["RPG_PCChoice"]
    else: cc_cc = True
    if "RPG_xScale" in sc.sticky: dd_dd = sc.sticky["RPG_xScale"]
    else: dd_dd = 100.0
    if "RPG_yScale" in sc.sticky: ee_ee = sc.sticky["RPG_yScale"]
    else: ee_ee = 100.0
    if "RPG_zScale" in sc.sticky: ff_ff = sc.sticky["RPG_zScale"]
    else: ff_ff = 100.0
    
    pt_count=rs.GetInteger("Number of points to generate?",aa_aa,1)
    if not pt_count: return
    
    choice=["ThreeD","TwoD","OneD"]
    space=rs.GetString("Type of distribution?",bb_bb,choice)
    if not space or space not in choice: return
    
    choice=["PointCloud","No","Yes"]
    pc=rs.GetBoolean("Create PointCloud?",choice,cc_cc)
    if not pc: return
    
    tol=sc.doc.ModelAbsoluteTolerance
    #get extents
    dx=0 ; dy=0 ; dz=0
    dx=GetScaleAlongAxis("X",dd_dd,tol)
    if dx is None: return
    if space=="TwoD" or space=="ThreeD":
        dy=GetScaleAlongAxis("Y",ee_ee,tol)
        if dy is None: return
        if space=="ThreeD":
            dz=GetScaleAlongAxis("Z",ff_ff,tol)
            if dz is None: return
    
    rs.EnableRedraw(False)
    pts=[]
    for i in range(pt_count):
        pts.append(Rhino.Geometry.Point3d(randu(0,dx),randu(0,dy),randu(0,dz)))
    
    if pc[0]: result=[rs.AddPointCloud(pts)]
    else: result=rs.AddPoints(pts)
    rs.SelectObjects(result)
    
    #Set preferences
    sc.sticky["RPG_PtCount"] = pt_count
    sc.sticky["RPG_SpaceChoice"] = space
    sc.sticky["RPG_PCChoice"] = pc[0]
    sc.sticky["RPG_xScale"] = dx
    sc.sticky["RPG_yScale"] = dy
    sc.sticky["RPG_zScale"] = dz
    
RandomPointGenerator3D()