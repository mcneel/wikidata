Imports RMA.Rhino

Public Class InflectionPointsPlugIn
  Inherits RMA.Rhino.MRhinoUtilityPlugIn

  Public Overrides Function PlugInID() As System.Guid
    Return New System.Guid("{31e8797f-08eb-463f-bf9f-406f973b2dec}")
  End Function

  Public Overrides Function PlugInName() As String
    Return "InflectionPoints"
  End Function

  Public Overrides Function PlugInVersion() As String
    Return "1.0.0.0"
  End Function

  Public Overrides Function OnLoadPlugIn() As Integer
    Return 1
  End Function

  Public Overrides Sub OnUnloadPlugIn()
  End Sub
End Class