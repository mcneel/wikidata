import rhinoscriptsyntax as rs
#selects planar curves only
entity="curve"
err_msg="No planar {}s added to selection".format(entity) 
objs=rs.ObjectsByType(4,state=1)
if objs:
    select=[obj for obj in objs if rs.IsCurve(obj) and rs.IsCurvePlanar(obj)]
    if select:
        rs.EnableRedraw(False)
        rs.SelectObjects(select)
        if len(select)>1: entity+="s"
        print "{} planar {} added to selection".format(len(select),entity)
    else: print err_msg
else: print err_msg