import rhinoscriptsyntax as rs
import scriptcontext as sc
"""Changes selected circles to new diameter. Script by Mitch Heynick 26.08.15"""

def circ_filt(rhino_object, geometry, component_index):
    return geometry.IsCircle()

def ChangeCircleDia():
    msg="Select circles to change diameter"
    tol=rs.UnitAbsoluteTolerance()
    objs=rs.GetObjects(msg,4,preselect=True,custom_filter=circ_filt)
    if not objs: return
    
    new_dia=rs.GetReal("New circle diameter?",minimum=tol)
    if not new_dia: return
    
    #rs.EnableRedraw(False)
    for obj in objs:
        sf=new_dia/(rs.CircleRadius(obj)*2.0)
        rs.ScaleObject(obj,rs.CircleCenterPoint(obj),[sf,sf,sf],False)
        pass
    print "Changed {} circles to diameter of {}".format(len(objs),new_dia)
ChangeCircleDia()