"""Reduce point count of polyline objects within tolerance
Mimics the behavior of the corresponding Grasshopper component
Uses RhinoCommon method Rhino.Geometry.Polyline.ReduceSegments
Preserves object color, layer and grouping
This version will convert curves (splines/polycurves) to polylines using the
same fitting tolerance as the rest.  Ignores lines, circles, arcs, ellipses.
Script by Mitch Heynick 25 February, 2014 - added reporting 11.03.15
Revised 26.08.15 - adapted for Mac (supress progress meter)"""

import rhinoscriptsyntax as rs
import Rhino
import scriptcontext as sc
from System import Guid

def plpcs_filt(rhino_object, geometry, component_index):
    #polylines, polycurves, splines
    a=rs.IsPolyline(geometry) and not rs.IsLine(geometry)
    b=rs.IsPolyCurve(geometry)
    c=not(rs.IsCircle(geometry) or rs.IsArc(geometry))
    d=not(rs.IsEllipse(geometry) or rs.IsLine(geometry))
    return a | b | (c & d)

def ConvertAndReducePolylines():
    msg="Select curves to process"
    crvIDs=rs.GetObjects(msg,4,preselect=True,custom_filter=plpcs_filt)
    if not crvIDs: return
    
    if sc.sticky.has_key("RPFittingTolerance"):
        def_tol = sc.sticky["RPFittingTolerance"]
    else:
        def_tol = 0.1
    absTol=sc.doc.ModelAbsoluteTolerance
    tol=rs.GetReal("Fitting Tolerance?",def_tol,absTol,)
    if tol == None: return
    
    rept=[len(crvIDs),0,0]
    rs.StatusBarProgressMeterShow("Processing curves",0,len(crvIDs),True,True)
    for i, crvID in enumerate(crvIDs):
        layer=rs.ObjectLayer(crvID)
        col_source=rs.ObjectColorSource(crvID)
        if col_source==1: color=rs.ObjectColor(crvID)
        groups=rs.ObjectGroups(crvID)
        obj=sc.doc.Objects.Find(crvID)
        if not rs.IsPolyline(crvID):
            crvObj=obj.Geometry.ToPolyline(0,0,0,0,0,tol,absTol,0,True)
        else:
            crvObj=obj.Geometry
        if crvObj:
            rc,pl=Rhino.Geometry.PolylineCurve.TryGetPolyline(crvObj)
            if rc:
                orig_count=pl.Count
                Rhino.Geometry.Polyline.ReduceSegments(pl,tol)
                if pl.IsValid:
                    newCrvID=sc.doc.Objects.AddPolyline(pl)
                    if newCrvID != Guid.Empty:
                        #report number of points
                        rept[1]+=orig_count
                        rept[2]+=pl.Count
                        rs.ObjectLayer(newCrvID,layer)
                        if col_source==1: rs.ObjectColor(newCrvID,color)
                        if len(groups)>0:
                            for group in groups: rs.AddObjectsToGroup(newCrvID,group)
                        sc.doc.Objects.Delete(crvID, True)
        rs.StatusBarProgressMeterUpdate(i,True)
    sc.doc.Views.Redraw()
    rs.StatusBarProgressMeterHide()
    sc.sticky["RPFittingTolerance"] = tol
    #report
    msg="Finished processing {} curves. ".format(rept[0])
    print msg+"Point count reduced by {:.0f}%".format((rept[2]/rept[1])*100)
ConvertAndReducePolylines()