//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TabbedDockbarDemo.rc
//
#define IDD_MYTAB                       6002
#define IDI_ICON1                       6003
#define IDI_TAB                         6003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        6004
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         6002
#define _APS_NEXT_SYMED_VALUE           6002
#endif
#endif
