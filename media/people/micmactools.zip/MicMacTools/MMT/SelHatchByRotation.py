import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def GetObjectOrValue(prompt,filt=None):
    #prompt==command line prompt
    go = Rhino.Input.Custom.GetObject()
    go.SetCommandPrompt(prompt)
    go.AcceptNumber(True,True)
    if filt: go.GeometryFilter=filt
    value=None
    while True:
        get_rc = go.Get()
        if get_rc==Rhino.Input.GetResult.Cancel: return
        if get_rc==Rhino.Input.GetResult.Object:
            value=go.Object(0)
            break
        elif get_rc==Rhino.Input.GetResult.Number:
            value=go.Number()
            break
    return value

def SelHatchByRotation():
    objs = rs.ObjectsByType(65536)
    if not objs: return
    tol=sc.doc.ModelAbsoluteTolerance
    
    msg1="Select a hatch to match rotation or enter an angle to search for"
    gf=Rhino.DocObjects.ObjectType.Hatch
    result=GetObjectOrValue(msg1,gf)
    if result is None: return
    if isinstance(result,Rhino.DocObjects.ObjRef):
        rot=rs.HatchRotation(result.ObjectId)
    else:
        rot=result
        
    rs.EnableRedraw(False)
    n = 0
    for obj in objs:
        if rs.IsObjectSelectable(obj):
            hp_rot=rs.HatchRotation(obj)
            if abs(hp_rot-rot)<tol:
                rs.SelectObject(obj)
                n += 1
    if n>0:
        if n==1: s=""
        else: s="es"
        print "Selected {} hatch{} with rotation angle of {}".format(n,s,rot)
    else: print "No hatches of requested rotation angle found"
SelHatchByRotation()