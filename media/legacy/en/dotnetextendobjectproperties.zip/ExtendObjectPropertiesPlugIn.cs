using RMA.Rhino;
using RMA.UI;

using System;
using System.Collections;
using System.Collections.Generic;

namespace ExtendObjectProperties
{
  ///<summary>
  /// Every Rhino.NET Plug-In must have one and only one MRhinoPlugIn derived
  /// class. DO NOT create an instance of this class. It is the responsibility
  /// of Rhino.NET to create an instance of this class and register it with Rhino.
  ///</summary>
  public class ExtendObjectPropertiesPlugIn : RMA.Rhino.MRhinoUtilityPlugIn
  {
    // data members
    public CMyObjectPropertiesDialogPage m_ObjPropPage = new CMyObjectPropertiesDialogPage();

    ///<summary>
    /// Rhino tracks plug-ins by their unique ID. Every plug-in must have a unique id.
    /// The Guid created by the project wizard is unique. You can create more Guids using
    /// the "Create Guid" tool in the Tools menu.
    /// </summary>
    /// <returns>The id for this plug-in</returns>
    public override System.Guid PlugInID()
    {
      return new System.Guid("{6c94ab29-4996-4d7e-bbf5-8130df795015}");
    }

    /// <returns>Plug-In name as displayed in the plug-in manager dialog</returns>
    public override string PlugInName()
    {
      return "ExtendObjectProperties";
    }

    ///<returns>Version information for this plug-in</returns>
    public override string PlugInVersion()
    {
      return "1.0.0.0";
    }

    ///<summary>
    /// Called after the plug-in is loaded and the constructor has been run.
    /// This is a good place to perform any significant initialization,
    /// license checking, and so on.  This function must return 1 for
    /// the plug-in to continue to load.
    ///</summary>
    ///<returns>
    ///  1 = initialization succeeded, let the plug-in load
    ///  0 = unable to initialize, don't load plug-in and display an error dialog
    /// -1 = unable to initialize, don't load plug-in and do not display an error
    ///      dialog. Note: OnUnloadPlugIn will not be called
    ///</returns>
    public override int OnLoadPlugIn()
    {
      return 1;
    }

    ///<summary>
    /// Called when the plug-in is about to be unloaded.  After this
    /// function is called, the plug-in will be disposed.
    ///</summary>
    public override void OnUnloadPlugIn()
    {
      // TODO: Add plug-in cleanup code here.
    }

    // Note using statements at top of this file which are necessary for List and MRhinoObjectPropertiesDialogPage
    public override void AddPagesToObjectPropertiesDialog(List<MRhinoObjectPropertiesDialogPage> pages)
    {
      pages.Add(m_ObjPropPage);
    }
  }

  ///<summary>
  /// This is our custom MRhinoObjectPropertiesDialogPage-inherited class
  /// that is used to display our custom object properties.
  ///</summary>
  public class CMyObjectPropertiesDialogPage : MRhinoObjectPropertiesDialogPage
  {
    // data members
    public MyObjectPropertiesPage m_UserControl = new MyObjectPropertiesPage();
    
    ////////////////////////////////////////////////////////////////////////
    // Required MRhinoStackedDialogPage overrides

    public override string EnglishPageTitle()
    { return "Example Page"; 
    }

    public override string LocalPageTitle()
    { 
      return EnglishPageTitle(); 
    }

    public override System.Windows.Forms.Control GetPageControl()
    {
      return m_UserControl;
    }

    ////////////////////////////////////////////////////////////////////////
    // Required MRhinoObjectPropertiesDialogPage overrides

    public override void InitControls(IRhinoObject new_obj)
    {
      m_UserControl.InitControls(new_obj);
    }

    public override bool AddPageToControlBar(IRhinoObject obj)
    {
      return m_UserControl.AddPageToControlBar(obj);
    }

    public override IRhinoCommand.result RunScript(IRhinoObject[] objects)
    {
      return m_UserControl.RunScript(objects);
    }
  }
}
