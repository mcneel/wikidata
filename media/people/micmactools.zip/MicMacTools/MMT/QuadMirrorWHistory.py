"""Script to mirror objects in X and Y around a point (relative to active CPlane)
If not active, history recording is enabled for the operation, then set back
to its original state. Script by Mitch Heynick 25.06.15"""

import rhinoscriptsyntax as rs
import Rhino.ApplicationSettings.HistorySettings as hs
import scriptcontext as sc

def QuadMirror():
    objs=rs.GetObjects("Select objects to quad mirror",preselect=True)
    if not objs: return
    m_pt=rs.GetPoint("Pick point to mirror around")
    if not m_pt: return
    hist=hs.RecordingEnabled
    hs.RecordingEnabled=True
    
    plane=rs.ViewCPlane()
    plane.Origin=m_pt
    rs.EnableRedraw(False)
    xform_x=rs.XformMirror(plane.Origin,plane.XAxis)
    xform_y=rs.XformMirror(plane.Origin,plane.YAxis)
    x_copy=[sc.doc.Objects.TransformWithHistory(obj,xform_x) for obj in objs]
    if x_copy:
        objs+=x_copy
        y_copy=[sc.doc.Objects.TransformWithHistory(obj,xform_y) for obj in objs]
        if y_copy:
            objs+=y_copy
            rs.SelectObjects(objs)
    hs.RecordingEnabled=hist
QuadMirror()