/////////////////////////////////////////////////////////////////////////////
// ModelessSampleApp.h : main header file for the ModelessSample DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "Resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CModelessSampleApp
// See ModelessSampleApp.cpp for the implementation of this class
//

class CModelessSampleApp : public CWinApp
{
public:
	CModelessSampleApp();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};
