import rhinoscriptsyntax as rs
import Rhino

def circ_filt(rhino_object, geometry, component_index):
    return geometry.IsCircle()

def GetCircleRadOrNumber(prompt):
    #prompt==command line prompt
    #returns None if Esc is pressed or no objects are chosen
    #otherwise, returns circle radius or entered value
    boolOption = Rhino.Input.Custom.OptionToggle(True, "Diameter", "Radius")
    
    go=Rhino.Input.Custom.GetObject()
    go.GeometryFilter = Rhino.DocObjects.ObjectType.Curve
    go.SetCommandPrompt(prompt)
    go.SetCustomGeometryFilter(circ_filt)
    go.AddOptionToggle("Input", boolOption)
    go.AcceptNumber(True,True)
    
    while True:
        get_rc = go.Get()
        if go.CommandResult()== Rhino.Commands.Result.Cancel:
            return #go.CommandResult()
        elif get_rc==Rhino.Input.GetResult.Option:
            continue
        elif get_rc==Rhino.Input.GetResult.Number:
            #number is returned
            if go.Number()<=0:
                print "Radius or Diameter must be positive"
                continue
            else:
                #number is positive
                return boolOption.CurrentValue, go.Number()
        else:
            #object is returned
            circle=go.Object(0).Geometry()
            return boolOption.CurrentValue, circle.Radius 

def ReplaceCircleRadDia():
    tol = rs.UnitAbsoluteTolerance()
    err_msg="No circles found in file!"
    crvs=rs.ObjectsByType(4, state=1)
    if not crvs: print err_msg ; return
    circles=[c for c in crvs if rs.IsCircle(c) and rs.IsObjectSelectable(c)]
    if not circles: print err_msg ; return
    
    msg="Select one circle of rad./dia. to change or key in a value to search for"
    user_input=GetCircleRadOrNumber(msg)
    if user_input is None: return
    if user_input[0]: t_rad=user_input[1]
    else:t_rad=user_input[1]*0.5
    
    targs=[]
    for circ in circles:
        if abs(t_rad-rs.CircleRadius(circ))<tol: targs.append(circ)
    if len(targs)==0:
        print "No circles found of desired radius" ; return
        
    #redraw cut because of a bug in rhinoscriptsyntax Rhino V5
    rs.EnableRedraw(False)
    rs.SelectObjects(targs)
    rs.Redraw()
    
    if user_input[0]:
        r_type="radius"
        u_rad=t_rad
    else:
        r_type="diameter"
        u_rad=t_rad*2
    msg="{} circles of {} {} found.  ".format(len(targs),r_type,u_rad)
    msg+="New {} for circles?".format(r_type)
    new=rs.GetReal(msg,minimum=tol)
    if new is None:
        rs.UnselectAllObjects() ; return
    
    rs.EnableRedraw(False)
    if user_input[0]: new_rad=new
    else: new_rad=new/2.0
    for circle in targs:
        sf = new_rad/t_rad
        rs.ScaleObject(circle,rs.CircleCenterPoint(circle),[sf,sf,sf])
    print "{} circles changed from {} {} to {}".format(len(targs),r_type,u_rad,new)
ReplaceCircleRadDia()
