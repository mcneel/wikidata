import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino
"""Adds a 1D, 2D or 3D grid of points to document, XYZ world aligned.
User selectable start point (lower left corner).  Options to specify individual
cell size or overall grid size; create individual points or a point cloud.
Crash warning message for over "n" individual points (100K default)
Script by Mitch Heynick Version 03.09.15"""

def GetCellSize(pt_count,o_dist):
    return o_dist/(pt_count-1)

def PointGrid3D():
    tol=sc.doc.ModelAbsoluteTolerance
    #get previous values, initialize
    if "PG3_XN" in sc.sticky: usr_xN = sc.sticky["PG3_XN"]
    else: usr_xN = 10
    if "PG3_YN" in sc.sticky: usr_yN = sc.sticky["PG3_YN"]
    else: usr_yN = 10
    if "PG3_ZN" in sc.sticky: usr_zN = sc.sticky["PG3_ZN"]
    else: usr_zN = 10
    if "PG3_XD" in sc.sticky: usr_xD = sc.sticky["PG3_XD"]
    else: usr_xD = 1.0
    if "PG3_YD" in sc.sticky: usr_yD = sc.sticky["PG3_YD"]
    else: usr_yD = 1.0
    if "PG3_ZD" in sc.sticky: usr_zD = sc.sticky["PG3_ZD"]
    else: usr_zD = 1.0
    if "PG3_CS" in sc.sticky: usr_cell_size = sc.sticky["PG3_CS"]
    else: usr_cell_size = True
    if "hhh" in sc.sticky: usr_pcc = sc.sticky["hhh"]
    else: usr_pcc = True
    pt_count=1
    warn_limit=100000
    
    #user input
    msg1="Number of points in "
    xN=rs.GetInteger(msg1+"X?",usr_xN,0)
    if xN is None: return
    yN=rs.GetInteger(msg1+"Y?",usr_yN,0)
    if yN is None: return
    zN=rs.GetInteger(msg1+"Z?",usr_zN,0)
    if zN is None: return
    
    gridspace=0
    msg1=" distance?"
    if xN:
        gridspace+=1
        xD=rs.GetReal("X"+msg1,usr_xD,tol)
        if xD is None: return
        pt_count*=xN
    if yN:
        gridspace+=1
        yD=rs.GetReal("Y"+msg1,usr_yD,tol)
        if yD is None: return
        pt_count*=yN
    if zN:
        gridspace+=1
        zD=rs.GetReal("Z"+msg1,usr_zD,tol)
        if zD is None: return
        pt_count*=zN
    
    choice=[("DistanceValues","OverallSize","CellSize"),("CreatePointCloud","No","Yes")]
    gb=rs.GetBoolean("Options",choice,[usr_cell_size,usr_pcc])
    if gb is None: return
    if not gb[0]:
        #cell size is calculated from overall
        if xN: xD=GetCellSize(xN,xD)
        if yN: yD=GetCellSize(yN,yD)
        if zN: zD=GetCellSize(zN,zD)
        
    sPt=rs.GetPoint("Pick point for lower left corner of grid")
    if not sPt: return
    
    if pt_count>warn_limit and not gb[1]:
        #warn user there will ne a lot of individual points
        msg='WARNING:\n'
        msg+='You are about to create {:,} individual points!\n'.format(pt_count)
        msg+='Rhino could run out of memory and crash.\n'
        msg+='Choose "Yes" to create a pointcloud instead, "No" to continue'
        resp=rs.MessageBox(msg,3+48)
        if not resp or resp==2: return
        elif resp==6: gb[1]=True
        else: pass
    
    #create point grid
    spX=sPt.X ; spY=sPt.Y ; spZ=sPt.Z
    pts=[]
    if gridspace==3:
        #XYZ grid
        for k in range(zN):
            for j in range(yN):
                for i in range(xN):
                    pts.append(Rhino.Geometry.Point3d(spX+(i*xD),spY+(j*yD),spZ+(k*zD)))
    elif gridspace==2:
        #2 dimensional grid
        if zN==0:
            #XY grid
            for j in range(yN):
                for i in range(xN):
                    pts.append(Rhino.Geometry.Point3d(spX+(i*xD),spY+(j*yD),spZ))
        elif yN==0:
            #ZX grid
            for k in range(zN):
                for i in range(xN):
                    pts.append(Rhino.Geometry.Point3d(spX+(i*xD),spY,spZ+(k*zD)))
        else:
            #YZ grid
            for k in range(zN):
                for j in range(yN):
                    pts.append(Rhino.Geometry.Point3d(spX,spY+(j*yD),spZ+(k*zD)))
    else:
        #1 dimensional grid
        if xN != 0:
            for i in range(xN):
                pts.append(Rhino.Geometry.Point3d(spX+(i*xD),spY,spZ))
        elif yN != 0:
            for j in range(yN):
                pts.append(Rhino.Geometry.Point3d(spX,spY+(j*yD),spZ))
        else:
            for k in range(zN):
                pts.append(Rhino.Geometry.Point3d(spX,spY,spZ+(k*zD)))
                
    #add points to document
    if not gb[1]:
        rs.AddPoints(pts)
    else:
        rs.AddPointCloud(pts)
        
    #store previous values
    if xN is not None: sc.sticky["PG3_XN"] = xN
    if yN is not None: sc.sticky["PG3_YN"] = yN
    if zN is not None: sc.sticky["PG3_ZN"] = zN
    if xD is not None:
        if not gb[0]: xD*=(xN-1)
        sc.sticky["PG3_XD"] = xD
    if yD is not None:
        if not gb[0]: yD*=(yN-1)
        sc.sticky["PG3_YD"] = yD
    if zD is not None:
        if not gb[0]: zD*=(zN-1)
        sc.sticky["PG3_ZD"] = zD
    sc.sticky["PG3_CS"] = gb[0]
    sc.sticky["hhh"] = gb[1]
    
PointGrid3D()