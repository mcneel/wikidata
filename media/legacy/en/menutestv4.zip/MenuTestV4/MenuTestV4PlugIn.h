/////////////////////////////////////////////////////////////////////////////
// MenuTestV4PlugIn.h : main header file for the MenuTestV4 plug-in
//

#pragma once

/////////////////////////////////////////////////////////////////////////////
// CMenuTestV4PlugIn
// See MenuTestV4PlugIn.cpp for the implementation of this class
//

class CMenuTestV4PlugIn : public CRhinoUtilityPlugIn
{
public:
  CMenuTestV4PlugIn();
  ~CMenuTestV4PlugIn();

  // Required overrides
  const wchar_t* PlugInName() const;
  const wchar_t* PlugInVersion() const;
  GUID PlugInID() const;
  BOOL OnLoadPlugIn();
  void OnUnloadPlugIn();

  // Online help overrides
  BOOL AddToPlugInHelpMenu() const;
  BOOL OnDisplayPlugInHelp( HWND hWnd ) const;

  void OnInitPlugInMenuPopups( WPARAM wParam, LPARAM lParam);
  BOOL OnPlugInMenuCommand( WPARAM wParam);

private:
  ON_wString m_plugin_version;
  bool m_script_mode;
  CMenu m_menu;
};

CMenuTestV4PlugIn& MenuTestV4PlugIn();



