The Rhino Guid Generator is a standalone in-house application
that will generate new Guids (ala Guidgen.exe). I've added two
new formats that I find useful. You might find them useful too.

To use this tool in Visual Studio 2005:

1. Put http:/subversion.mcneel.com/rhino/usr/RhinoGuidgen/ on 
   your computer. 

2. Launch Visual Studio 2005. 

3. Select Tools->External Tools... 

4. Select "Create &Guid" in the menu contents list. 

5. Modify this item's command to point to the following executable:

   ...\RhinoGuidgen\Release\RhinoGuidgen.exe

6. Add "/a" to the argument field. This allows RhinoGuidgen.exe 
   to be parented to the IDE window.

If you're ambitious enough, you might even make a toolbar button.

