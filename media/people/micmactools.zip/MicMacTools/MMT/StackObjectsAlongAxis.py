import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino
"""Script to stack objects according to their bounding box along X, Y or Z axes
Script by Mitch Heynick 09.06.15"""

def CommandLineOptions(axis_index,bo):
    go = Rhino.Input.Custom.GetOption()
    go.SetCommandPrompt("DirectionSettings")
    # set up the options
    axis_opt = ("X", "Y", "Z")
    axis_list = go.AddOptionList("StackingAxis", axis_opt, axis_index)
    bool_opt = Rhino.Input.Custom.OptionToggle(bo,"TowardsMinus","TowardsPlus")    
    go.AddOptionToggle("MoveObjects", bool_opt)
    go.AcceptNothing(True)
    
    #get options
    while True:
        get_rc = go.Get()
        if go.CommandResult()== Rhino.Commands.Result.Cancel:
            return
        elif get_rc==Rhino.Input.GetResult.Option:
            if go.OptionIndex()==axis_list:
                axis_index = go.Option().CurrentListOptionIndex
            continue
        break
    return [axis_index ,bool_opt.CurrentValue]
    
def StackObjectsAlongAxis():
    obj_filt=4+8+16+32+4096
    objs = rs.GetObjects("Select objects to stack",obj_filt,preselect=True)
    if not objs: return
    #get previous settings
    if "StackAxis_AxisOpt" in sc.sticky: axis = sc.sticky["StackAxis_AxisOpt"]
    else: axis = 2
    if "StackAxis_DirOpt" in sc.sticky: dir = sc.sticky["StackAxis_DirOpt"]
    else: dir=False
    cl_opts=CommandLineOptions(axis,dir)
    if not cl_opts: return
        
    if cl_opts[0]==0: A=1 ; B=0 ; dir_vec=Rhino.Geometry.Vector3d(1, 0, 0) #X
    elif cl_opts[0]==1: A=3 ; B=1 ; dir_vec=Rhino.Geometry.Vector3d(0, 1, 0) #Y
    elif cl_opts[0]==2: A=4 ; B=2 ; dir_vec=Rhino.Geometry.Vector3d(0, 0, 1) #Z
    
    obj_bb_list=[]
    for obj in objs:
        bb = rs.BoundingBox(obj)
        obj_bb_list.append((bb[A][B],obj))
    obj_bb_list.sort(reverse=cl_opts[1])
    obj_list_sorted=[obj[1] for obj in obj_bb_list]
    first_obj=obj_list_sorted.pop(0)
    bb_obj = rs.BoundingBox(first_obj)
    if cl_opts[1]: target = bb_obj[0][B]
    else: target = bb_obj[A][B]
    
    rs.EnableRedraw(False)
    for obj in (obj_list_sorted):    
        bb_obj = rs.BoundingBox(obj)
        if cl_opts[1]: move = target - bb_obj[A][B]
        else: move = target - bb_obj[0][B]
        rs.MoveObject(obj, move*dir_vec)
        if cl_opts[1]: target = bb_obj[0][B] + move
        else: target = bb_obj[A][B] + move
        
    #Set preferences
    sc.sticky["StackAxis_AxisOpt"] = cl_opts[0]
    sc.sticky["StackAxis_DirOpt"] = cl_opts[1]
    
StackObjectsAlongAxis()