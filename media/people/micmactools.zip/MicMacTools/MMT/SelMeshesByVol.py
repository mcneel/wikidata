import rhinoscriptsyntax as rs
import scriptcontext as sc
from Rhino import RhinoMath
    
def SelMeshesByVol():
    meshes=rs.ObjectsByType(32,state=1)
    if not meshes: return
    objs=[mesh for mesh in meshes if rs.IsObjectSolid(mesh)]
    if not objs:
        print "No closed meshes found"
        return
    tol=sc.doc.ModelAbsoluteTolerance
    ff=RhinoMath.SqrtEpsilon #"fuzz factor"
    entity="mesh"
    measure="volume"
    cl=["LessThan","GreaterThan","EqualTo","LTorEqualTo","GTorEqualTo","Between"]
    
    #get previous settings
    if "SMV_Type_Choice" in sc.sticky: type_choice = sc.sticky["SMV_Type_Choice"]
    else: type_choice = cl[0]
    if "SMV_User_V" in sc.sticky: user_V = sc.sticky["SMV_User_V"]
    else: user_V = 1.0
    if "SMV_Max_V" in sc.sticky: max_V = sc.sticky["SMV_Max_V"]
    else: max_V = 1.0
    if "SMV_Min_V" in sc.sticky: min_V = sc.sticky["SMV_Min_V"]
    else: min_V = 1.0
    
    rs.UnselectAllObjects()
    msg="Selection type for {} {}?".format(entity,measure)
    while True:
        compare=rs.GetString(msg,type_choice,cl)
        if not compare: return
        if compare in cl: break
    
    if compare == cl[5]:
        min_V=rs.GetReal("Minimum volume?",min_V,minimum=tol)
        if not min_V: return
        if max_V<min_V: max_V=min_V
        max_V=rs.GetReal("Maximum volume?",max_V,minimum=min_V)
        if not max_V: return
    else:
        vol=rs.GetReal("Volume?",user_V,minimum=tol)
        if not vol: return
        
    rs.EnableRedraw(False)
    for obj in objs:
        mv=rs.MeshVolume(obj)
        if mv: obj_vol=mv[1]
        if not obj_vol: continue
        if compare==cl[0]:
            if obj_vol < vol-ff: rs.SelectObject(obj)
        elif compare==cl[1]:
            if obj_vol > vol+ff: rs.SelectObject(obj)
        elif compare==cl[2]:
            if abs(vol-obj_vol)<ff: rs.SelectObject(obj)
        elif compare==cl[3]:
            if obj_vol <= vol: rs.SelectObject(obj)
        elif compare==cl[4]:
            if obj_vol >= vol: rs.SelectObject(obj)
        elif compare==cl[5]:
            if obj_vol >= min_V and obj_vol <= max_V: rs.SelectObject(obj)
            
    selObjs=rs.SelectedObjects()
    if selObjs:
        q=len(selObjs)
        if q>1: entity+="es"
    else: q="No" ; entity+="es"
    print "{} {} found that match selection criteria".format(q,entity)
    
    #store previous settings
    sc.sticky["SMV_Type_Choice"] = compare
    try: sc.sticky["SMV_User_V"] = vol
    except: pass
    try: sc.sticky["SMV_Max_V"] = max_V
    except: pass
    try: sc.sticky["SMV_Min_V"] = min_V
    except: pass
SelMeshesByVol()
