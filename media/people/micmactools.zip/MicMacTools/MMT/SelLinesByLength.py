import rhinoscriptsyntax as rs
import scriptcontext as sc
from Rhino import RhinoMath
    
def SelLinesByLength():
    objs=rs.ObjectsByType(4,state=1)
    if not objs: return
    tol=sc.doc.ModelAbsoluteTolerance
    ff=RhinoMath.SqrtEpsilon #"fuzz factor"
    entity="line"
    measure="length"
    cl=["LessThan","GreaterThan","EqualTo","LTorEqualTo","GTorEqualTo","Between"]
    
    #get previous settings
    if "SLL_Type_Choice" in sc.sticky: type_choice = sc.sticky["SLL_Type_Choice"]
    else: type_choice = cl[0]
    if "SLL_User_L" in sc.sticky: user_L = sc.sticky["SLL_User_L"]
    else: user_L = 1.0
    if "SLL_Max_L" in sc.sticky: max_L = sc.sticky["SLL_Max_L"]
    else: max_L = 1.0
    if "SLL_Min_L" in sc.sticky: min_L = sc.sticky["SLL_Min_L"]
    else: min_L = 1.0
    
    rs.UnselectAllObjects()
    msg="Selection type for {} {}?".format(entity,measure)
    while True:
        compare=rs.GetString(msg,type_choice,cl)
        if not compare: return
        if compare in cl: break
    
    if compare == cl[5]:
        min_L=rs.GetReal("Minimum length?",min_L,minimum=tol)
        if not min_L: return
        if max_L<min_L: max_L=min_L
        max_L=rs.GetReal("Maximum length?",max_L,minimum=min_L)
        if not max_L: return
    else:
        length=rs.GetReal("Length?",user_L,minimum=tol)
        if not length: return
        
    rs.EnableRedraw(False)
    for obj in objs:
        if rs.IsLine(obj):
            obj_len=rs.CurveLength(obj)
            if compare==cl[0]:
                if obj_len < length-ff: rs.SelectObject(obj)
            elif compare==cl[1]:
                if obj_len > length+ff: rs.SelectObject(obj)
            elif compare==cl[2]:
                if abs(length-obj_len)<ff: rs.SelectObject(obj)
            elif compare==cl[3]:
                if obj_len <= length: rs.SelectObject(obj)
            elif compare==cl[4]:
                if obj_len >= length: rs.SelectObject(obj)
            elif compare==cl[5]:
                if obj_len >= min_L and obj_len <= max_L: rs.SelectObject(obj)
                
    selObjs=rs.SelectedObjects()
    if selObjs:
        q=len(selObjs)
        if q>1: entity+="s"
    else: q="No" ; entity+="s"
    print "{} {} found that match selection criteria".format(q,entity)
        
    #store previous settings
    sc.sticky["SLL_Type_Choice"] = compare
    try: sc.sticky["SLL_User_L"] = length
    except: pass
    try: sc.sticky["SLL_Max_L"] = max_L
    except: pass
    try: sc.sticky["SLL_Min_L"] = min_L
    except: pass
SelLinesByLength()
