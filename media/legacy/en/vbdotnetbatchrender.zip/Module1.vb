Module Module1

  Sub Main()

    ' Browse for folder
    Dim strFolder As String
    strFolder = GetFolderPath()
    If (strFolder.Length = 0) Then Exit Sub

    ' Create Rhino object
    Console.Write("Creating Rhino object...")
    Dim oRhino As Rhino4.Application
    On Error Resume Next
    oRhino = CreateObject("Rhino4.Application")
    If (Err.Number <> 0) Then
      Console.WriteLine("failed.")
      Exit Sub
    Else
      Console.WriteLine("succeeded.")
    End If

    ' Retrieve RhinoScript object
    Dim oRhinoScript As RhinoScript4.RhinoScript = Nothing
    Console.Write("Retrieving RhinoScript object...")
    Dim nCount As Integer = 0
    Do While (nCount < 10)
      On Error Resume Next
      oRhinoScript = oRhino.GetScriptObject
      If (Err.Number <> 0) Then
        Err.Clear()
        System.Threading.Thread.Sleep(500)
        nCount = nCount + 1
      Else
        Exit Do
      End If
    Loop

    If (oRhinoScript Is Nothing) Then
      Console.WriteLine("failed.")
      oRhino = Nothing
      Exit Sub
    Else
      Console.WriteLine("succeeded.")
    End If

    ' Create file system object
    Console.Write("Creating file system object...")
    Dim oFSO As Object = Nothing
    oFSO = CreateObject("Scripting.FileSystemObject")
    If (Err.Number <> 0) Then
      Console.WriteLine("failed.")
      oRhinoScript = Nothing
      oRhino = Nothing
      Exit Sub
    Else
      Console.WriteLine("succeeded.")
    End If

    ' Render all 3dm files in selected folder
    Dim oFolder As Object = Nothing
    Dim oFile As Object = Nothing
    Dim strFile As String
    Dim strBitmap As String
    oFolder = oFSO.GetFolder(strFolder)
    For Each oFile In oFolder.Files
      strFile = oFile.Path
      If (InStr(LCase(strFile), ".3dm") > 0) Then
        strBitmap = Replace(strFile, ".3dm", ".jpg", 1, -1, 1)
        Console.WriteLine("Processing " & strFile & "...")
        oRhinoScript.DocumentModified(False)
        Console.WriteLine("  Opening")
        oRhinoScript.Command("_-Open " & Chr(34) & strFile & Chr(34))
        Console.WriteLine("  Rendering")
        oRhinoScript.Command("_-Render")
        Console.WriteLine("  Saving")
        oRhinoScript.Command("_-SaveRenderWindowAs " & Chr(34) & strBitmap & Chr(34))
        Console.WriteLine("  Closing render window")
        oRhinoScript.Command("_-CloseRenderWindow")
        oRhinoScript.DocumentModified(False)
        Console.WriteLine("  Done")
      End If
    Next

    Console.Write("Cleaning up...")
    oFile = Nothing
    oFolder = Nothing
    oFSO = Nothing
    oRhinoScript = Nothing
    oRhino = Nothing
    Console.WriteLine("done!")

  End Sub

  ' Wrapper function for BrowseForFolder class
  Function GetFolderPath()
    Dim dialog As New BrowseForFolder()
    Dim strPath As String
    strPath = dialog.BrowseDialog("Select folder")
    GetFolderPath = strPath
  End Function

  ' Browse for folder class
  Public Class BrowseForFolder
    Inherits System.Windows.Forms.Design.FolderNameEditor

    Dim m_dialog As New FolderBrowser()

    Public Function BrowseDialog(ByVal strTitle As String)
      BrowseDialog = ""
      m_dialog.Style = FolderBrowserStyles.RestrictToSubfolders
      m_dialog.StartLocation = FolderBrowserFolder.Desktop
      m_dialog.Description = strTitle
      Dim rc As System.Windows.Forms.DialogResult
      rc = m_dialog.ShowDialog()
      If (rc = Windows.Forms.DialogResult.OK) Then
        BrowseDialog = m_dialog.DirectoryPath()
      End If
    End Function

  End Class

End Module
