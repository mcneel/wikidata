//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MenuTestV4.rc
//
#define IDR_MENU1                       14000
#define IDR_MENUTEST                    14000
#define ID_TESTCOMMAND1_TESTCOMMAND2    32771
#define ID_MENU_TESTCOMMAND2            32772
#define ID_MENU_SCRIPTMODE              32773
#define ID_TESTMENU_TESTCOMMAND1        32774
#define ID_TESTMENU_TESTCOMMAND2        32775
#define ID_TESTMENU_SCRIPTMODE          32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        14001
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         14000
#define _APS_NEXT_SYMED_VALUE           14000
#endif
#endif
