import rhinoscriptsyntax as rs
import scriptcontext as sc
from Rhino import RhinoMath

def GetBrepVol(objID):
    #faster than rs.SurfaceVolume()
    brep=sc.doc.Objects.Find(objID).Geometry
    if brep:
        brep=brep.ToBrep(True) #for extrusion objects
    if brep: return brep.GetVolume()
    
def SelSrfsByVol():
    breps=rs.ObjectsByType(8+16,state=1)
    if not breps: return
    objs=[brep for brep in breps if rs.IsObjectSolid(brep)]
    if not objs:
        print "No closed surfaces or polysurfaces found"
        return
    tol=sc.doc.ModelAbsoluteTolerance
    ff=RhinoMath.SqrtEpsilon #"fuzz factor"
    entity="surface"
    entity2="polysurface"
    measure="volume"
    cl=["LessThan","GreaterThan","EqualTo","LTorEqualTo","GTorEqualTo","Between"]
    
    #get previous settings
    if "SSV_Type_Choice" in sc.sticky: type_choice = sc.sticky["SSV_Type_Choice"]
    else: type_choice = cl[0]
    if "SSV_User_V" in sc.sticky: user_V = sc.sticky["SSV_User_V"]
    else: user_V = 1.0
    if "SSV_Max_V" in sc.sticky: max_V = sc.sticky["SSV_Max_V"]
    else: max_V = 1.0
    if "SSV_Min_V" in sc.sticky: min_V = sc.sticky["SSV_Min_V"]
    else: min_V = 1.0
    
    rs.UnselectAllObjects()
    msg="Selection type for {} or {} {}?".format(entity,entity2,measure)
    while True:
        compare=rs.GetString(msg,type_choice,cl)
        if not compare: return
        if compare in cl: break
    
    if compare == cl[5]:
        min_V=rs.GetReal("Minimum volume?",min_V,minimum=tol)
        if not min_V: return
        if max_V<min_V: max_V=min_V
        max_V=rs.GetReal("Maximum volume?",max_V,minimum=min_V)
        if not max_V: return
    else:
        vol=rs.GetReal("Volume?",user_V,minimum=tol)
        if not vol: return
        
    rs.EnableRedraw(False)
    for obj in objs:
        obj_vol=GetBrepVol(obj)
        if not obj_vol: continue
        if compare==cl[0]:
            if obj_vol < vol-ff: rs.SelectObject(obj)
        elif compare==cl[1]:
            if obj_vol > vol+ff: rs.SelectObject(obj)
        elif compare==cl[2]:
            if abs(vol-obj_vol)<ff: rs.SelectObject(obj)
        elif compare==cl[3]:
            if obj_vol <= vol: rs.SelectObject(obj)
        elif compare==cl[4]:
            if obj_vol >= vol: rs.SelectObject(obj)
        elif compare==cl[5]:
            if obj_vol >= min_V and obj_vol <= max_V: rs.SelectObject(obj)
            
    selObjs=rs.SelectedObjects()
    msg="found that match selection criteria"
    if selObjs:
        q=len(selObjs)
        if q>1:
            entity+="s" ; entity2+="s"
    else: q="No" ; entity+="s" ; entity2+="s"
    print "{} {} or {} {}".format(q,entity,entity2,msg)
    
    #store previous settings
    sc.sticky["SSV_Type_Choice"] = compare
    try: sc.sticky["SSV_User_V"] = vol
    except: pass
    try: sc.sticky["SSV_Max_V"] = max_V
    except: pass
    try: sc.sticky["SSV_Min_V"] = min_V
    except: pass
SelSrfsByVol()
