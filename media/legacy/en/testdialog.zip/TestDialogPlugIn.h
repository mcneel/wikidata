#pragma once

#include "TestModelessDialog.h"

class CTestDialogPlugIn : public CRhinoUtilityPlugIn
{
public:
  CTestDialogPlugIn();
  ~CTestDialogPlugIn();

  const wchar_t* PlugInName() const;
  const wchar_t* PlugInVersion() const;
  GUID PlugInID() const;

  BOOL OnLoadPlugIn();
  void OnUnloadPlugIn();

  bool DisplayDialog();
  void SetDialogFocus();
  bool IsDialogVisible();
  void DestroyDialog();

public:
  ON_wString m_sPlugInVersion;
  CTestModelessDialog* m_pDialog;
};

CTestDialogPlugIn& TestDialogPlugIn();
