' NOTE!!!
' In order to get external access to Rhino from a separate program, we need
' to use the Rhino and RhinoScript COM interfaces.
' Make sure your project has references for the Rhino and RhinoScript type
' library by selecting the references tab on the project properties sheet
Public Class Form1
  Private m_rhino As Rhino4.Application = Nothing
  Private m_rhinoscript As RhinoScript4.IRhinoScript = Nothing

  ' this function ensures that we have a connection to rhino and rhinoscript
  Private Function ConnectToRhinoScript() As Boolean
    If (m_rhino Is Nothing) Then
      Me.UseWaitCursor = True
      m_rhino = New Rhino4.Application()

      ' when rhino first loads, it needs to load up the RhinoScript plug-in which
      ' can take a little time. Make a few attempts to get rhinoscript interface
      Dim attempts As Integer = 10
      For i As Integer = 0 To attempts
        'sleep for a half a second to allow rhino load rhinoscript
        System.Threading.Thread.Sleep(500)
        Dim obj As Object = m_rhino.GetScriptObject()
        If (obj IsNot Nothing) Then
          ' we got it
          m_rhinoscript = CType(obj, RhinoScript4.IRhinoScript)
          Exit For
        End If
      Next
      Me.UseWaitCursor = False
    End If

    Return (m_rhinoscript IsNot Nothing)
  End Function

  Private Sub m_btnShowRhino_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles m_btnShowRhino.Click
    If (ConnectToRhinoScript()) Then
      m_rhino.Visible = True
    End If
  End Sub

  Private Sub m_btnDrawLines_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles m_btnDrawLines.Click
    If (ConnectToRhinoScript()) Then
      ' Draw some stuff
      Dim list As New System.Collections.Generic.List(Of Double())
      list.Add(New Double() {0, 0, 0})
      list.Add(New Double() {10, 0, 0})
      list.Add(New Double() {10, 10, 0})
      list.Add(New Double() {0, 10, 0})
      list.Add(New Double() {0, 0, 0})
      list.Add(New Double() {10, 10, 0})
      list.Add(New Double() {0, 10, 0})
      list.Add(New Double() {10, 0, 0})

      For i As Integer = 0 To list.Count - 2
        m_rhinoscript.AddLine(list(i), list(i + 1))
      Next
    End If
  End Sub

  Private Sub m_btnHideRhino_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles m_btnHideRhino.Click
    If (ConnectToRhinoScript()) Then
      m_rhino.Visible = False
    End If
  End Sub
End Class
