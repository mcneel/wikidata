""""Explode a colored point cloud while retaining the point colors
Script by Mitch Heynick, version 29 September 2013"""

import Rhino
import rhinoscriptsyntax as rs
import scriptcontext as sc

def ExplodeColorPointCloud():
    pcID=rs.GetObject("Select color point cloud to explode",2,preselect=True,select=True)
    if not pcID: return
    if not rs.PointCloudHasPointColors(pcID):
        rs.Command("_Explode", False)
        return
    pointlist=[]
    colorlist=[]
    pcObj=rs.coercerhinoobject(pcID)
    for loc in pcObj.Geometry:
        pointlist.append(loc.Location)
        colorlist.append(loc.Color)
    sc.doc.Views.RedrawEnabled = False
    for i,pt in enumerate(pointlist):
        ptID=sc.doc.Objects.AddPoint(pt)
        rs.ObjectColor(ptID,colorlist[i])
    rs.DeleteObject(pcID)
    sc.doc.Views.Redraw()
    
ExplodeColorPointCloud()