// #define CMD_LINE

using RMA.Rhino;
using RMA.OpenNURBS;

// Necessary for StreamReader
using System.IO;


namespace ReadPointFile
{
  ///<summary>
  /// A Rhino.NET plug-in can contain as many MRhinoCommand derived classes as it wants.
  /// DO NOT create an instance of this class (this is the responsibility of Rhino.NET.)
  /// A command wizard can be found in visual studio when adding a new item to the project.
  /// </summary>
  public class ReadPointFileCommand : RMA.Rhino.MRhinoScriptCommand
  {
    ///<summary>
    /// Rhino tracks commands by their unique ID. Every command must have a unique id.
    /// The Guid created by the project wizard is unique. You can create more Guids using
    /// the "Create Guid" tool in the Tools menu.
    ///</summary>
    ///<returns>The id for this command</returns>
    public override System.Guid CommandUUID()
    {
      return new System.Guid("{f24ecb11-75d5-47fe-897c-d6c4c31919cb}");
    }

    ///<returns>The command name as it appears on the Rhino command line</returns>
    public override string EnglishCommandName()
    {
      return "ReadPoints";
    }
    
    ///<summary> 
    /* This gets called when when the user runs this command.
     * It reads points from a file like this:
-13.65,11.24,0.00
-10.59,5.03,0.00
-4.47,0.60,0.00
1.49,2.46,0.00
9.87,0.44,0.00
11.72,-3.83,0.00
15.35,-13.90,0.00
     * and draws a curve through them.
     * This is pretty crude with no error checking etc, but its a place to start
*/
    ///</summary>
    public override IRhinoCommand.result RunCommand(IRhinoCommandContext context)
    {
      // Dialog to get a file name
      MRhinoGetFileDialog dlg = new MRhinoGetFileDialog();
      if(dlg.DisplayFileDialog(IRhinoGetFileDialog.file_dialog_type.open_text_file_dialog))
      {
        string filename = dlg.FileName();
        string line = "";
        RhUtil.RhinoApp().Print(string.Format("Opening file {0}.\n", filename));

        // These aren't necessary for just drawing the curve with RunScript().
        // They show how to get numbers and points from the text in the file.
        // You can change the definition of CMD_LINE (at the top) to make the 
        //  curve with or without using RunScript()
        // The Command class has to be derived from RMA.Rhino.MRhinoScriptCommand 
        //  instead of RMA.Rhino.MRhinoCommand to use RunCommand

        // Delimiters to separate numbers in the text file
        char[] delim = new char[2];
        delim[0] = ','; delim[1] = '\0';
        // an array to accumulate the points for a whole curve
        On3dPointArray points = new On3dPointArray(8);

#if CMD_LINE
        // Start building up a string to send to the Rhino command line.
        string command_string = "-_InterpCrv";
#endif
        // This is what reads the file
        // note "using System.IO;" above
        StreamReader reader = new StreamReader(filename);
        line = reader.ReadLine();

        // line == null attribute the end of the file
        while(line != null && line.Length > 0)
        {
#if CMD_LINE
          // Add each point to the commandline string
          command_string += " "+line;
#endif

#if !CMD_LINE
//          RhUtil.RhinoApp().Print(string.Format("string: {0}\n", line));
          string[] substrs = line.Split(delim);
          if(substrs.Length == 3)
          {
            On3dPoint p = new On3dPoint();
            p.x = double.Parse(substrs[0]);
            p.y = double.Parse(substrs[1]);
            p.z = double.Parse(substrs[2]);
            points.Append(p);
//            context.m_doc.AddPointObject(p);
//            RhUtil.RhinoApp().Print(string.Format("x,y,z = {0},{1},{2}\n", p.x, p.y, p.z));
          }
#endif
          line = reader.ReadLine();
        }
#if !CMD_LINE
        // This would define start and end directions for the curve if they
        // were used in RhinoInterpCurve instead of null, null
        // On3dVector start_tan = new On3dVector();
        // start_tan = points[1] - points[0];
        // start_tan.Unitize();
        // int j = points.Count();
        // On3dVector end_tan = new On3dVector();
        // end_tan = points[j - 1] - points[j - 2];
        // end_tan.Unitize();

        OnNurbsCurve curve = RhUtil.RhinoInterpCurve(3, points, null, null, 1);
        context.m_doc.AddCurveObject(curve);
#endif
        reader.Close();

#if CMD_LINE
        command_string += " enter";
        RhUtil.RhinoApp().RunScript(command_string);
#endif
      }

      context.m_doc.Regen();
      return IRhinoCommand.result.success;
    }
  }
}

