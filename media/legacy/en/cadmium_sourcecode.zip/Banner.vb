Public Class Banner
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblFurtherInfo As System.Windows.Forms.Label
    Friend WithEvents linkReconstructivism As System.Windows.Forms.LinkLabel
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Banner))
        Me.lblFurtherInfo = New System.Windows.Forms.Label
        Me.linkReconstructivism = New System.Windows.Forms.LinkLabel
        Me.SuspendLayout()
        '
        'lblFurtherInfo
        '
        Me.lblFurtherInfo.BackColor = System.Drawing.Color.Transparent
        Me.lblFurtherInfo.Location = New System.Drawing.Point(152, 32)
        Me.lblFurtherInfo.Name = "lblFurtherInfo"
        Me.lblFurtherInfo.Size = New System.Drawing.Size(240, 96)
        Me.lblFurtherInfo.TabIndex = 0
        Me.lblFurtherInfo.Text = "..."
        '
        'linkReconstructivism
        '
        Me.linkReconstructivism.ActiveLinkColor = System.Drawing.Color.Transparent
        Me.linkReconstructivism.BackColor = System.Drawing.Color.Transparent
        Me.linkReconstructivism.Cursor = System.Windows.Forms.Cursors.Hand
        Me.linkReconstructivism.DisabledLinkColor = System.Drawing.Color.Transparent
        Me.linkReconstructivism.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.linkReconstructivism.ForeColor = System.Drawing.Color.Transparent
        Me.linkReconstructivism.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.linkReconstructivism.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.linkReconstructivism.LinkColor = System.Drawing.Color.Transparent
        Me.linkReconstructivism.Location = New System.Drawing.Point(0, 134)
        Me.linkReconstructivism.Name = "linkReconstructivism"
        Me.linkReconstructivism.Size = New System.Drawing.Size(400, 16)
        Me.linkReconstructivism.TabIndex = 1
        Me.linkReconstructivism.TabStop = True
        Me.linkReconstructivism.Text = "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii"
        Me.linkReconstructivism.TextAlign = System.Drawing.ContentAlignment.BottomRight
        Me.linkReconstructivism.VisitedLinkColor = System.Drawing.Color.Transparent
        '
        'Banner
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(400, 150)
        Me.ControlBox = False
        Me.Controls.Add(Me.linkReconstructivism)
        Me.Controls.Add(Me.lblFurtherInfo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.Name = "Banner"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Banner_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblFurtherInfo.Text = ".NET plugin for Rhinoceros3D version 3.x" & vbCrLf & _
                              "Plugin version: " & Definitions.PluginVersion & vbCrLf & vbCrLf & _
                              "This plugin provides tools to import and edit molecular data."
        lblFurtherInfo.BackColor = System.Drawing.Color.FromArgb(100, 255, 255, 255)
    End Sub

    Private Sub Banner_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Click
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub linkReconstructivism_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles linkReconstructivism.LinkClicked
        System.Diagnostics.Process.Start("http://www.reconstructivm.net")
    End Sub

    Private Sub lblFurtherInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblFurtherInfo.Click
        Me.Close()
        Me.Dispose()
    End Sub
End Class
