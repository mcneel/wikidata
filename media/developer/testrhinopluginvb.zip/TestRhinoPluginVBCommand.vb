Imports System
Imports Rhino

<System.Runtime.InteropServices.Guid("e0206ce8-7162-4ac6-9229-eda9c61c44a1")> _
Public Class TestRhinoPluginVBCommand
  Inherits Rhino.Commands.Command

  '''<summary>
  ''' The one and only TestRhinoPluginVBCommand object
  '''</summary>
  Private Shared m_thecommand As TestRhinoPluginVBCommand

  '''<summary>
  ''' Returns the one and only instance of this command
  '''</summary>
  Public Shared ReadOnly Property TheCommand() As TestRhinoPluginVBCommand
    Get
      Return m_thecommand
    End Get
  End Property

  '''<summary>
  ''' Public constructor
  '''</summary>
  Public Sub New()
    ' Rhino only creates one instance of each defined public command class
    ' so it is safe to hold on to a static reference.
    m_thecommand = Me
  End Sub

  '''<summary>
  ''' Command name as it appears on the Rhino command line
  '''</summary>
  Public Overrides ReadOnly Property EnglishName() As String
    Get
      Return "TestRhinoPluginVB"
    End Get
  End Property

  '''<summary>
  ''' The command entry point
  '''</summary>
  Protected Overrides Function RunCommand(ByVal doc As RhinoDoc, ByVal mode As Rhino.Commands.RunMode) As Rhino.Commands.Result
    RhinoApp.WriteLine("The {0} command is under construction", EnglishName)
    Return Rhino.Commands.Result.Success
  End Function
End Class
