/////////////////////////////////////////////////////////////////////////////
// cmdTabbedDockbarDemo.cpp : command file
//

#include "StdAfx.h"
#include "TabbedDockbarDemoPlugIn.h"

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//
// BEGIN TabbedDockbarDemo command
//

#pragma region TabbedDockbarDemo command

class CCommandTabbedDockbarDemo : public CRhinoCommand
{
public:
	CCommandTabbedDockbarDemo() {}
  ~CCommandTabbedDockbarDemo() {}
	UUID CommandUUID()
	{
		// {E3BF0649-E710-4CB3-B241-47174191128F}
    static const GUID TabbedDockbarDemoCommand_UUID =
    { 0xE3BF0649, 0xE710, 0x4CB3, { 0xB2, 0x41, 0x47, 0x17, 0x41, 0x91, 0x12, 0x8F } };
    return TabbedDockbarDemoCommand_UUID;
	}
	const wchar_t* EnglishCommandName() { return L"TabbedDockbarDemo"; }
	const wchar_t* LocalCommandName() { return L"TabbedDockbarDemo"; }
	CRhinoCommand::result RunCommand( const CRhinoCommandContext& );
};
static class CCommandTabbedDockbarDemo theTabbedDockbarDemoCommand;

CRhinoCommand::result CCommandTabbedDockbarDemo::RunCommand( const CRhinoCommandContext& context )
{
  ON_wString wStr;
  wStr.Format( L"The \"%s\" command is under construction.\n", EnglishCommandName() );
  if( context.IsInteractive() )
    RhinoMessageBox( wStr, PlugIn()->PlugInName(), MB_OK );
  else
	  RhinoApp().Print( wStr );
  return CRhinoCommand::success;
}

#pragma endregion

//
// END TabbedDockbarDemo command
//
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
