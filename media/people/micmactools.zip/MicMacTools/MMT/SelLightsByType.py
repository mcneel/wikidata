import rhinoscriptsyntax as rs
import scriptcontext as sc

def GetLightType(lightID):
    light=sc.doc.Objects.Find(lightID).Geometry
    if light.IsLinearLight: return 0
    elif light.IsPointLight: return 1
    elif light.IsRectangularLight: return 2
    elif light.IsDirectionalLight: return 3
    elif light.IsSpotLight: return 4
    else: return -1
    
def SelLightsByType():
    lights=rs.ObjectsByType(256)
    if not lights:
        print "No lights found in document" ; return
    light_list=['Linear','Point','Rectangular','Directional','Spot']
    msg="Light type to select?"
    title="Light type selection"
    light_type=rs.ListBox(light_list,msg,title,4)
    if not light_type: return
    index=light_list.index(light_type)
    
    n=0
    rs.EnableRedraw(False)
    for light in lights:
        if rs.IsObjectSelectable(light):
            if GetLightType(light)==index:
                rs.SelectObject(light)
                n+=1
    if n>0:
        if n==1: s=""
        else: s="s"
        print "{} {} light{} selected".format(n,light_list[index],s)
    else:
        print "No {} lights found in file".format(light_list[index])
SelLightsByType()