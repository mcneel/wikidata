Imports System.Windows.Forms

Public Class Analysis
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents datTree As System.Windows.Forms.TreeView
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnOK = New System.Windows.Forms.Button
        Me.datTree = New System.Windows.Forms.TreeView
        Me.SuspendLayout()
        '
        'btnOK
        '
        Me.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.btnOK.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnOK.Location = New System.Drawing.Point(0, 376)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(272, 24)
        Me.btnOK.TabIndex = 1
        Me.btnOK.Text = "Close"
        '
        'datTree
        '
        Me.datTree.BackColor = System.Drawing.SystemColors.Control
        Me.datTree.Dock = System.Windows.Forms.DockStyle.Fill
        Me.datTree.HotTracking = True
        Me.datTree.ImageIndex = -1
        Me.datTree.Location = New System.Drawing.Point(0, 0)
        Me.datTree.Name = "datTree"
        Me.datTree.SelectedImageIndex = -1
        Me.datTree.Size = New System.Drawing.Size(272, 376)
        Me.datTree.TabIndex = 2
        '
        'Analysis
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(272, 400)
        Me.Controls.Add(Me.datTree)
        Me.Controls.Add(Me.btnOK)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Analysis"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Molecule info"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public mol_Pointer As Molecule

    Public Sub LoadMolecularData()
        Dim a As Int32
        Dim iTotalAtomCount As Int32
        Dim iPerElementCount(109) As Int32

        For a = 0 To mol_Pointer.AtomUpperBound
            iTotalAtomCount += 1
            iPerElementCount(System.Math.Max(mol_Pointer.Atoms(a).ElementType, 0)) += 1
        Next

        Dim StructureRoot As New TreeNode("Structure")
        Dim AtomRoot As New TreeNode("Atoms")
        Dim ChainRoot As New TreeNode("Chains")
        Dim ResidueRoot As New TreeNode("Residues")

        StructureRoot.Expand()
        AtomRoot.Expand()
        ChainRoot.Expand()
        ResidueRoot.Expand()

        datTree.Nodes.Add(StructureRoot)
        datTree.Nodes.Add(AtomRoot)
        datTree.Nodes.Add(ChainRoot)
        datTree.Nodes.Add(ResidueRoot)

        Dim iTopNode As TreeNode
        Dim iBottomNode As TreeNode

        '---------------------------------------------------------------------------------------
        iTopNode = New TreeNode(String.Format("The molecule contains {0} structures", _
                                              mol_Pointer.set_Molecules.libRecord.Count))
        StructureRoot.Nodes.Add(iTopNode)
        For a = 1 To mol_Pointer.set_Molecules.libRecord.Count
            iBottomNode = New TreeNode(String.Format("Structure ID: {0}", _
                                       mol_Pointer.set_Molecules.libRecord.Item(a)))
            iTopNode.Nodes.Add(iBottomNode)
        Next

        '---------------------------------------------------------------------------------------
        Dim iHeaders As Collection = mol_Pointer.ReadSpecificRecordField("HEADER")
        If iHeaders.Count > 0 Then
            iTopNode = New TreeNode(String.Format("The molecule contains {0} headers", iHeaders.Count))
            StructureRoot.Nodes.Add(iTopNode)
            For a = 1 To iHeaders.Count
                iBottomNode = New TreeNode(Decoder.StripDuplicateSpaces(iHeaders.Item(a)))
                iTopNode.Nodes.Add(iBottomNode)
            Next
        End If

        '---------------------------------------------------------------------------------------
        Dim iKeywordLines As Collection = mol_Pointer.ReadSpecificRecordField("KEYWDS")
        If iKeywordLines.Count > 0 Then
            Dim iSingleLine As String()
            Dim iKeyWords As New Collection
            Dim i As Int32

            For a = 1 To iKeywordLines.Count
                iSingleLine = Split(Mid(iKeywordLines.Item(a), 5), ",")
                For i = 0 To iSingleLine.GetUpperBound(0)
                    iKeyWords.Add(Trim(iSingleLine(i)))
                Next
            Next

            iTopNode = New TreeNode(String.Format("The molecule contains {0} keywords", iKeyWords.Count))
            StructureRoot.Nodes.Add(iTopNode)
            For a = 1 To iKeyWords.Count
                iBottomNode = New TreeNode(iKeyWords.Item(a))
                iTopNode.Nodes.Add(iBottomNode)
            Next
        End If

        '---------------------------------------------------------------------------------------
        iTopNode = New TreeNode(String.Format("The molecule contains {0} atoms", iTotalAtomCount))
        AtomRoot.Nodes.Add(iTopNode)
        For a = 0 To UBound(iPerElementCount)
            If iPerElementCount(a) > 0 Then
                iBottomNode = New TreeNode(String.Format("{0} ({1})", _
                                           Definitions.ToElementName(a, True), iPerElementCount(a)))
                iTopNode.Nodes.Add(iBottomNode)
            End If
        Next

        '---------------------------------------------------------------------------------------
        iTopNode = New TreeNode(String.Format("The molecule contains {0} chains", _
                                              mol_Pointer.set_Chains.libRecord.Count))
        ChainRoot.Nodes.Add(iTopNode)
        For a = 1 To mol_Pointer.set_Chains.libRecord.Count
            iBottomNode = New TreeNode(mol_Pointer.set_Chains.libRecord.Item(a))
            iTopNode.Nodes.Add(iBottomNode)
        Next

        '---------------------------------------------------------------------------------------
        iTopNode = New TreeNode(String.Format("The molecule contains {0} residues", _
                                              mol_Pointer.set_Residues.libRecord.Count))
        ResidueRoot.Nodes.Add(iTopNode)
        For a = 1 To mol_Pointer.set_Residues.libRecord.Count
            iBottomNode = New TreeNode(String.Format("{0}   ({1})", _
                                        mol_Pointer.set_Residues.libRecord.Item(a), _
                                        Definitions.ToFullResidueName(mol_Pointer.set_Residues.libRecord.Item(a))))
            iTopNode.Nodes.Add(iBottomNode)
        Next
    End Sub
End Class
