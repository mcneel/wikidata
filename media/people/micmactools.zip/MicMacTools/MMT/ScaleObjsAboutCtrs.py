import rhinoscriptsyntax as rs
import scriptcontext
"""
Scales objects about their "centers" - center point will be:
Closed mesh, surface and polysurface objects : Volume centroid
Open mesh, surface/polysurface objects, closed planar curves : Area centroid
All other objects : object world bounding box center
"""

def FindObjectCenter(obj):
    #finds object center point - returns point if found, otherwise None
    ctrPt=[]
    if rs.IsMesh(obj):
        if rs.IsMeshClosed(obj):
            ctrPt=rs.MeshVolumeCentroid(obj)
        else:
            ctrPt=rs.MeshAreaCentroid(obj)
    elif rs.IsCurve(obj) and rs.IsCurvePlanar(obj) and rs.IsCurveClosed(obj):
        ctrPt=rs.CurveAreaCentroid(obj)[0]
    elif rs.IsSurface(obj) or rs.IsPolysurface(obj):
        if rs.IsObjectSolid(obj):
            ctrPt=rs.SurfaceVolumeCentroid(obj)[0]
        else:
            ctrPt=rs.SurfaceAreaCentroid(obj)[0]
    if not ctrPt:
        bb=rs.BoundingBox(obj)
        if bb: ctrPt=(bb[0]+bb[6])/2
    return ctrPt

def ScaleObjsAboutCtrs():
    
    if scriptcontext.sticky.has_key("ScaleFactor"):
        osf=scriptcontext.sticky["ScaleFactor"]
    else: osf=1.0
    
    msg1="Select objects to scale about centers"
    dblTol=rs.UnitAbsoluteTolerance
    arrObjs=rs.GetObjects(msg1,preselect=True)
    if not arrObjs: return
    
    sc=rs.GetReal("Scale factor for objects?",osf)
    if not sc: return
    if sc==0 :
        print "Scale must be nonzero"
        return
    scriptcontext.sticky["ScaleFactor"] = sc
    
    n=0
    rs.EnableRedraw(False)
    for i in range (len(arrObjs)):
        cp=FindObjectCenter(arrObjs[i])
        if cp: 
            rs.ScaleObject(arrObjs[i],cp,[sc,sc,sc],False) 
        else: n+=1
    if n>0:
        print "Scaled "+str(i-n)+" objects || Unable to scale "+str(n)+" objects"
    else:
        print "Scaled "+str(len(arrObjs))+" objects"
        
if __name__=="__main__" :
    ScaleObjsAboutCtrs()