import rhinoscriptsyntax as rs
#rs.GetLinetype() not yet implemented in Python rhinoscriptsyntax
#rs.MultiListBox() idem. So currently limited to one linetype per operation.

def SelCrvsByLinetype():
    ltList=rs.LinetypeNames(True)
    lt=rs.ListBox(ltList,"Select linetype")
    if not lt: return
    objs = rs.ObjectsByType(4)
    if not objs: return
    
    rs.EnableRedraw(False)
    n = 0
    for obj in objs:
        if rs.IsObjectSelectable(obj):
            if rs.ObjectLinetypeSource(obj) == 1:
                objLT = rs.ObjectLinetype(obj)
            elif rs.ObjectLinetypeSource(obj) == 0:
                objLT = rs.LayerLinetype(rs.ObjectLayer(obj))
                
        if objLT.lower() == lt.lower():
            rs.SelectObject(obj)
            n += 1
    if n>0:
        if n==1: s=""
        else: s="s"
        print "Selected {} curve{} with the chosen linetype".format(n,s)
    else: print "No curves of this linetype found"

SelCrvsByLinetype()