Imports RMA.Rhino
Imports RMA.OpenNURBS
Imports RMA.Rhino.RhUtil

Public Class DivideCurveStraightCommand
  Inherits RMA.Rhino.MRhinoCommand

  Public Overrides Function CommandUUID() As System.Guid
    Return New Guid("{b8e62b56-92fd-4e0c-ad25-5e74ef4e6afd}")
  End Function

  Public Overrides Function EnglishCommandName() As String
    Return "DivideCurveStraight"
  End Function

  Public Overrides Function RunCommand(ByVal context As RMA.Rhino.IRhinoCommandContext) As RMA.Rhino.IRhinoCommand.result
    Dim cget As New MRhinoGetObject
    cget.SetCommandPrompt("Curves to divide")
    cget.SetGeometryFilter(IRhinoGetObject.GEOMETRY_TYPE_FILTER.curve_object Or IRhinoGetObject.GEOMETRY_TYPE_FILTER.edge_object)

    Dim crvs As New List(Of IOnCurve)

    Select Case cget.GetObjects(1, 0)
      Case IRhinoGet.result.object
        For i As Int32 = 0 To cget.ObjectCount() - 1
          crvs.Add(cget.Object(i).Curve)
        Next

      Case Else
        Return IRhinoCommand.result.cancel
    End Select

    Dim dist As Double = 1.0
    Select Case RhUtil.RhinoGetNumber("Distance between divisions", False, False, dist, 0.001)
      Case IRhinoCommand.result.success
        'ok
      Case Else
        Return IRhinoCommand.result.cancel
    End Select

    For Each crv As IOnCurve In crvs
      Dim nDiv As New CurveDivider(crv)
      Dim divpt As List(Of DivisionPoint) = nDiv.Divide(dist)

      If (divpt IsNot Nothing) Then
        For Each pt As DivisionPoint In divpt
          context.m_doc.AddPointObject(pt.m_p)
        Next
      End If
    Next

    context.m_doc.Regen()

    Return IRhinoCommand.result.success
  End Function
End Class