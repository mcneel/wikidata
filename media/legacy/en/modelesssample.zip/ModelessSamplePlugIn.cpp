/////////////////////////////////////////////////////////////////////////////
// ModelessSamplePlugIn.cpp : defines the initialization routines for the plug-in.

#include "StdAfx.h"
#include "ModelessSampleApp.h"
#include "ModelessSamplePlugIn.h"

// The plug-in object must be constructed before any plug-in classes
// derived from CRhinoCommand. The #pragma init_seg(lib) ensures that
// this happens.

#pragma warning( push )
#pragma warning( disable : 4073 )
#pragma init_seg( lib )
#pragma warning( pop )

// Rhino plug-in declaration
RHINO_PLUG_IN_DECLARE

// Rhino plug-in developer declarations
// TODO: fill in the following developer declarations 
// with your company information. When completed,
// delete the following #error directive.
//#error Developer declarations block is incomplete!
RHINO_PLUG_IN_DEVELOPER_ORGANIZATION( L"My Company Name" );
RHINO_PLUG_IN_DEVELOPER_ADDRESS( L"123 Developer Street\r\nCity State 12345-6789" );
RHINO_PLUG_IN_DEVELOPER_COUNTRY( L"My Country" );
RHINO_PLUG_IN_DEVELOPER_PHONE( L"123.456.7890" );
RHINO_PLUG_IN_DEVELOPER_FAX( L"123.456.7891" );
RHINO_PLUG_IN_DEVELOPER_EMAIL( L"support@mycompany.com" );
RHINO_PLUG_IN_DEVELOPER_WEBSITE( L"http://www.mycompany.com" );
RHINO_PLUG_IN_UPDATE_URL( L"http://www.mycompany.com/support" );

// The one and only CModelessSamplePlugIn object
static CModelessSamplePlugIn thePlugIn;

/////////////////////////////////////////////////////////////////////////////
// CModelessSamplePlugIn definition

CModelessSamplePlugIn& ModelessSamplePlugIn()
{ 
  // Return a reference to the one and only CModelessSamplePlugIn object
  return thePlugIn; 
}

CModelessSamplePlugIn::CModelessSamplePlugIn()
: m_dialog(0)
{
  m_plugin_version = __DATE__"  "__TIME__;
}

CModelessSamplePlugIn::~CModelessSamplePlugIn()
{
}

/////////////////////////////////////////////////////////////////////////////
// Required overrides

const wchar_t* CModelessSamplePlugIn::PlugInName() const
{
  return L"ModelessSample";
}

const wchar_t* CModelessSamplePlugIn::PlugInVersion() const
{
  return m_plugin_version;
}

GUID CModelessSamplePlugIn::PlugInID() const
{
  // {7308377F-1219-4F3B-8112-78340D26F513}
  static const GUID ModelessSamplePlugIn_UUID =
  { 0x7308377F, 0x1219, 0x4F3B, { 0x81, 0x12, 0x78, 0x34, 0xD, 0x26, 0xF5, 0x13 } };
  return ModelessSamplePlugIn_UUID;
}

BOOL CModelessSamplePlugIn::OnLoadPlugIn()
{
  return CRhinoUtilityPlugIn::OnLoadPlugIn();
}

void CModelessSamplePlugIn::OnSaveAllSettings()
{
  DestroyDlg();
}

void CModelessSamplePlugIn::OnUnloadPlugIn()
{
  CRhinoUtilityPlugIn::OnUnloadPlugIn();
}

/////////////////////////////////////////////////////////////////////////////
// Online help overrides

BOOL CModelessSamplePlugIn::AddToPlugInHelpMenu() const
{
  return FALSE;
}

BOOL CModelessSamplePlugIn::OnDisplayPlugInHelp( HWND hWnd ) const
{
  return CRhinoUtilityPlugIn::OnDisplayPlugInHelp( hWnd );
}

bool CModelessSamplePlugIn::IsDlgCreated()
{
  bool rc = false;
  if( m_dialog && ::IsWindow(m_dialog->m_hWnd) )
    rc = true;
  return rc;
}

bool CModelessSamplePlugIn::IsDlgVisible()
{
  bool rc = false;
  if( IsDlgCreated() && m_dialog->IsWindowVisible() )
    rc = true;
  return rc;

}

bool CModelessSamplePlugIn::SetDlgVisible()
{
  bool rc = false;
  if( IsDlgCreated() && !IsDlgVisible() )
  {
    m_dialog->ShowWindow( SW_SHOWNORMAL );
    m_dialog->SetFocus();
    rc = true;
  }
  return rc;
}

bool CModelessSamplePlugIn::SetDlgHidden()
{
  bool rc = false;
  if( IsDlgCreated() && IsDlgVisible() )
  {
    m_dialog->ShowWindow( SW_HIDE );
    ::SetFocus( RhinoApp().MainWnd() );
    rc = true;
  }
  return rc;
}

bool CModelessSamplePlugIn::DisplayDlg()
{
	AFX_MANAGE_STATE( AfxGetStaticModuleState() );

  if( IsDlgCreated() )
  {
    if( !IsDlgVisible() )
      SetDlgVisible();
    m_dialog->SetFocus();
    return true;
  }

  m_dialog = new CModelessSampleDialog( CWnd::FromHandle(RhinoApp().MainWnd()) );
	if( m_dialog->Create(IDD_DIALOG1, CWnd::FromHandle(RhinoApp().MainWnd())) )
	{
		m_dialog->ShowWindow( SW_SHOW );
		m_dialog->UpdateWindow();
    m_dialog->SetFocus();
		return true;
	}

	return false;
}

void CModelessSamplePlugIn::DestroyDlg()
{
  if( IsDlgCreated() )
  {
    m_dialog->KillDialog();
    m_dialog = 0;
  }
}

void CModelessSamplePlugIn::ZeroDlg()
{
  m_dialog = 0;
}

void CModelessSamplePlugIn::SetDlgPointValue( int item, const ON_3dPoint& pt )
{
  if( IsDlgVisible() )
    m_dialog->SetPointValue( item, pt );
}


