"""Exports one DXF file per layer, export folder is same as current
folder if file has been saved; otherwise, choice of file name/location.
Will use the last used export scheme as the list of available export schemes
is not currently user-accessible.  Script by Mitch Heynick 08.09.15"""

import rhinoscriptsyntax as rs
import scriptcontext as sc
import os

def BatchExportDXFByObject():
    doc_name=sc.doc.Name
    ft="DXF"
    filt = "{} Files (*.{})|*.{}||".format(ft,ft.lower(),ft.lower())
    if not doc_name:
        #document hasn't been saved
        msg="Main file name/folder for {} export?".format(ft)
        filename=rs.SaveFileName(msg, filt)
        #SaveFileName returns the complete path plus file name
        if filename==None: return
    else:
        #document has been saved, get path
        msg="Folder for {} export? (Enter to save in current folder)".format(ft)
        folder = rs.BrowseForFolder(rs.WorkingFolder(), msg)
        if not folder: return
        filename=os.path.join(folder,doc_name)
    
    #start the export sequence
    rs.EnableRedraw(False)
    layers=rs.LayerNames()
    for layer in layers:
        if rs.IsLayerSelectable(layer):
            #need to check for sublayers in name and replace "::"
            layer_name=layer.replace("::","_")
            e_file_name = '"{}-{}.{}" '.format(filename[:-4],layer_name,ft.lower())
            rs.UnselectAllObjects()
            rs.ObjectsByLayer(layer, True)
            if rs.SelectedObjects():
                #runs the export using the file name/path and your settings
                rs.Command("-_Export "+e_file_name+" _Enter", False)
        
    rs.EnableRedraw(True)

BatchExportDXFByObject()