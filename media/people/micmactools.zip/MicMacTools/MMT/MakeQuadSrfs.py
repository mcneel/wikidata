"""Makes untrimmed quad surfaces from either 4 sided polylines or
trimmed four linear sided surfaces.  Leaves untrimmed surfaces alone.  
Deletes original surfaces if replacement is possible, polylines are not deleted.
Script by Mitch Heynick 02.07.15
Revised 01.09.15, fixed polyline bug, added normal check for surface conversion"""

import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def four_s_filt(rhino_object, geometry, component_index):
    if rs.IsSurface(rhino_object.Id):
        if geometry.Edges.Count==4: return True
    else:
        a=rs.IsCurveClosed(rhino_object.Id)
        b=rs.CurveDegree(rhino_object.Id)==1
        c=rs.CurvePointCount(rhino_object.Id)==5
        if a and b and c: return True
    return False
    
def GetPlanarBrepNormal(brep,tol):
    if brep.Faces.Count == 1:
        plane=brep.Faces[0].TryGetPlane(tol)
        if plane:
            return plane[1].Normal

def MakeQuadSrfs():
    msg="Select closed quad polycurves to surface"
    objs=rs.GetObjects(msg,4+8,preselect=True,custom_filter=four_s_filt)
    if not objs: return
    rs.EnableRedraw(False)
    tol=sc.doc.ModelAbsoluteTolerance
    aTol=Rhino.RhinoMath.DefaultAngleTolerance
    for obj in objs:
        if rs.IsCurve(obj):
            pts=rs.CurvePoints(obj)
            pts[-1]=tol
            brep=Rhino.Geometry.Brep.CreateFromCornerPoints(*pts)
            if brep:
                new_srf_id=sc.doc.Objects.AddBrep(brep)
                if new_srf_id: rs.MatchObjectAttributes(new_srf_id,obj)
        else:
            if rs.IsSurfaceTrimmed(obj):
                brep=sc.doc.Objects.Find(obj).Geometry
                edges=brep.Edges
                prev_norm_vec=GetPlanarBrepNormal(brep,tol)
                new_srf=Rhino.Geometry.Brep.CreateEdgeSurface(edges)
                new_norm_vec=GetPlanarBrepNormal(new_srf,tol)
                if prev_norm_vec and new_norm_vec:
                    if new_norm_vec.IsParallelTo(prev_norm_vec,aTol)==-1:
                        new_srf.Flip()
                new_srf_id=sc.doc.Objects.AddBrep(new_srf)
                if new_srf_id:
                    rs.MatchObjectAttributes(new_srf_id,obj)
                    rs.DeleteObject(obj)
    sc.doc.Views.Redraw

MakeQuadSrfs()