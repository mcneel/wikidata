import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def SpheresToPoints():
    tol=rs.UnitAbsoluteTolerance()
    if "SPHTP_Rad" in sc.sticky: user_rad = sc.sticky["SPHTP_Rad"]
    else: user_rad = 1.0
    msg="Select points to apply spheres - orientation plane will be active view"
    ptIDs=rs.GetObjects(msg,1,preselect=True)
    if not ptIDs: return
    plane=rs.ViewCPlane()
    rad=rs.GetReal("Sphere radius",user_rad,tol)
    if not rad: return
    
    rs.EnableRedraw(False)
    pts=rs.coerce3dpointlist(ptIDs)
    copies=[]
    for pt in pts:
        plane.Origin=pt
        #bug in rhinoscriptsyntax makes the following necessary
        sphere=Rhino.Geometry.Sphere(plane,rad)
        copies.append(sc.doc.Objects.AddSphere(sphere))
    rs.SelectObjects(copies)
    sc.doc.Views.Redraw()
    sc.sticky["SPHTP_Rad"] = rad
SpheresToPoints()