Imports RMA.Rhino

Public Class DivideCurveStraightPlugIn
  Inherits RMA.Rhino.MRhinoUtilityPlugIn

  Public Overrides Function PlugInID() As System.Guid
    Return New System.Guid("{6343dc8e-bb17-4ccf-9a55-0aac14e44025}")
  End Function

  Public Overrides Function PlugInName() As String
    Return "DivideCurveStraight"
  End Function

  Public Overrides Function PlugInVersion() As String
    Return "1.0.0.0"
  End Function

  Public Overrides Function OnLoadPlugIn() As Integer
    Return 1
  End Function

  Public Overrides Sub OnUnloadPlugIn()
    ' TODO: Add plug-in cleanup code here.
  End Sub
End Class