import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino, System

def GetObjectEscCancel(prompt,filt=None):
    #prompt==command line prompt
    go = Rhino.Input.Custom.GetObject()
    go.SetCommandPrompt(prompt)
    if filt:
        go.GeometryFilter=filt
        #can add subfilter if desired
        #go.SetCustomGeometryFilter(None)
    go.AcceptNothing(True)
    value=None
    
    get_rc = go.Get()
    if get_rc==Rhino.Input.GetResult.Cancel: value=False
    elif get_rc==Rhino.Input.GetResult.Nothing: value=True
    elif get_rc==Rhino.Input.GetResult.Object:
        value=go.Object(0)
    else: value=False
    return value
    
def GetObjPrintColor(objID):
    if rs.ObjectPrintColorSource(objID) == 1:
        obj_pc = rs.ObjectPrintColor(objID)
    elif rs.ObjectPrintColorSource(objID) == 0:
        obj_pc = rs.LayerPrintColor(rs.ObjectLayer(objID))
    return obj_pc
    
def CompareColors(color_a,color_b):
    col_a=rs.coercecolor(color_a)
    col_b=rs.coercecolor(color_b)
    if col_a and col_b:
        if col_a.R==col_b.R:
            if col_a.G==col_b.G:
                if col_a.B==col_b.B:
                    return True
    return False

def SelObjsByPrintColor():
    objs=rs.NormalObjects()
    if not objs: return
    on_mac=Rhino.Runtime.HostUtils.RunningOnOSX
    if on_mac: msg1="Pick object to match print color"
    else: msg1="Pick object to match or Enter to choose color"
    
    result=GetObjectEscCancel(msg1)
    if not result: return
    if isinstance(result,Rhino.DocObjects.ObjRef):
        color=GetObjPrintColor(result)
    else:
        if not on_mac:
            color=rs.GetColor() #Not working on Mac Rhino V5.0
            if not color: return
        else: return
        
    rs.EnableRedraw(False)
    n = 0
    for obj in objs:
        obj_col=GetObjPrintColor(obj)
        if CompareColors(obj_col,color):
            rs.SelectObject(obj)
            n+=1
    if n >0: 
        if n==1: s=""
        else: s="s"
        print "Selected {} curve{} with chosen print color".format(n,s)
    else: print "No curves with chosen print color found"

SelObjsByPrintColor()