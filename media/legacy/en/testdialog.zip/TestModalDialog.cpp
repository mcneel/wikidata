#include "StdAfx.h"
#include "TestDialog.h"
#include "TestModalDialog.h"

CTestModalDialog::CTestModalDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CTestModalDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestModalDialog)
	//}}AFX_DATA_INIT
}

void CTestModalDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestModalDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestModalDialog, CDialog)
	//{{AFX_MSG_MAP(CTestModalDialog)
	ON_BN_CLICKED(IDC_BUTTON1, OnAddLine)
	ON_BN_CLICKED(IDC_BUTTON2, OnAddCircle)
	ON_BN_CLICKED(IDC_BUTTON3, OnAddPoints)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CTestModalDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	return TRUE;
}

void CTestModalDialog::OnAddLine() 
{
  CRhinoDoc* doc = ::RhinoApp().ActiveDoc();
  if( doc )
  {
    ON_Line line( ON_3dPoint(10,10,0), ON_3dPoint(20,20,0) );
    doc->AddCurveObject( line );
    doc->Redraw();
  }
}

void CTestModalDialog::OnAddCircle() 
{
  CRhinoDoc* doc = ::RhinoApp().ActiveDoc();
  if( doc )
  {
    ON_Circle circle( ON_3dPoint(15,15,0), 10.0 );
    doc->AddCurveObject( circle );
    doc->Redraw();
  }
}

void CTestModalDialog::OnAddPoints() 
{
  CRhinoDoc* doc = ::RhinoApp().ActiveDoc();
  if( doc )
  {
    doc->AddPointObject( ON_3dPoint(5,5,0) );
    doc->AddPointObject( ON_3dPoint(15,5,0) );
    doc->AddPointObject( ON_3dPoint(15,15,0) );
    doc->AddPointObject( ON_3dPoint(5,15,0) );
    doc->Redraw();
  }
}
