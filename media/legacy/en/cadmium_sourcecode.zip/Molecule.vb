Public Class Molecule
    Public Atoms() As Atom
    Public Bonds() As Bond
    Public BBox_Cache As Boolean = False

    Public set_Molecules As New RecordSet
    Public set_Chains As New RecordSet
    Public set_Residues As New RecordSet

    Public Original_Atom_Count As Int32 = -1
    Public Shadow_PDB_File As String

    Public Function AtomUpperBound() As Int32
        Dim i As Integer = -1
        Try
            i = Atoms.GetUpperBound(0)
        Catch ex As Exception
            i = -1
        End Try
        Return i
    End Function

    Public Function BondUpperBound() As Int32
        Dim i As Integer = -1
        Try
            i = Bonds.GetUpperBound(0)
        Catch ex As Exception
            i = -1
        End Try
        Return i
    End Function

    Public Sub AddAtom(ByVal nAtom As Atom)
        ReDim Preserve Atoms(AtomUpperBound() + 1)
        Atoms(AtomUpperBound) = nAtom
    End Sub

    Public Sub AddBond(ByVal nBond As Bond)
        ReDim Preserve Bonds(BondUpperBound() + 1)
        Bonds(BondUpperBound) = nBond
    End Sub

    Public Sub CullAtom(ByVal sIndex As Int32)
        If AtomUpperBound() <= 0 Then
            Erase Atoms
            Return
        End If

        Dim i As Int32
        If sIndex < AtomUpperBound() Then
            For i = sIndex To AtomUpperBound() - 1
                Atoms(i) = Atoms(i + 1)
            Next
        End If
        ReDim Preserve Atoms(AtomUpperBound() - 1)
    End Sub

    Public Sub CullBond(ByVal sIndex As Int32)
        If BondUpperBound() <= 0 Then
            Erase Bonds
            Return
        End If

        Dim i As Int32
        If sIndex < BondUpperBound() Then
            For i = sIndex To BondUpperBound() - 1
                Bonds(i) = Bonds(i + 1)
            Next
        End If
        ReDim Preserve Bonds(BondUpperBound() - 1)
    End Sub

    Public Sub CullEmptySlots(Optional ByVal CullAtomList As Boolean = True)
        If CullAtomList Then
            If AtomUpperBound() < 0 Then Exit Sub
            Dim i, j As Int32
            j = -1
            For i = 0 To AtomUpperBound()
                If Not (Atoms(i) Is Nothing) Then
                    j += 1
                    Atoms(j) = Atoms(i)
                End If
            Next
            If j < 0 Then
                Erase Atoms
                Return
            End If
            ReDim Preserve Atoms(j)
        Else
            If BondUpperBound() < 0 Then Exit Sub
            Dim i, j As Int32
            j = -1
            For i = 0 To BondUpperBound()
                If Not (Bonds(i) Is Nothing) Then
                    j += 1
                    Bonds(j) = Bonds(i)
                End If
            Next
            If j < 0 Then
                Erase Bonds
                Return
            End If
            ReDim Preserve Bonds(j)
        End If
    End Sub

    Public Function BoundingBox() As RMA.OpenNURBS.OnBoundingBox
        Static iBoundingBox As New RMA.OpenNURBS.OnBoundingBox
        If BBox_Cache Then Return iBoundingBox

        Dim i As Int32
        Dim xmin As Double = Atoms(0).x
        Dim xmax As Double = Atoms(0).x
        Dim ymin As Double = Atoms(0).y
        Dim ymax As Double = Atoms(0).y
        Dim zmin As Double = Atoms(0).z
        Dim zmax As Double = Atoms(0).z

        For i = 1 To AtomUpperBound()
            xmin = System.Math.Min(xmin, Atoms(i).x)
            xmax = System.Math.Max(xmax, Atoms(i).x)
            ymin = System.Math.Min(ymin, Atoms(i).y)
            ymax = System.Math.Max(ymax, Atoms(i).y)
            zmin = System.Math.Min(zmin, Atoms(i).z)
            zmax = System.Math.Max(zmax, Atoms(i).z)
        Next

        iBoundingBox = New RMA.OpenNURBS.OnBoundingBox(New RMA.OpenNURBS.On3dPoint(xmin, ymin, zmin), _
                                                       New RMA.OpenNURBS.On3dPoint(xmax, ymax, zmax))
        BBox_Cache = True
        Return iBoundingBox
    End Function

    Public Function Insert(ByVal pAttributes As GeometryAttributes) As RMA.Rhino.MRhinoObject()
        Dim iAtt As New RMA.Rhino.MRhinoObjectAttributes
        iAtt.Default()

        If pAttributes.o_Group Then
            Dim iGroup As Int32 = RMA.Rhino.RhUtil.RhinoApp.ActiveDoc.m_group_table.AddGroup(New RMA.OpenNURBS.OnGroup)
            iAtt.AddToGroup(iGroup)
        End If
        iAtt.SetColorSource(RMA.OpenNURBS.IOn.object_color_source.color_from_object)

        Dim arrObjs() As RMA.Rhino.MRhinoObject
        Dim i As Int32
        If pAttributes.a_AtomGeometry = AtomGeometry.PointSet Then
            ReDim arrObjs(0)
            Dim arrPts As New RMA.OpenNURBS.ArrayOn3dPoint
            For i = 0 To AtomUpperBound()
                arrPts.Append(Atoms(i).CastONPoint)
            Next
            arrObjs(0) = RMA.Rhino.RhUtil.RhinoApp.ActiveDoc.AddPointCloudObject(arrPts, iAtt)
        Else
            ReDim arrObjs(AtomUpperBound)
            Dim r_Argument As Object
            If pAttributes.a_AtomRadius = AtomRadius.Constant Then
                r_Argument = pAttributes.a_ConstRadius
            Else
                r_Argument = pAttributes.a_AtomRadius
            End If
            With RMA.Rhino.RhUtil.RhinoApp.ActiveDoc
                For i = 0 To AtomUpperBound()
                    iAtt.m_name = Atoms(i).Name
                    iAtt.m_color = Atoms(i).CastOnColor(pAttributes)
                    Select Case pAttributes.a_AtomGeometry
                        Case AtomGeometry.Point
                            arrObjs(i) = .AddPointObject(Atoms(i).CastONPoint, iAtt)
                        Case AtomGeometry.MeshBox
                            arrObjs(i) = .AddMeshObject(Atoms(i).CastOnMeshBox, iAtt)
                        Case AtomGeometry.LQ_MeshSphere
                            arrObjs(i) = .AddMeshObject(Atoms(i).CastOnMeshSphere(r_Argument, False), iAtt)
                        Case AtomGeometry.HQ_MeshSphere
                            arrObjs(i) = .AddMeshObject(Atoms(i).CastOnMeshSphere(r_Argument, True), iAtt)
                        Case AtomGeometry.NurbsSphere
                            arrObjs(i) = .AddSurfaceObject(Atoms(i).CastOnSurface, iAtt)
                    End Select
                Next
            End With
        End If

        If BondUpperBound() < 0 Then Return arrObjs

        iAtt.m_color = New RMA.OpenNURBS.OnColor(0, 0, 0)
        Select Case pAttributes.b_BondGeometry
            Case BondGeometry.Line
                For i = 0 To BondUpperBound()
                    iAtt.m_name = Bonds(i).CreateDefaultName(Atoms(Bonds(i).Father), _
                                                             Atoms(Bonds(i).Mother))
                    RMA.Rhino.RhUtil.RhinoApp.ActiveDoc.AddCurveObject( _
                        Bonds(i).CastOnLine(Atoms(Bonds(i).Father), _
                                            Atoms(Bonds(i).Mother)), iAtt)
                Next
            Case BondGeometry.NurbsPipe
                For i = 0 To BondUpperBound()
                    iAtt.m_name = Bonds(i).CreateDefaultName(Atoms(Bonds(i).Father), _
                                                             Atoms(Bonds(i).Mother))
                    RMA.Rhino.RhUtil.RhinoApp.ActiveDoc.AddSurfaceObject( _
                        Bonds(i).CastOnNurbs(Atoms(Bonds(i).Father), _
                                             Atoms(Bonds(i).Mother), _
                                             pAttributes.b_PipeRadius), iAtt)
                Next
            Case BondGeometry.MeshPipe
                For i = 0 To BondUpperBound()
                    iAtt.m_name = Bonds(i).CreateDefaultName(Atoms(Bonds(i).Father), _
                                                             Atoms(Bonds(i).Mother))
                    RMA.Rhino.RhUtil.RhinoApp.ActiveDoc.AddMeshObject( _
                        Bonds(i).CastOnMesh(Atoms(Bonds(i).Father), _
                                            Atoms(Bonds(i).Mother), _
                                            pAttributes.b_PipeRadius, pAttributes.b_MeshFaceCount), iAtt)
                Next
        End Select

        Return arrObjs
    End Function

    Public Sub SynchronizeViewportsToMolecule(Optional ByVal bSynchActiveOnly As Boolean = False)
        Dim iViews() As RMA.Rhino.MRhinoView
        Dim v, vCount As Int32
        Dim mBBox As RMA.OpenNURBS.OnBoundingBox = BoundingBox()
        vCount = RMA.Rhino.RhUtil.RhinoApp.ActiveDoc.GetViewList(iViews)

        For v = 0 To vCount - 1
            If Not bSynchActiveOnly Or RMA.Rhino.RhUtil.RhinoApp.ActiveView Is iViews(v) Then
                iViews(v).Viewport.DollyExtents(mBBox)
            End If
        Next
    End Sub

    Public Function ReadFromPDBFile(ByVal sFilepath As String) As Boolean
        Dim iReader As New System.IO.StreamReader(sFilepath)
        Dim iLine As String
        Dim terN As Int32 = 1

        Do
            iLine = iReader.ReadLine
            If iLine Is Nothing Then Exit Do
            Select Case Trim(Left(iLine, 6))
                Case "TER"
                    set_Molecules.AddRecord(terN)
                    terN += 1
                Case "ATOM", "HETATM"
                    Dim nAtom As New Atom
                    If nAtom.ReadFromASCII(iLine, terN) Then
                        AddAtom(nAtom)
                        set_Chains.AddUniqueRecord(nAtom.Chain)
                        set_Residues.AddUniqueRecord(nAtom.Residue)
                    End If
                Case "END"
                    Exit Do
                Case Else
            End Select
        Loop Until Not iReader.BaseStream.CanRead

        Me.Original_Atom_Count = AtomUpperBound() + 1
        RMA.Rhino.RhUtil.RhinoApp.Print("data loaded..." & vbCrLf)
        iReader.Close()

        Shadow_PDB_File = sFilepath
        Return True
    End Function

    Public Function ReadSpecificRecordField(ByVal sField As String) As Collection
        Try
            Dim iReader As New System.IO.StreamReader(Shadow_PDB_File)
            Dim iLine As String
            Dim iLines As New Collection

            Do
                iLine = iReader.ReadLine
                If iLine Is Nothing Then Exit Do
                If UCase(Left(iLine, sField.Length)) = UCase(sField) Then
                    iLines.Add(Mid(iLine, sField.Length + 1))
                End If
            Loop

            iReader.Close()
            Return iLines
        Catch ex As Exception
            MsgBox(ex.Message, , "Error in ReadSpecificRecordField")
        End Try
    End Function

    Public Sub CalculateBonds(ByVal SearchDepth As Int32)
        Dim i, j As Int32
        Dim jMax As Int32

        For i = 0 To AtomUpperBound() - 1
            jMax = System.Math.Min(i + SearchDepth, AtomUpperBound)
            For j = i + 1 To jMax
                If Atoms(i).IsWithinBondingRange(Atoms(j)) Then
                    AddBond(New Bond(i, j))
                End If
            Next
        Next
    End Sub

    Public Sub FilterAtomList(ByVal nFilter As AtomFilter)
        Dim i As Int32

        If nFilter.set_Molecules.RecordCount > 0 Then
            For i = 0 To AtomUpperBound()
                If nFilter.set_Molecules.IsRecord(CStr(Atoms(i).MoleculeNumber)) Then Atoms(i) = Nothing
            Next
            CullEmptySlots(True)
        End If

        If nFilter.set_Chains.RecordCount > 0 Then
            For i = 0 To AtomUpperBound()
                If nFilter.set_Chains.IsRecord(CStr(Atoms(i).Chain)) Then Atoms(i) = Nothing
            Next
            CullEmptySlots(True)
        End If

        If nFilter.set_Residues.RecordCount > 0 Then
            For i = 0 To AtomUpperBound()
                If nFilter.set_Residues.IsRecord(CStr(Atoms(i).Residue)) Then Atoms(i) = Nothing
            Next
            CullEmptySlots(True)
        End If
    End Sub

    Public Sub CullElements(Optional ByVal cElement As AtomCode = AtomCode.H)
        Dim i As Int32
        For i = 0 To AtomUpperBound()
            If Atoms(i).ElementType = cElement Then Atoms(i) = Nothing
        Next
        CullEmptySlots(True)
    End Sub
End Class

