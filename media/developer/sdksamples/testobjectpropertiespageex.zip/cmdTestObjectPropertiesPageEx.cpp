/////////////////////////////////////////////////////////////////////////////
// cmdTestObjectPropertiesPageEx.cpp : command file
//

#include "StdAfx.h"
#include "TestObjectPropertiesPageExPlugIn.h"

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//
// BEGIN TestObjectPropertiesPageEx command
//

#pragma region TestObjectPropertiesPageEx command

class CCommandTestObjectPropertiesPageEx : public CRhinoCommand
{
public:
	CCommandTestObjectPropertiesPageEx() {}
  ~CCommandTestObjectPropertiesPageEx() {}
	UUID CommandUUID()
	{
		// {833B7AFD-A13C-49E8-BB81-60A3ECC2C267}
    static const GUID TestObjectPropertiesPageExCommand_UUID =
    { 0x833B7AFD, 0xA13C, 0x49E8, { 0xBB, 0x81, 0x60, 0xA3, 0xEC, 0xC2, 0xC2, 0x67 } };
    return TestObjectPropertiesPageExCommand_UUID;
	}
	const wchar_t* EnglishCommandName() { return L"TestObjectPropertiesPageEx"; }
	const wchar_t* LocalCommandName() { return L"TestObjectPropertiesPageEx"; }
	CRhinoCommand::result RunCommand( const CRhinoCommandContext& );
};
static class CCommandTestObjectPropertiesPageEx theTestObjectPropertiesPageExCommand;

CRhinoCommand::result CCommandTestObjectPropertiesPageEx::RunCommand( const CRhinoCommandContext& context )
{
  ON_wString wStr;
  wStr.Format( L"The \"%s\" command is under construction.\n", EnglishCommandName() );
  if( context.IsInteractive() )
    RhinoMessageBox( wStr, PlugIn()->PlugInName(), MB_OK );
  else
	  RhinoApp().Print( wStr );
  return CRhinoCommand::success;
}

#pragma endregion

//
// END TestObjectPropertiesPageEx command
//
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
