"""Compress or expand object spacing by a scale factor in X, Y and Z
Warning: does not check for resulting overlaps!!!
Script by Mitch Heynick 4 June 2014"""

import rhinoscriptsyntax as rs
import scriptcontext as sc

def BBCtr(objs):
    BB=rs.BoundingBox(objs)
    return (BB[0]+BB[6])/2

def CompressExpandSpace():
    objTypes=1+4+8+16+32+512+4096    
    msg="Select collection of objects to compress or expand spacing"    
    objs=rs.GetObjects(msg,objTypes,preselect=True)
    if not objs: return
    
    tol=rs.UnitAbsoluteTolerance()  
    scalePt=rs.GetPoint("Base point for scale")
    if not scalePt: return
    
    #retrive previous scale factor
    if "cesPrevScaleFactors" in sc.sticky: sf=sc.sticky["cesPrevScaleFactors"]
    else: sf=[1.0,1.0,1.0]
    
    sX=rs.GetReal("Scale in X?",sf[0],tol)
    if not sX: return    
    sY=rs.GetReal("Scale in Y?",sf[1],tol)
    if not sY: return
    sZ=rs.GetReal("Scale in Z?",sf[2],tol)
    if not sZ: return
    
    rs.EnableRedraw(False)
    origCP=[]
    for obj in objs:
        if rs.IsPoint(obj):
            origCP.append(rs.PointCoordinates(obj))
        elif rs.IsTextDot(obj):
            origCP.append(rs.TextDotPoint(obj))
        else:
            pt=BBCtr(obj)
            if not pt:
                print("Unable to find bounding box of object")
                rs.SelectObject(obj)
                return
            else:
                origCP.append(pt)      

    xForm=rs.XformScale([sX,sY,sZ],scalePt)
    scaledCPts=rs.PointArrayTransform(origCP,xForm)
    
    for i,obj in enumerate(objs):
        rs.MoveObject(obj,scaledCPts[i]-origCP[i])
    #store prev scale factor
    sc.sticky["cesPrevScaleFactors"] = [sX,sY,sZ]
    
CompressExpandSpace()