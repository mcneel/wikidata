Option Compare Text
Imports RMA.Rhino

Module SelectionTools
    Public Function GetAtomAttributes(ByVal sPrompt As String, ByVal nAttributes As AtomAttributes) As String
        Dim getInterface As New RMA.Rhino.MRhinoGetObject
        getInterface.SetCommandPrompt(sPrompt)
        getInterface.SetGeometryFilter(Convert.ToUInt32(RMA.Rhino.IRhinoGetObject.GEOMETRY_TYPE_FILTER.mesh_object Or _
                                                        RMA.Rhino.IRhinoGetObject.GEOMETRY_TYPE_FILTER.point_object Or _
                                                        RMA.Rhino.IRhinoGetObject.GEOMETRY_TYPE_FILTER.surface_object))

        getInterface.EnableTransparentCommands(True)
        getInterface.EnablePreSelect(True, False)
        getInterface.EnablePostSelect(True)
        getInterface.AcceptString(True)

        getInterface.GetObjects(0, 1)
        Select Case getInterface.Result
            Case RMA.Rhino.IRhinoGet.result.object
                Exit Select
            Case RMA.Rhino.IRhinoGet.result.string
                Return getInterface.String
            Case Else
                Return Nothing
        End Select

        Dim iObjRef As RMA.Rhino.MRhinoObjRef = getInterface.Object(0)
        Dim iObjAtt As RMA.Rhino.MRhinoObjectAttributes = iObjRef.Object.Attributes
        Select Case nAttributes
            Case AtomAttributes.Element
                Return ExtractAtomElement(iObjAtt.m_name)
            Case AtomAttributes.Molecule
                Return ExtractAtomMolecule(iObjAtt.m_name)
            Case AtomAttributes.Chain
                Return ExtractAtomChain(iObjAtt.m_name)
            Case AtomAttributes.Residue
                Return ExtractAtomResidue(iObjAtt.m_name)
        End Select
        Return ""
    End Function

    Public Function SelectAtoms(ByVal sFilter As String, ByVal nAttributes As AtomAttributes) As Int32
        Dim iIterator As New RMA.Rhino.MRhinoObjectIterator(RMA.Rhino.RhUtil.RhinoApp.ActiveDoc, _
                                                            RMA.Rhino.IRhinoObjectIterator.object_state.normal_objects)
        iIterator.SetObjectFilter(Convert.ToUInt32(RMA.Rhino.IRhinoGetObject.GEOMETRY_TYPE_FILTER.mesh_object Or _
                                                   RMA.Rhino.IRhinoGetObject.GEOMETRY_TYPE_FILTER.point_object Or _
                                                   RMA.Rhino.IRhinoGetObject.GEOMETRY_TYPE_FILTER.surface_object))
        iIterator.EnableVisibleFilter(True)

        Dim iObject As RMA.Rhino.MRhinoObject
        Dim nCount As Int32 = 0
        Dim iAttributes As RMA.Rhino.MRhinoObjectAttributes
        Dim bSelect As Boolean


        iObject = iIterator.First()
        If iObject Is Nothing Then Return nCount
        Do
            iAttributes = iObject.Attributes
            bSelect = False
            Select Case nAttributes
                Case AtomAttributes.Element
                    If ExtractAtomElement(iAttributes.m_name) = sFilter Then bSelect = True
                Case AtomAttributes.Molecule
                    If ExtractAtomMolecule(iAttributes.m_name) = sFilter Then bSelect = True
                Case AtomAttributes.Residue
                    If ExtractAtomResidue(iAttributes.m_name) = sFilter Then bSelect = True
                Case AtomAttributes.Chain
                    If ExtractAtomChain(iAttributes.m_name) = sFilter Then bSelect = True
            End Select

            If bSelect Then
                iObject.Select(True, True, True, True, False, False)
                nCount += 1
            End If

            iObject = iIterator.Next()
            If iObject Is Nothing Then Return nCount
        Loop
    End Function

    Public Function SelectByElement() As RMA.Rhino.IRhinoCommand.result
        Dim iFilter As String = GetAtomAttributes( _
            "Enter an element name or select an atom to specify the selection filter", _
            AtomAttributes.Element)
        If iFilter = "" Then Return IRhinoCommand.result.cancel

        iFilter = Definitions.ToElementName(Definitions.ToElementType(iFilter), False)
        Dim nCount As Int32 = SelectAtoms(iFilter, AtomAttributes.Element)

        Select Case nCount
            Case 0
                RMA.Rhino.RhUtil.RhinoApp.Print(String.Format("No {0} atoms were found...", iFilter) & vbCrLf)
            Case 1
                RMA.Rhino.RhUtil.RhinoApp.Print(String.Format("Only one {0} atom was found...", iFilter) & vbCrLf)
            Case Is > 2
                RMA.Rhino.RhUtil.RhinoApp.Print(String.Format("{0} {1} atoms were found...", nCount, iFilter) & vbCrLf)
        End Select
        RMA.Rhino.RhUtil.RhinoApp.ActiveDoc.Redraw()
    End Function

    Public Function SelectByMolecularStructure() As RMA.Rhino.IRhinoCommand.result
        Dim iFilter As String = GetAtomAttributes( _
            "Enter a molecule structure ID or select an atom from that structure to specify the selection filter", _
            AtomAttributes.Molecule)
        If iFilter = "" Then Return IRhinoCommand.result.cancel

        Dim nCount As Int32 = SelectAtoms(iFilter, AtomAttributes.Molecule)

        Select Case nCount
            Case 0
                RMA.Rhino.RhUtil.RhinoApp.Print(String.Format("The {0} molecule structure could not be found...", iFilter) & vbCrLf)
            Case 1
                RMA.Rhino.RhUtil.RhinoApp.Print(String.Format("Only one atom in the {0} structure was found...", iFilter) & vbCrLf)
            Case Is > 2
                RMA.Rhino.RhUtil.RhinoApp.Print(String.Format("{0} atoms in the {1} structure were found...", nCount, iFilter) & vbCrLf)
        End Select
        RMA.Rhino.RhUtil.RhinoApp.ActiveDoc.Redraw()
    End Function

    Public Function SelectByChain() As RMA.Rhino.IRhinoCommand.result
        Dim iFilter As String = GetAtomAttributes( _
            "Enter a chain ID or select an atom from that chain to specify the selection filter", _
            AtomAttributes.Chain)
        If iFilter = "" Then Return IRhinoCommand.result.cancel

        Dim nCount As Int32 = SelectAtoms(iFilter, AtomAttributes.Chain)

        Select Case nCount
            Case 0
                RMA.Rhino.RhUtil.RhinoApp.Print(String.Format("Chain {0} could not be found...", iFilter) & vbCrLf)
            Case 1
                RMA.Rhino.RhUtil.RhinoApp.Print(String.Format("Only one atom in chain {0} was found...", iFilter) & vbCrLf)
            Case Is > 2
                RMA.Rhino.RhUtil.RhinoApp.Print(String.Format("{0} atoms were found in chain {1}...", nCount, iFilter) & vbCrLf)
        End Select
        RMA.Rhino.RhUtil.RhinoApp.ActiveDoc.Redraw()
    End Function

    Public Function SelectByResidue() As RMA.Rhino.IRhinoCommand.result
        Dim iFilter As String = GetAtomAttributes( _
            "Enter a residue code or select an atom from that residue to specify the selection filter", _
            AtomAttributes.Residue)
        If iFilter = "" Then Return IRhinoCommand.result.cancel

        Dim nCount As Int32 = SelectAtoms(iFilter, AtomAttributes.Residue)

        Select Case nCount
            Case 0
                RMA.Rhino.RhUtil.RhinoApp.Print(String.Format("Residue {0} could not be found...", iFilter) & vbCrLf)
            Case 1
                RMA.Rhino.RhUtil.RhinoApp.Print(String.Format("Only one atom in residue {0} was found...", iFilter) & vbCrLf)
            Case Is > 2
                RMA.Rhino.RhUtil.RhinoApp.Print(String.Format("{0} atoms were found in residue {1}...", nCount, iFilter) & vbCrLf)
        End Select
        RMA.Rhino.RhUtil.RhinoApp.ActiveDoc.Redraw()
    End Function
End Module
