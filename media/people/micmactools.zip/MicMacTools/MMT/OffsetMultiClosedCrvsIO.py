import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino

def GetOffsetPickPoint(crv,plane,dist,side,n):
    #returns pick point on correct side of curve
    #outside==0 ; inside==1
    check_pt = CrvSegmentMidPt(crv, n)    
    if check_pt:
        tan_vec = rs.CurveTangent(crv,rs.CurveClosestPoint(crv,check_pt))    
        norm_vec = rs.VectorCrossProduct(plane.ZAxis, tan_vec)
        norm_vec = rs.VectorScale(norm_vec, dist)
        pick_pt = check_pt + norm_vec
        #rs.AddPoint(pick_pt)
        #rs.Redraw()
        pt_in=rs.PointInPlanarClosedCurve(pick_pt,crv,plane)
        if (pt_in==0 and side==0) or (pt_in==1 and side==1):
            #point matches choice
            return pick_pt
            
        elif (pt_in==1 and side==0) or (pt_in==0 and side==1):
            #point on opposite side
            norm_vec.Reverse()
            pick_pt = check_pt + norm_vec
            #rs.AddPoint(pick_pt)
            #rs.Redraw()
            pt_in=rs.PointInPlanarClosedCurve(pick_pt,crv,plane)
            if (pt_in==0 and side==0) or (pt_in==1 and side==1):
                #point matches choice
                return pick_pt

def OffsetCurve2Sides(crv,dist,trans,side):
    if rs.IsPolyline(crv):
        n = rs.CurvePointCount(crv)-2
    elif rs.IsPolyCurve(crv):
        n = rs.PolyCurveCount(crv)-1
    else: n = 1
    
    if rs.IsLine(crv): plane = rs.ViewCPlane()
    else: plane = rs.CurvePlane(crv)
    offset_crvs=[]
    
    #RhinoCommon offset?
    if side==0 or side==2:
        for i in range(n):
            pick_pt=GetOffsetPickPoint(crv,plane,dist,0,n)
            if pick_pt:
                offset_0=rs.OffsetCurve(crv, pick_pt,dist,plane.ZAxis,trans)
                if offset_0:
                    offset_crvs.append(offset_0)
                    break
        if not pick_pt:
            #error message
            return
        
    if side==1 or side==2:
        for i in range(n):
            pick_pt=GetOffsetPickPoint(crv,plane,dist,1,n)
            if pick_pt:
                offset_1=rs.OffsetCurve(crv,pick_pt,dist,plane.ZAxis,trans)
                if offset_1:
                    offset_crvs.append(offset_1)
                    break
        if not pick_pt:
            #error message
            return
    if len(offset_crvs)>0: return offset_crvs

def CrvSegmentMidPt(crv, n):
    if rs.IsPolyline(crv):
        verts = rs.PolylineVertices(crv)
        midPt = (verts[n] + verts[n+1])/2
    elif rs.IsPolyCurve(crv):
        midPt = rs.CurveMidPoint(crv, n)
    else:
        midPt = rs.CurveMidPoint(crv)
    return midPt

def cpCrv_filt(rhino_object, geometry, component_index):
    return rs.IsCurvePlanar(geometry) and rs.IsCurveClosed(geometry)

def OffsetMultiClosedCurvesIO():
    msg="Select closed planar curve(s) to offset"
    crvs=rs.GetObjects(msg,4,preselect=True,custom_filter=cpCrv_filt)
    if not crvs: return
    
    tol=rs.UnitAbsoluteTolerance()
    s_choice=["Outside","Inside","Both"]
    t_choice = ["Sharp", "Round", "Smooth", "Chamfer"]
    
    if "OMCCIO_dist" in sc.sticky: prev_dist = sc.sticky["OMCCIO_dist"]
    else: prev_dist = 1.0
    if "OMCCIO_trans" in sc.sticky: prev_trans = sc.sticky["OMCCIO_trans"]
    else: prev_trans = "Sharp"
    if "OMCCIO_side" in sc.sticky: prev_side = sc.sticky["OMCCIO_side"]
    else: prev_side = "Inside"
    
    off_dist=rs.GetReal("Distance to offset",prev_dist,tol)
    if not off_dist: return
    
    trans_type = rs.GetString("Offset transition?", prev_trans, t_choice)
    if not trans_type in t_choice: return
    if trans_type=="Sharp": tt=1
    elif trans_type=="Round": tt=2
    elif trans_type=="Smooth": tt=3
    elif trans_type=="Chamfer": tt=4
    else: return
    
    side=rs.GetString("Side to offset?",prev_side,s_choice)
    if not side in s_choice: return    
    if side=="Outside": ss=0
    elif side=="Inside": ss=1
    elif side=="Both": ss=2
    
    rs.EnableRedraw(False)
    rs.UnselectAllObjects()
    count=0
    for crv in crvs:
        offsets=OffsetCurve2Sides(crv,off_dist,tt,ss)
        if ss<2: rv=1
        else: rv=2
        if offsets and len(offsets)==rv: count+=1
        for offset in offsets: rs.SelectObjects(offsets)
    #reporting
    print "{} out of {} curves offset successfully".format(len(crvs),count)
    #set preferences
    sc.sticky["OMCCIO_dist"] = off_dist
    sc.sticky["OMCCIO_trans"] = trans_type
    sc.sticky["OMCCIO_side"] = side
    
OffsetMultiClosedCurvesIO()