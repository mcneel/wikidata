import rhinoscriptsyntax as rs
import scriptcontext as sc
from Rhino import RhinoMath
    
def SelSrfsByArea():
    objs=rs.ObjectsByType(8+16,state=1)
    if not objs: return
    tol=sc.doc.ModelAbsoluteTolerance
    ff=RhinoMath.SqrtEpsilon #"fuzz factor"
    entity="surface"
    entity2="polysurface"
    measure="area"
    cl=["LessThan","GreaterThan","EqualTo","LTorEqualTo","GTorEqualTo","Between"]
    
    #get previous settings
    if "SSA_Type_Choice" in sc.sticky: type_choice = sc.sticky["SSA_Type_Choice"]
    else: type_choice = cl[0]
    if "SSA_User_A" in sc.sticky: user_A = sc.sticky["SSA_User_A"]
    else: user_A = 1.0
    if "SSA_Max_A" in sc.sticky: max_A = sc.sticky["SSA_Max_A"]
    else: max_A = 1.0
    if "SSA_Min_A" in sc.sticky: min_A = sc.sticky["SSA_Min_A"]
    else: min_A = 1.0
    
    rs.UnselectAllObjects()
    msg="Selection type for {} {}?".format(entity,measure)
    while True:
        compare=rs.GetString(msg,type_choice,cl)
        if not compare: return
        if compare in cl: break
    
    if compare == cl[5]:
        min_A=rs.GetReal("Minimum area?",min_A,minimum=tol)
        if not min_A: return
        if max_A<min_A: max_A=min_A
        max_A=rs.GetReal("Maximum area?",max_A,minimum=min_A)
        if not max_A: return
    else:
        area=rs.GetReal("Area?",user_A,minimum=tol)
        if not area: return
        
    rs.EnableRedraw(False)
    for obj in objs:
        sa=rs.SurfaceArea(obj)
        if not sa: continue
        obj_area=sa[0]
        if compare==cl[0]:
            if obj_area < area-ff: rs.SelectObject(obj)
        elif compare==cl[1]:
            if obj_area > area+ff: rs.SelectObject(obj)
        elif compare==cl[2]:
            if abs(area-obj_area)<ff: rs.SelectObject(obj)
        elif compare==cl[3]:
            if obj_area <= area: rs.SelectObject(obj)
        elif compare==cl[4]:
            if obj_area >= area: rs.SelectObject(obj)
        elif compare==cl[5]:
            if obj_area >= min_A and obj_area <= max_A: rs.SelectObject(obj)
            
    selObjs=rs.SelectedObjects()
    msg="found that match selection criteria"
    if selObjs:
        q=len(selObjs)
        if q>1:
            entity+="s" ; entity2+="s"
    else: q="No" ; entity+="s" ; entity2+="s"
    print "{} {} or {} {}".format(q,entity,entity2,msg)
    
    #store previous settings
    sc.sticky["SSA_Type_Choice"] = compare
    try: sc.sticky["SSA_User_A"] = area
    except: pass
    try: sc.sticky["SSA_Max_A"] = max_A
    except: pass
    try: sc.sticky["SSA_Min_A"] = min_A
    except: pass
SelSrfsByArea()
