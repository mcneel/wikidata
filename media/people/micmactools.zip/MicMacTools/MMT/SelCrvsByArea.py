import rhinoscriptsyntax as rs
import scriptcontext as sc
from Rhino import RhinoMath
    
def SelCrvsByArea():
    crvs=rs.ObjectsByType(4,state=1)
    if not crvs:return
    objs=[c for c in crvs if (rs.IsCurveClosed(c) and rs.IsCurvePlanar(c))]
    if not objs:
        print "No closed planar curves found"
        return
    tol=sc.doc.ModelAbsoluteTolerance
    ff=RhinoMath.SqrtEpsilon #"fuzz factor"
    entity="curve"
    measure="area"
    cl=["LessThan","GreaterThan","EqualTo","LTorEqualTo","GTorEqualTo","Between"]
    
    #get previous settings
    if "SCA_Type_Choice" in sc.sticky: type_choice = sc.sticky["SCA_Type_Choice"]
    else: type_choice = cl[0]
    if "SCA_User_A" in sc.sticky: user_A = sc.sticky["SCA_User_A"]
    else: user_A = 1.0
    if "SCA_Max_A" in sc.sticky: max_A = sc.sticky["SCA_Max_A"]
    else: max_A = 1.0
    if "SCA_Min_A" in sc.sticky: min_A = sc.sticky["SCA_Min_A"]
    else: min_A = 1.0
    
    rs.UnselectAllObjects()
    msg="Selection type for {} {}?".format(entity,measure)
    while True:
        compare=rs.GetString(msg,type_choice,cl)
        if not compare: return
        if compare in cl: break
    
    if compare == cl[5]:
        min_A=rs.GetReal("Minimum area?",min_A,minimum=tol)
        if not min_A: return
        if max_A<min_A: max_A=min_A
        max_A=rs.GetReal("Maximum area?",max_A,minimum=min_A)
        if not max_A: return
    else:
        area=rs.GetReal("Area?",user_A,minimum=tol)
        if not area: return
        
    rs.EnableRedraw(False)
    for obj in objs:
        ca=rs.CurveArea(obj)
        if not ca: continue
        obj_area=ca[0]
        if compare==cl[0]:
            if obj_area < area-ff: rs.SelectObject(obj)
        elif compare==cl[1]:
            if obj_area > area+ff: rs.SelectObject(obj)
        elif compare==cl[2]:
            if abs(area-obj_area)<ff: rs.SelectObject(obj)
        elif compare==cl[3]:
            if obj_area <= area: rs.SelectObject(obj)
        elif compare==cl[4]:
            if obj_area >= area: rs.SelectObject(obj)
        elif compare==cl[5]:
            if obj_area >= min_A and obj_area <= max_A: rs.SelectObject(obj)
            
    selObjs=rs.SelectedObjects()
    if selObjs:
        q=len(selObjs)
        if q>1: entity+="s"
    else: q="No" ; entity+="s"
    print "{} closed planar {} found that match selection criteria".format(q,entity)
    
    #store previous settings
    sc.sticky["SCA_Type_Choice"] = compare
    try: sc.sticky["SCA_User_A"] = area
    except: pass
    try: sc.sticky["SCA_Max_A"] = max_A
    except: pass
    try: sc.sticky["SCA_Min_A"] = min_A
    except: pass
SelCrvsByArea()
