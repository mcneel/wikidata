import rhinoscriptsyntax as rs

entity="ellipse"
err_msg="No {} objects added to selection".format(entity+"s") 
objs=rs.ObjectsByType(4,state=1)
if objs:
    select=[obj for obj in objs if rs.IsEllipse(obj)]
    if select:
        rs.EnableRedraw(False)
        rs.SelectObjects(select)
        if len(select)>1: s="s"
        else: s=""
        print "{} {} object{} added to selection".format(len(select),entity,s)
    else: print err_msg
else: print err_msg