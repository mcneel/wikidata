Public Class OptionsDialog
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents cmbAtomGeometry As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbBondGeometry As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents numSearchDepth As System.Windows.Forms.NumericUpDown
    Friend WithEvents chkIgnoreHydrogen As System.Windows.Forms.CheckBox
    Friend WithEvents cmbAtomRadius As System.Windows.Forms.ComboBox
    Friend WithEvents numConstantRadius As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents chkApplyFilter As System.Windows.Forms.CheckBox
    Friend WithEvents FilterTree As System.Windows.Forms.TreeView
    Friend WithEvents lblShowBanner As System.Windows.Forms.LinkLabel
    Friend WithEvents btnDetails As System.Windows.Forms.Button
    Friend WithEvents chkGroupGeometry As System.Windows.Forms.CheckBox
    Friend WithEvents numBondFaces As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cmbColours As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Divider1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents numBondRadius As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label7 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.numBondRadius = New System.Windows.Forms.NumericUpDown
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Divider1 = New System.Windows.Forms.GroupBox
        Me.cmbColours = New System.Windows.Forms.ComboBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.numBondFaces = New System.Windows.Forms.NumericUpDown
        Me.chkGroupGeometry = New System.Windows.Forms.CheckBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.numConstantRadius = New System.Windows.Forms.NumericUpDown
        Me.cmbAtomRadius = New System.Windows.Forms.ComboBox
        Me.chkIgnoreHydrogen = New System.Windows.Forms.CheckBox
        Me.numSearchDepth = New System.Windows.Forms.NumericUpDown
        Me.Label3 = New System.Windows.Forms.Label
        Me.cmbBondGeometry = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmbAtomGeometry = New System.Windows.Forms.ComboBox
        Me.btnOK = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.chkApplyFilter = New System.Windows.Forms.CheckBox
        Me.FilterTree = New System.Windows.Forms.TreeView
        Me.lblShowBanner = New System.Windows.Forms.LinkLabel
        Me.btnDetails = New System.Windows.Forms.Button
        Me.GroupBox1.SuspendLayout()
        CType(Me.numBondRadius, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numBondFaces, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numConstantRadius, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numSearchDepth, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.numBondRadius)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.Divider1)
        Me.GroupBox1.Controls.Add(Me.cmbColours)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.numBondFaces)
        Me.GroupBox1.Controls.Add(Me.chkGroupGeometry)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.numConstantRadius)
        Me.GroupBox1.Controls.Add(Me.cmbAtomRadius)
        Me.GroupBox1.Controls.Add(Me.chkIgnoreHydrogen)
        Me.GroupBox1.Controls.Add(Me.numSearchDepth)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.cmbBondGeometry)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.cmbAtomGeometry)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(272, 296)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Geometry settings"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(8, 200)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(104, 16)
        Me.Label7.TabIndex = 24
        Me.Label7.Text = "Bond pipe radius"
        '
        'numBondRadius
        '
        Me.numBondRadius.DecimalPlaces = 2
        Me.numBondRadius.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.numBondRadius.Location = New System.Drawing.Point(120, 200)
        Me.numBondRadius.Minimum = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.numBondRadius.Name = "numBondRadius"
        Me.numBondRadius.Size = New System.Drawing.Size(144, 20)
        Me.numBondRadius.TabIndex = 23
        Me.numBondRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.numBondRadius.Value = New Decimal(New Integer() {25, 0, 0, 131072})
        '
        'GroupBox2
        '
        Me.GroupBox2.Location = New System.Drawing.Point(8, 224)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(256, 5)
        Me.GroupBox2.TabIndex = 22
        Me.GroupBox2.TabStop = False
        '
        'Divider1
        '
        Me.Divider1.Location = New System.Drawing.Point(8, 112)
        Me.Divider1.Name = "Divider1"
        Me.Divider1.Size = New System.Drawing.Size(256, 5)
        Me.Divider1.TabIndex = 21
        Me.Divider1.TabStop = False
        '
        'cmbColours
        '
        Me.cmbColours.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbColours.Items.AddRange(New Object() {"Default colour", "CPK palette", "Per chain", "Per residue", "Per sequence", "Per molecule", "By position", "By temperature", "By occupancy", "By serial"})
        Me.cmbColours.Location = New System.Drawing.Point(120, 264)
        Me.cmbColours.MaxDropDownItems = 20
        Me.cmbColours.Name = "cmbColours"
        Me.cmbColours.Size = New System.Drawing.Size(144, 21)
        Me.cmbColours.TabIndex = 20
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 264)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(96, 16)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Atom colours"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(8, 152)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(88, 16)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Bond faces"
        '
        'numBondFaces
        '
        Me.numBondFaces.Location = New System.Drawing.Point(120, 152)
        Me.numBondFaces.Minimum = New Decimal(New Integer() {3, 0, 0, 0})
        Me.numBondFaces.Name = "numBondFaces"
        Me.numBondFaces.Size = New System.Drawing.Size(144, 20)
        Me.numBondFaces.TabIndex = 17
        Me.numBondFaces.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.numBondFaces.Value = New Decimal(New Integer() {3, 0, 0, 0})
        '
        'chkGroupGeometry
        '
        Me.chkGroupGeometry.Checked = True
        Me.chkGroupGeometry.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkGroupGeometry.Location = New System.Drawing.Point(8, 240)
        Me.chkGroupGeometry.Name = "chkGroupGeometry"
        Me.chkGroupGeometry.Size = New System.Drawing.Size(112, 16)
        Me.chkGroupGeometry.TabIndex = 16
        Me.chkGroupGeometry.Text = "Group all objects"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 72)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(104, 16)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Atom radius"
        '
        'numConstantRadius
        '
        Me.numConstantRadius.DecimalPlaces = 2
        Me.numConstantRadius.Increment = New Decimal(New Integer() {25, 0, 0, 131072})
        Me.numConstantRadius.Location = New System.Drawing.Point(120, 88)
        Me.numConstantRadius.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.numConstantRadius.Minimum = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.numConstantRadius.Name = "numConstantRadius"
        Me.numConstantRadius.Size = New System.Drawing.Size(144, 20)
        Me.numConstantRadius.TabIndex = 14
        Me.numConstantRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.numConstantRadius.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'cmbAtomRadius
        '
        Me.cmbAtomRadius.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbAtomRadius.Items.AddRange(New Object() {"Fixed radius", "Atomic radius", "Bonding radius", "vd.Waals radius"})
        Me.cmbAtomRadius.Location = New System.Drawing.Point(120, 64)
        Me.cmbAtomRadius.MaxDropDownItems = 20
        Me.cmbAtomRadius.Name = "cmbAtomRadius"
        Me.cmbAtomRadius.Size = New System.Drawing.Size(144, 21)
        Me.cmbAtomRadius.TabIndex = 13
        '
        'chkIgnoreHydrogen
        '
        Me.chkIgnoreHydrogen.Location = New System.Drawing.Point(120, 48)
        Me.chkIgnoreHydrogen.Name = "chkIgnoreHydrogen"
        Me.chkIgnoreHydrogen.Size = New System.Drawing.Size(144, 16)
        Me.chkIgnoreHydrogen.TabIndex = 12
        Me.chkIgnoreHydrogen.Text = "Ignore hydrogen atoms"
        '
        'numSearchDepth
        '
        Me.numSearchDepth.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.numSearchDepth.Location = New System.Drawing.Point(120, 176)
        Me.numSearchDepth.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.numSearchDepth.Minimum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.numSearchDepth.Name = "numSearchDepth"
        Me.numSearchDepth.Size = New System.Drawing.Size(144, 20)
        Me.numSearchDepth.TabIndex = 11
        Me.numSearchDepth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.numSearchDepth.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 176)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 16)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Bond search depth"
        '
        'cmbBondGeometry
        '
        Me.cmbBondGeometry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbBondGeometry.Items.AddRange(New Object() {"No bonds", "Lines", "Nurbs pipes", "Mesh pipes"})
        Me.cmbBondGeometry.Location = New System.Drawing.Point(120, 128)
        Me.cmbBondGeometry.MaxDropDownItems = 20
        Me.cmbBondGeometry.Name = "cmbBondGeometry"
        Me.cmbBondGeometry.Size = New System.Drawing.Size(144, 21)
        Me.cmbBondGeometry.TabIndex = 9
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 128)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 16)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Bond geometry"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 16)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Atom geometry"
        '
        'cmbAtomGeometry
        '
        Me.cmbAtomGeometry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbAtomGeometry.Items.AddRange(New Object() {"No atoms", "Single pointcloud", "Multiple points", "Nurbs spheres", "Mesh spheres (low)", "Mesh spheres (high)", "Mesh boxes"})
        Me.cmbAtomGeometry.Location = New System.Drawing.Point(120, 24)
        Me.cmbAtomGeometry.MaxDropDownItems = 20
        Me.cmbAtomGeometry.Name = "cmbAtomGeometry"
        Me.cmbAtomGeometry.Size = New System.Drawing.Size(144, 21)
        Me.cmbAtomGeometry.TabIndex = 6
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(200, 312)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(80, 24)
        Me.btnOK.TabIndex = 1
        Me.btnOK.Text = "OK"
        '
        'btnCancel
        '
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(112, 312)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(80, 24)
        Me.btnCancel.TabIndex = 2
        Me.btnCancel.Text = "Cancel"
        '
        'chkApplyFilter
        '
        Me.chkApplyFilter.Location = New System.Drawing.Point(8, 344)
        Me.chkApplyFilter.Name = "chkApplyFilter"
        Me.chkApplyFilter.Size = New System.Drawing.Size(152, 16)
        Me.chkApplyFilter.TabIndex = 4
        Me.chkApplyFilter.Text = "Apply atom filters"
        '
        'FilterTree
        '
        Me.FilterTree.CheckBoxes = True
        Me.FilterTree.Enabled = False
        Me.FilterTree.ImageIndex = -1
        Me.FilterTree.Indent = 25
        Me.FilterTree.Location = New System.Drawing.Point(8, 368)
        Me.FilterTree.Name = "FilterTree"
        Me.FilterTree.Nodes.AddRange(New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("All molecule structures"), New System.Windows.Forms.TreeNode("All chain structures"), New System.Windows.Forms.TreeNode("All residue sequences")})
        Me.FilterTree.SelectedImageIndex = -1
        Me.FilterTree.Size = New System.Drawing.Size(272, 360)
        Me.FilterTree.TabIndex = 11
        '
        'lblShowBanner
        '
        Me.lblShowBanner.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lblShowBanner.Location = New System.Drawing.Point(240, 0)
        Me.lblShowBanner.Name = "lblShowBanner"
        Me.lblShowBanner.Size = New System.Drawing.Size(40, 12)
        Me.lblShowBanner.TabIndex = 12
        Me.lblShowBanner.TabStop = True
        Me.lblShowBanner.Text = "About"
        Me.lblShowBanner.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnDetails
        '
        Me.btnDetails.Location = New System.Drawing.Point(8, 312)
        Me.btnDetails.Name = "btnDetails"
        Me.btnDetails.Size = New System.Drawing.Size(80, 24)
        Me.btnDetails.TabIndex = 13
        Me.btnDetails.Text = "Details..."
        '
        'OptionsDialog
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(290, 363)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnDetails)
        Me.Controls.Add(Me.lblShowBanner)
        Me.Controls.Add(Me.FilterTree)
        Me.Controls.Add(Me.chkApplyFilter)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "OptionsDialog"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CADmium import options"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.numBondRadius, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numBondFaces, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numConstantRadius, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numSearchDepth, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public g_Attributes As GeometryAttributes
    Public mol_Pointer As Molecule

    Public Sub SetRecordLibraries(ByVal nFilter As AtomFilter)
        Dim allBaseNodes As Windows.Forms.TreeNodeCollection = FilterTree.Nodes
        Dim mol_Node As Windows.Forms.TreeNode = allBaseNodes.Item(0)
        Dim chn_Node As Windows.Forms.TreeNode = allBaseNodes.Item(1)
        Dim res_Node As Windows.Forms.TreeNode = allBaseNodes.Item(2)

        If nFilter.set_Molecules.RecordCount > 0 Then
            Dim curMolecule As String
            For Each curMolecule In nFilter.set_Molecules.libRecord
                mol_Node.Nodes.Add("Molecule " & curMolecule)
            Next
        End If

        If nFilter.set_Chains.RecordCount > 0 Then
            Dim curChain As String
            For Each curChain In nFilter.set_Chains.libRecord
                chn_Node.Nodes.Add("Chain " & curChain)
            Next
        End If

        If nFilter.set_Residues.RecordCount > 0 Then
            Dim curResidue As String
            For Each curResidue In nFilter.set_Residues.libRecord
                res_Node.Nodes.Add("Residue " & curResidue)
            Next
        End If

        Dim nCollection As Collection = GetAllTreeNodes()
        Dim iNode As Windows.Forms.TreeNode
        For Each iNode In nCollection
            iNode.Checked = True
        Next

        mol_Node.Expand()
        chn_Node.Expand()
    End Sub

    Public Function GetRecordLibraries() As AtomFilter
        Dim iNodeCollection As Collection = GetAllTreeNodes()
        Dim iNode As Windows.Forms.TreeNode
        Dim iFilter As New AtomFilter

        For Each iNode In iNodeCollection
            If Not iNode.Checked Then
                Select Case UCase(Mid(iNode.Text, 1, 4))
                    Case "MOLE"
                        iFilter.set_Molecules.AddRecord(Mid(iNode.Text, 10))
                    Case "CHAI"
                        iFilter.set_Chains.AddRecord(Mid(iNode.Text, 7))
                    Case "RESI"
                        iFilter.set_Residues.AddRecord(Mid(iNode.Text, 9))
                    Case Else
                        'Do nothing
                End Select
            End If
        Next
        Return iFilter
    End Function

    Private Function GetAllTreeNodes() As Collection
        Dim iNodeCollection As New Collection
        Dim iNode As Windows.Forms.TreeNode

        For Each iNode In FilterTree.Nodes
            IterateNodes(iNode, iNodeCollection)
        Next
        Return iNodeCollection
    End Function

    Private Sub IterateNodes(ByVal iNode As Windows.Forms.TreeNode, ByVal iNodeCollection As Collection)
        iNodeCollection.Add(iNode)
        Dim aNode As Windows.Forms.TreeNode
        For Each aNode In iNode.Nodes
            IterateNodes(aNode, iNodeCollection)
        Next
    End Sub

    Private Sub SetGeometryAttributes()
        Dim nAttributes As New GeometryAttributes
        nAttributes.o_Group = chkGroupGeometry.Checked
        nAttributes.b_SearchDepth = numSearchDepth.Value
        nAttributes.b_MeshFaceCount = numBondFaces.Value
        nAttributes.b_PipeRadius = numBondRadius.Value
        nAttributes.o_IgnoreHydrogen = chkIgnoreHydrogen.Checked
        nAttributes.o_ApplyFilter = chkApplyFilter.Checked

        nAttributes.a_ConstRadius = numConstantRadius.Value

        Select Case Me.cmbAtomGeometry.Text
            Case "No atoms"
                nAttributes.a_AtomGeometry = AtomGeometry.None
            Case "Single pointcloud"
                nAttributes.a_AtomGeometry = AtomGeometry.PointSet
            Case "Multiple points"
                nAttributes.a_AtomGeometry = AtomGeometry.Point
            Case "Nurbs spheres"
                nAttributes.a_AtomGeometry = AtomGeometry.NurbsSphere
            Case "Mesh spheres (low)"
                nAttributes.a_AtomGeometry = AtomGeometry.LQ_MeshSphere
            Case "Mesh spheres (high)"
                nAttributes.a_AtomGeometry = AtomGeometry.HQ_MeshSphere
            Case "Mesh boxes"
                nAttributes.a_AtomGeometry = AtomGeometry.MeshBox
            Case Else
                nAttributes.a_AtomGeometry = AtomGeometry.Unknown
        End Select

        Select Case Me.cmbAtomRadius.Text
            Case "Fixed radius"
                nAttributes.a_AtomRadius = AtomRadius.Constant
            Case "Atomic radius"
                nAttributes.a_AtomRadius = AtomRadius.AtomicRadius
            Case "Bonding radius"
                nAttributes.a_AtomRadius = AtomRadius.BondingRadius
            Case "vd. Waals radius"
                nAttributes.a_AtomRadius = AtomRadius.VanDerWaalsRadius
            Case Else
                nAttributes.a_AtomRadius = AtomRadius.Unknown
        End Select

        Select Case Me.cmbBondGeometry.Text
            Case "No bonds"
                nAttributes.b_BondGeometry = BondGeometry.None
            Case "Lines"
                nAttributes.b_BondGeometry = BondGeometry.Line
            Case "Nurbs pipes"
                nAttributes.b_BondGeometry = BondGeometry.NurbsPipe
            Case "Mesh pipes"
                nAttributes.b_BondGeometry = BondGeometry.MeshPipe
            Case Else
                nAttributes.b_BondGeometry = BondGeometry.Unknown
        End Select

        Select Case Me.cmbColours.Text
            Case "Default colour"
                nAttributes.a_AtomColour = AtomColour.None
            Case "CPK palette"
                nAttributes.a_AtomColour = AtomColour.CPK
            Case "Per chain"
                nAttributes.a_AtomColour = AtomColour.ByChain
            Case "Per residue"
                nAttributes.a_AtomColour = AtomColour.ByResidue
            Case "Per sequence"
                nAttributes.a_AtomColour = AtomColour.BySequence
            Case "Per molecule"
                nAttributes.a_AtomColour = AtomColour.ByMolecule
            Case "By position"
                nAttributes.a_AtomColour = AtomColour.ByPosition
            Case "By temperature"
                nAttributes.a_AtomColour = AtomColour.ByTemperature
            Case "By occupancy"
                nAttributes.a_AtomColour = AtomColour.ByOccupancy
            Case "By serial"
                nAttributes.a_AtomColour = AtomColour.BySerialNumber
            Case Else
                nAttributes.a_AtomColour = AtomColour.Unknown
        End Select

        g_Attributes = nAttributes
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        SetGeometryAttributes()
        SaveSettingsToRegistry()
        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub OptionsDialog_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LoadSettingsFromRegistry()
    End Sub

    Private Sub cmbAtomRadius_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbAtomRadius.SelectedIndexChanged
        numConstantRadius.Enabled = CBool(cmbAtomRadius.Text = "Fixed radius")
    End Sub

    Private Sub SaveSettingsToRegistry()
        ExchangeSetting(Me.cmbAtomGeometry.Name) = Me.cmbAtomGeometry.SelectedIndex
        ExchangeSetting(Me.cmbAtomRadius.Name) = Me.cmbAtomRadius.SelectedIndex
        ExchangeSetting(Me.cmbBondGeometry.Name) = Me.cmbBondGeometry.SelectedIndex
        ExchangeSetting(Me.cmbColours.Name) = Me.cmbColours.SelectedIndex
        ExchangeSetting(Me.chkIgnoreHydrogen.Name) = Me.chkIgnoreHydrogen.Checked
        ExchangeSetting(Me.chkGroupGeometry.Name) = Me.chkGroupGeometry.Checked
        ExchangeSetting(Me.numConstantRadius.Name) = Me.numConstantRadius.Value
        ExchangeSetting(Me.numSearchDepth.Name) = Me.numSearchDepth.Value
        ExchangeSetting(Me.numBondFaces.Name) = Me.numBondFaces.Value
        ExchangeSetting(Me.numBondRadius.Name) = Me.numBondRadius.Value
    End Sub

    Private Sub LoadSettingsFromRegistry()
        Me.cmbAtomGeometry.SelectedIndex = ExchangeSetting(Me.cmbAtomGeometry.Name, "1")
        Me.cmbBondGeometry.SelectedIndex = ExchangeSetting(Me.cmbBondGeometry.Name, "0")
        Me.cmbAtomRadius.SelectedIndex = ExchangeSetting(Me.cmbAtomRadius.Name, "1")
        Me.cmbColours.SelectedIndex = ExchangeSetting(Me.cmbColours.Name, "1")
        Me.chkIgnoreHydrogen.Checked = ExchangeSetting(Me.chkIgnoreHydrogen.Name, "False")
        Me.chkGroupGeometry.Checked = ExchangeSetting(Me.chkGroupGeometry.Name, "True")
        Me.numConstantRadius.Value = ExchangeSetting(Me.numConstantRadius.Name, "1.0")
        Me.numSearchDepth.Value = ExchangeSetting(Me.numSearchDepth.Name, "1000")
        Me.numBondFaces.Value = ExchangeSetting(Me.numBondFaces.Name, "3")
        Me.numBondRadius.Value = ExchangeSetting(Me.numBondRadius.Name, "0.25")
    End Sub

    Public Property ExchangeSetting(ByVal sName As String, _
                                    Optional ByVal ResultOnFailure As String = "") As String
        Get
            Dim iKey As Microsoft.Win32.RegistryKey
            iKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey( _
                    "Software\\Reconstructivism\\CADmium", False)
            If iKey Is Nothing Then Return ResultOnFailure

            ResultOnFailure = iKey.GetValue(sName, ResultOnFailure)
            iKey.Close()
            Return ResultOnFailure
        End Get
        Set(ByVal Value As String)
            Dim iKey As Microsoft.Win32.RegistryKey
            iKey = Microsoft.Win32.Registry.CurrentUser.CreateSubKey( _
                    "Software\\Reconstructivism\\CADmium")
            iKey.SetValue(sName, Value)
            iKey.Close()
        End Set
    End Property

    Private Sub chkApplyFilter_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkApplyFilter.CheckedChanged
        If chkApplyFilter.Checked Then
            Me.Height = 760
            FilterTree.Enabled = True
        Else
            Me.Height = 388
            FilterTree.Enabled = False
        End If
    End Sub

    Private Sub lblShowBanner_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lblShowBanner.LinkClicked
        Dim iBanner As New Banner
        lblShowBanner.LinkVisited = True
        iBanner.ShowDialog(RMA.Rhino.RhUtil.RhinoApp.MainWnd)
    End Sub

    Private Sub btnDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetails.Click
        Dim iAnalysis As New Analysis
        iAnalysis.mol_Pointer = mol_Pointer
        iAnalysis.LoadMolecularData()

        iAnalysis.Left = Me.Left + Me.Width
        iAnalysis.Height = Me.Height
        iAnalysis.Top = Me.Top

        iAnalysis.ShowDialog(Me)
    End Sub

    Private Sub FilterTree_AfterCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles FilterTree.AfterCheck
        Try
            Dim aNodes As Collection = GetAllTreeNodes()
            Dim iNode As System.Windows.Forms.TreeNode
            Select Case e.Node.Text
                Case "All molecule structures"
                    e.Node.BackColor = System.Drawing.SystemColors.Window
                    For Each iNode In aNodes
                        If Microsoft.VisualBasic.Left(iNode.Text, 9) = "Molecule " Then
                            iNode.Checked = e.Node.Checked
                        End If
                    Next
                Case "All chain structures"
                    e.Node.BackColor = System.Drawing.SystemColors.Window
                    For Each iNode In aNodes
                        If Microsoft.VisualBasic.Left(iNode.Text, 6) = "Chain " Then
                            iNode.Checked = e.Node.Checked
                        End If
                    Next
                Case "All residue sequences"
                    e.Node.BackColor = System.Drawing.SystemColors.Window
                    For Each iNode In aNodes
                        If Microsoft.VisualBasic.Left(iNode.Text, 8) = "Residue " Then
                            iNode.Checked = e.Node.Checked
                        End If
                    Next
            End Select
        Catch ex As Exception
            Return
        End Try
    End Sub

    Private Sub cmbAtomGeometry_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbAtomGeometry.SelectedIndexChanged
        Select Case UCase(cmbAtomGeometry.Text)
            Case "NO ATOMS", "SINGLE POINTCLOUD"
                cmbAtomRadius.Enabled = False
                numConstantRadius.Enabled = False
                cmbColours.Enabled = False
            Case "MULTIPLE POINTS"
                cmbAtomRadius.Enabled = False
                numConstantRadius.Enabled = False
                cmbColours.Enabled = True
            Case Else
                cmbAtomRadius.Enabled = True
                If UCase(cmbAtomRadius.Text) = "FIXED RADIUS" Then numConstantRadius.Enabled = True
                cmbColours.Enabled = True
        End Select
    End Sub

    Private Sub cmbBondGeometry_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbBondGeometry.SelectedIndexChanged
        Select Case UCase(cmbBondGeometry.Text)
            Case "NO BONDS"
                numBondFaces.Enabled = False
                numSearchDepth.Enabled = False
                numBondRadius.Enabled = False
            Case "LINES"
                numBondFaces.Enabled = False
                numSearchDepth.Enabled = True
                numBondRadius.Enabled = False
            Case "NURBS PIPES"
                numBondFaces.Enabled = False
                numSearchDepth.Enabled = True
                numBondRadius.Enabled = True
            Case Else
                numBondFaces.Enabled = True
                numSearchDepth.Enabled = True
                numBondRadius.Enabled = True
        End Select
    End Sub
End Class
