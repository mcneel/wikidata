import rhinoscriptsyntax as rs
import scriptcontext as sc
    
def SelCrvsByDegree():
    crvs=rs.ObjectsByType(4,state=1)
    if not crvs: return
    entity="curve"
    measure="degree"
    if "SCD_Degree" in sc.sticky: user_deg = sc.sticky["SCD_Degree"]
    else: user_deg = 3
    
    deg=rs.GetInteger("Degree of curves to select?",user_deg,1,11)
    if deg is None: return
    count=0
    rs.EnableRedraw(False)
    for crv in crvs:
        if rs.CurveDegree(crv)==deg:
            count+=1
            rs.SelectObject(crv)
    if count>0:
        add="added to selection"
        if count>1: entity+="s"
    else: count="No" ; entity+="s" ; add="found"
    print "{} degree {} {} {}".format(count,deg,entity,add)
    sc.sticky["SCD_Degree"] = deg
SelCrvsByDegree()