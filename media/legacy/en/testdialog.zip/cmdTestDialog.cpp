#include "StdAfx.h"
#include "TestDialogPlugIn.h"
#include "TestModalDialog.h"


class CCommandTestModalDialog : public CRhinoCommand
{
public:
	CCommandTestModalDialog() {}
  ~CCommandTestModalDialog() {}

	UUID CommandUUID()
	{
		// {A3E2B665-9485-4CCA-B865-EF5AA8A2E243}
		static const GUID TestModalDialogCommand_UUID =
    { 0xA3E2B665, 0x9485, 0x4CCA, { 0xB8, 0x65, 0xEF, 0x5A, 0xA8, 0xA2, 0xE2, 0x43 } };
		return TestModalDialogCommand_UUID;
	}

	const wchar_t* EnglishCommandName() { return L"TestModalDialog"; }
	const wchar_t* LocalCommandName() const { return L"TestModalDialog"; }
	CRhinoCommand::result RunCommand( const CRhinoCommandContext& );
};

static class CCommandTestModalDialog theTestModalDialogCommand;

CRhinoCommand::result CCommandTestModalDialog::RunCommand( const CRhinoCommandContext& context )
{
  CTestModalDialog dlg( CWnd::FromHandle(::RhinoApp().MainWnd()) );
  dlg.DoModal();
  return CRhinoCommand::success;
}


class CCommandTestModelessDialog : public CRhinoCommand
{
public:
	CCommandTestModelessDialog() {}
	~CCommandTestModelessDialog() {}

	UUID CommandUUID()
	{
		// {5E50A58-C60B-4E1E-A2C4-2657DC90417E}
		static const GUID TestModelessDialogCommand_UUID =
		{ 0x5E50A58, 0xC60B, 0x4E1E, { 0xA2, 0xC4, 0x26, 0x57, 0xDC, 0x90, 0x41, 0x7E } };
		return TestModelessDialogCommand_UUID;
	}

	const wchar_t* EnglishCommandName() { return L"TestModelessDialog"; }
	const wchar_t* LocalCommandName() { return L"TestModelessDialog"; }
	CRhinoCommand::result RunCommand( const CRhinoCommandContext& );
};

static class CCommandTestModelessDialog theTestModelessDialogCommand;

CRhinoCommand::result CCommandTestModelessDialog::RunCommand( const CRhinoCommandContext& context )
{
  CTestDialogPlugIn& plugin = TestDialogPlugIn();
  if( plugin.IsDialogVisible() )
  {
    plugin.SetDialogFocus();
  }
  else
  {
    if( !plugin.DisplayDialog() )
      RhinoApp().Print( L"Cannot create dialog box." );
  }

  return CRhinoCommand::success;
}
