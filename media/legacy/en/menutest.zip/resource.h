//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MenuTest.rc
//
#define IDR_TESTMENU                    6000
#define IDR_MENUTEST                    6000
#define ID_TESTMENU_TESTCOMMAND1        33000
#define ID_TESTMENU_TESTCOMMAND2        33001
#define ID_TESTMENU_SCRIPTMODE          33002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        6001
#define _APS_NEXT_COMMAND_VALUE         33003
#define _APS_NEXT_CONTROL_VALUE         6000
#define _APS_NEXT_SYMED_VALUE           6000
#endif
#endif
