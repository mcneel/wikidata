// MyTabDialog.cpp : implementation file
//

#include "stdafx.h"
#include "MyTabDialog.h"
#include "TabbedDockbarDemoPlugIn.h"


// CMyTabDialog dialog

IMPLEMENT_DYNCREATE(CMyTabDialog, CRhinoTabbedDockBarDialog)

CMyTabDialog::CMyTabDialog()
{
}

CMyTabDialog::~CMyTabDialog()
{
}

void CMyTabDialog::DoDataExchange(CDataExchange* pDX)
{
	CRhinoTabbedDockBarDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMyTabDialog, CRhinoTabbedDockBarDialog)
END_MESSAGE_MAP()



const wchar_t* CMyTabDialog::Caption(void) const
{
	return L"MyTab";
}

ON_UUID CMyTabDialog::TabId(void) const
{
#error "Don't reuse this UUID"
	// {EEDF40DF-43FB-4FCD-8167-4B6551AC8170}
	static const GUID uuid = { 0xeedf40df, 0x43fb, 0x4fcd, { 0x81, 0x67, 0x4b, 0x65, 0x51, 0xac, 0x81, 0x70 } };
	return uuid;

}

ON_UUID CMyTabDialog::PlugInId(void) const
{
	return TabbedDockbarDemoPlugIn().PlugInID();
}

HICON	CMyTabDialog::Icon(void) const
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	return ::LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_TAB));
}

