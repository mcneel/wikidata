/////////////////////////////////////////////////////////////////////////////
// MenuTest.cpp
//

#include "StdAfx.h"
#include "MenuTest.h"


/////////////////////////////////////////////////////////////////////////////
// CMenuTestApp definition

BEGIN_MESSAGE_MAP(CMenuTestApp, CWinApp)
	//{{AFX_MSG_MAP(CMenuTestApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMenuTestApp construction

CMenuTestApp::CMenuTestApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CMenuTestApp object

CMenuTestApp theApp;
