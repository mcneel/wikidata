Imports RMA.Rhino
Imports RMA.OpenNURBS
Imports RMA.Rhino.RhUtil

Public Class InflectionPointsCommand
  Inherits RMA.Rhino.MRhinoCommand

  Public Overrides Function CommandUUID() As System.Guid
    Return New Guid("{a24b5c2a-6dc5-4d10-9465-aab7c38c1638}")
  End Function

  Public Overrides Function EnglishCommandName() As String
    Return "InflectionPoints"
  End Function

  Public Overrides Function RunCommand(ByVal context As RMA.Rhino.IRhinoCommandContext) As RMA.Rhino.IRhinoCommand.result
    Dim nCurveGetter As New MRhinoGetObject
    nCurveGetter.SetCommandPrompt("Pick a curve for inflection analysis")
    nCurveGetter.SetGeometryFilter(IRhinoGetObject.GEOMETRY_TYPE_FILTER.curve_object)

    Select Case nCurveGetter.GetObjects(1, 1)
      Case IRhinoGet.result.object
        Dim rhCurve As IOnCurve = nCurveGetter.Object(0).Curve
        If (rhCurve Is Nothing) Then Return IRhinoCommand.result.cancel

        Dim nInflectionSolver As New InflectionFinder(rhCurve)
        Dim nInflectionCount As Int32 = nInflectionSolver.Inflections.Count

        If (nInflectionCount = 0) Then
          RhinoApp.Print("No inflection points found on curve" & vbCrLf)
        Else
          RhinoApp.Print(nInflectionCount & " inflection points found on curve" & vbCrLf)

          For Each ptInflection As CurveInflection In nInflectionSolver.Inflections
            context.m_doc.AddPointObject(ptInflection.Point)

#If DEBUG Then
            RhinoApp.Print(String.Format("Inflection point at: {0}", ptInflection.Parameter) & vbCrLf)
#Else
            RhinoApp.Print(String.Format("Inflection point at: {0:0.00}", ptInflection.Parameter) & vbCrLf)
#End If
          Next
        End If

      Case Else
        Return IRhinoCommand.result.cancel
    End Select

    context.m_doc.Regen()
    Return IRhinoCommand.result.success
  End Function
End Class